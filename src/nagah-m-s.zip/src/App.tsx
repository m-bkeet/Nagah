/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CenterProvider, useCenter } from './context/CenterContext';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ToastContainer } from './components/ToastContainer';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { PrintModal } from './components/PrintModal';
import { FloatingTeachingToolsOverlay } from './components/FloatingTeachingToolsOverlay';
import { MobileAppNavigation } from './components/MobileAppNavigation';
import { ThemeStudioModal } from './components/ThemeStudioModal';
import { PwaUpdateToast } from './components/PwaUpdateToast';
import { ErrorBoundary } from './components/ErrorBoundary';
import { FloatingChatButton } from './components/FloatingChatButton';

// Views
import { LoginView } from './views/LoginView';
import { DashboardView } from './views/DashboardView';
import { TraineesView } from './views/TraineesView';
import { TrainersView } from './views/TrainersView';
import { CoursesView } from './views/CoursesView';
import { ProgramsView } from './views/ProgramsView';
import { GroupsView } from './views/GroupsView';
import { AttendanceView } from './views/AttendanceView';
import { FinanceView } from './views/FinanceView';
import { ExpensesView } from './views/ExpensesView';
import { PointsView } from './views/PointsView';
import { ExamsView } from './views/ExamsView';
import { InteractiveSessionsView } from './views/InteractiveSessionsView';
import { SocialFeedView } from './views/SocialFeedView';
import { DevicesView } from './views/DevicesView';
import { MessagesView } from './views/MessagesView';
import { HomeworksView } from './views/HomeworksView';
import { ReportsView } from './views/ReportsView';
import { CertificatesView } from './views/CertificatesView';
import { BranchesView } from './views/BranchesView';
import { AuditLogsView } from './views/AuditLogsView';
import { SettingsView } from './views/SettingsView';
import { StudentKioskView } from './views/StudentKioskView';
import { ProjectorView } from './views/ProjectorView';
import { PublicRegistrationView } from './views/PublicRegistrationView';
import { PublicTrainerRegistrationView } from './views/PublicTrainerRegistrationView';
import { LabScheduleView } from './views/LabScheduleView';
import { PublicParentPortalView } from './views/PublicParentPortalView';
import { PublicStudentPortalView } from './views/PublicStudentPortalView';
import { PublicTrainerPortalView } from './views/PublicTrainerPortalView';
import { NagahAiDeveloperView } from './views/NagahAiDeveloperView';

const MainLayout: React.FC = () => {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { setIsSearchOpen } = useCenter();
  const { themeConfig } = useTheme();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(true);

  // Global Ctrl+K / Cmd+K Command Palette Shortcut Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setIsSearchOpen]);

  const queryParams = new URLSearchParams(window.location.search);
  const search = window.location.search;
  
  // Persist lab device role in localStorage if detected via URL
  useEffect(() => {
    if (queryParams.get('role') === 'trainee_device' || queryParams.get('view') === 'student_kiosk') {
      localStorage.setItem('nagah_is_lab_device', 'true');
    }
  }, [search]);

  const isTrainerRegister = search.includes('trainer_register=true');
  const isRegister = search.includes('view=register') || search.includes('/register') || search.includes('student_register=true');
  const isParentPortal = search.includes('view=parent_portal') || search.includes('parent-portal');
  const isStudentPortal = search.includes('view=student_portal') || search.includes('student-portal');
  const isTrainerPortal = search.includes('view=trainer_portal') || search.includes('trainer-portal') || search.includes('role=trainer_portal') || activeTab === 'trainer_portal';
  
  const handleExitToHome = () => {
    try {
      localStorage.removeItem('nagah_is_lab_device');
    } catch (e) {
      // ignore
    }
    window.location.href = window.location.origin;
  };

  const isTraineeKiosk = 
    queryParams.get('role') === 'trainee_device' || 
    queryParams.get('view') === 'student_kiosk' || 
    (queryParams.get('kiosk') === 'true') ||
    activeTab === 'student_kiosk' || 
    user?.role === 'trainee_device';

  const isProjector = queryParams.get('view') === 'projector' || activeTab === 'projector';

  if (isTrainerPortal) {
    return (
      <ErrorBoundary fallbackTitle="استعادة بوابة المحاضر والمدرب">
        <PublicTrainerPortalView onBack={handleExitToHome} />
      </ErrorBoundary>
    );
  }

  if (isTrainerRegister) {
    return (
      <ErrorBoundary fallbackTitle="استعادة نموذج تسجيل المدربين">
        <PublicTrainerRegistrationView onBack={handleExitToHome} />
      </ErrorBoundary>
    );
  }

  if (isRegister) {
    return (
      <ErrorBoundary fallbackTitle="استعادة نموذج التسجيل">
        <PublicRegistrationView onBack={handleExitToHome} />
      </ErrorBoundary>
    );
  }

  if (isParentPortal) {
    return (
      <ErrorBoundary fallbackTitle="استعادة بوابة ولي الأمر">
        <PublicParentPortalView onBack={handleExitToHome} />
      </ErrorBoundary>
    );
  }

  if (isStudentPortal) {
    return (
      <ErrorBoundary fallbackTitle="استعادة بوابة المتدرب">
        <PublicStudentPortalView onBack={handleExitToHome} />
      </ErrorBoundary>
    );
  }

  // PRIORITY BYPASS: Student Kiosk / Lab Device Mode
  // This must come BEFORE any auth or loading checks to ensure lab devices work instantly
  if (isTraineeKiosk) {
    return (
      <ErrorBoundary fallbackTitle="استعادة كشك المتدرب بالمعمل">
        <StudentKioskView />
      </ErrorBoundary>
    );
  }

  if (isProjector) {
    return (
      <ErrorBoundary fallbackTitle="استعادة شاشة العرض والبروجيكتور">
        <ProjectorView onExit={() => setActiveTab('devices')} />
      </ErrorBoundary>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-100 space-y-3" dir="rtl">
        <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm font-bold text-slate-300 font-mono">جاري تحميل نظام مركز النجاح V7...</p>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <ErrorBoundary fallbackTitle="استعادة شاشة تسجيل الدخول">
        <LoginView />
      </ErrorBoundary>
    );
  }

  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView onNavigate={(tab) => setActiveTab(tab)} />;
      case 'trainees':
        return <TraineesView />;
      case 'trainers':
        return <TrainersView />;
      case 'courses':
        return <CoursesView />;
      case 'programs':
        return <ProgramsView />;
      case 'groups':
        return <GroupsView onNavigate={(tab) => setActiveTab(tab)} />;
      case 'lab_schedule':
        return <LabScheduleView />;
      case 'attendance':
        return <AttendanceView />;
      case 'finance':
        return <FinanceView />;
      case 'expenses':
        return <ExpensesView />;
      case 'points':
        return <PointsView />;
      case 'exams':
        return <ExamsView />;
      case 'interactive':
        return <InteractiveSessionsView />;
      case 'social_feed':
        return <SocialFeedView />;
      case 'devices':
        return <DevicesView />;
      case 'student_kiosk':
        return <StudentKioskView />;
      case 'projector':
        return <ProjectorView onExit={() => setActiveTab('devices')} />;
      case 'messages':
        return <MessagesView />;
      case 'homeworks':
        return <HomeworksView />;
      case 'reports':
        return <ReportsView />;
      case 'certificates':
        return <CertificatesView />;
      case 'branches':
        return <BranchesView />;
      case 'ai_developer':
        return <NagahAiDeveloperView />;
      case 'audit':
      case 'audit_logs':
        return <AuditLogsView />;
      case 'parent_portal':
        return <PublicParentPortalView onBack={() => setActiveTab('dashboard')} />;
      case 'student_portal':
        return <PublicStudentPortalView onBack={() => setActiveTab('dashboard')} />;
      case 'settings':
        return <SettingsView />;
      default:
        return <DashboardView onNavigate={(tab) => setActiveTab(tab)} />;
    }
  };

  return (
    <div
      className="min-h-screen text-slate-100 flex flex-col font-sans transition-colors duration-300"
      style={{ backgroundColor: themeConfig.colors.bgMain }}
      dir="rtl"
    >
      {/* Top Header */}
      <Header
        onNavigate={(view) => setActiveTab(view)}
        toggleSidebar={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />

      {/* Mobile Top App Quick Bar (FB/WhatsApp style) */}
      <MobileAppNavigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Body with Sidebar and Main Content */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Desktop Sidebar (participates in flex flow) */}
        <div className="hidden md:block shrink-0 transition-all duration-300" style={{ width: isSidebarCollapsed ? '4rem' : '15rem' }}>
          <Sidebar
            activeTab={activeTab}
            onTabChange={setActiveTab}
            isCollapsed={isSidebarCollapsed}
            onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            isMobile={false}
          />
        </div>

        <main
          className="flex-1 overflow-y-auto p-4 md:p-6 pb-20 md:pb-6 transition-all duration-300"
          style={{
            background: `linear-gradient(to bottom, ${themeConfig?.colors?.bgMainGradientStart || '#0c0f1f'}, ${themeConfig?.colors?.bgMainGradientMid || '#121026'}, ${themeConfig?.colors?.bgMainGradientEnd || '#080a14'})`
          }}
        >
          <div className="max-w-7xl mx-auto">
            <ErrorBoundary fallbackTitle="استعادة واجهة النظام الحالية">
              {renderActiveView()}
            </ErrorBoundary>
          </div>
        </main>
      </div>

      {/* Mobile Sidebar (pure floating overlay, outside flex-flow of body) */}
      <div className="block md:hidden">
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          isMobile={true}
        />
      </div>

      {/* Global Modals & Overlays */}
      <PwaUpdateToast />
      <FloatingTeachingToolsOverlay onNavigateToView={(view) => setActiveTab(view)} />
      <GlobalSearchModal onNavigate={(view) => setActiveTab(view)} />
      <PrintModal />
      <ToastContainer />
      <FloatingChatButton />
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary fallbackTitle="استعادة تشغيل تطبيق مركز النجاح">
      <AuthProvider>
        <ThemeProvider>
          <CenterProvider>
            <MainLayout />
          </CenterProvider>
        </ThemeProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
