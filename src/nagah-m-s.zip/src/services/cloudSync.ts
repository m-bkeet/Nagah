import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  limit, 
  Timestamp, 
  updateDoc, 
  deleteDoc,
  CollectionReference
} from '../lib/firebase';
import { db } from '../lib/firebase';
import { Trainee, Branch, Course, Group, Trainer, AttendanceRecord, Payment, Expense, ExamResult, PointTransaction, CenterSettings } from '../types';

/**
 * Cloud Sync Service with Firebase Firestore.
 * Automatically synchronizes student registrations, attendance, trainers, branches, 
 * payments, and center state in realtime across ALL devices (Mobiles, Desktops, Tablets, Vercel/Web).
 */

export class CloudSyncService {
  private static instance: CloudSyncService;

  public static getInstance(): CloudSyncService {
    if (!CloudSyncService.instance) {
      CloudSyncService.instance = new CloudSyncService();
    }
    return CloudSyncService.instance;
  }

  private getCollection(name: string): CollectionReference | null {
    try {
      if (!db) return null;
      return collection(db, name);
    } catch {
      return null;
    }
  }

  /**
   * Save or Update Trainee in Firestore Cloud
   */
  async syncTraineeToCloud(trainee: Trainee): Promise<void> {
    try {
      if (!db || !trainee?.id) return;
      const docRef = doc(db, 'trainees', trainee.id);
      await setDoc(docRef, {
        ...trainee,
        updatedAt: Date.now(),
        syncedAt: new Date().toISOString()
      }, { merge: true });
      console.log(`[CloudSync] Trainee synced to cloud: ${trainee.fullName} (${trainee.code})`);
    } catch (error) {
      console.warn('[CloudSync] Failed to sync trainee to Firestore:', error);
    }
  }

  /**
   * Delete Trainee from Firestore Cloud
   */
  async deleteTraineeFromCloud(traineeId: string): Promise<void> {
    try {
      if (!db || !traineeId) return;
      await deleteDoc(doc(db, 'trainees', traineeId));
      console.log(`[CloudSync] Trainee deleted from cloud: ${traineeId}`);
    } catch (error) {
      console.warn('[CloudSync] Failed to delete trainee from Firestore:', error);
    }
  }

  /**
   * Fetch all Trainees from Cloud
   */
  async getTraineesFromCloud(): Promise<Trainee[]> {
    try {
      const col = this.getCollection('trainees');
      if (!col) return [];
      const snapshot = await getDocs(col);
      const list: Trainee[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as Trainee);
      });
      return list;
    } catch (error) {
      console.warn('[CloudSync] Failed to fetch trainees from cloud:', error);
      return [];
    }
  }

  /**
   * Realtime Listener for Trainees across all open devices
   */
  subscribeToTrainees(callback: (trainees: Trainee[]) => void): () => void {
    try {
      const col = this.getCollection('trainees');
      if (!col) return () => {};
      const unsubscribe = onSnapshot(col, (snapshot) => {
        const list: Trainee[] = [];
        snapshot.forEach((docSnap) => {
          list.push({ id: docSnap.id, ...docSnap.data() } as Trainee);
        });
        if (list.length > 0) {
          callback(list);
        }
      }, (error) => {
        console.warn('[CloudSync] Realtime Trainees listener error:', error);
      });
      return unsubscribe;
    } catch (err) {
      console.warn('[CloudSync] Failed to establish trainees snapshot subscription', err);
      return () => {};
    }
  }

  /**
   * Sync Branch / Course / Group / Settings
   */
  async syncBranchToCloud(branch: Branch): Promise<void> {
    try {
      if (!db || !branch?.id) return;
      await setDoc(doc(db, 'branches', branch.id), branch, { merge: true });
    } catch (e) {
      console.warn('[CloudSync] Failed to sync branch:', e);
    }
  }

  async syncGroupToCloud(group: Group): Promise<void> {
    try {
      if (!db || !group?.id) return;
      await setDoc(doc(db, 'groups', group.id), group, { merge: true });
    } catch (e) {
      console.warn('[CloudSync] Failed to sync group:', e);
    }
  }

  async syncCourseToCloud(course: Course): Promise<void> {
    try {
      if (!db || !course?.id) return;
      await setDoc(doc(db, 'courses', course.id), course, { merge: true });
    } catch (e) {
      console.warn('[CloudSync] Failed to sync course:', e);
    }
  }

  async syncSettingsToCloud(settings: CenterSettings): Promise<void> {
    try {
      if (!db) return;
      await setDoc(doc(db, 'settings', 'center_config'), settings, { merge: true });
    } catch (e) {
      console.warn('[CloudSync] Failed to sync settings:', e);
    }
  }

  /**
   * Batch initial seed / upload of existing data to Firestore
   */
  async seedInitialDataToCloud(data: {
    trainees?: Trainee[];
    branches?: Branch[];
    courses?: Course[];
    groups?: Group[];
    trainers?: Trainer[];
    settings?: CenterSettings;
  }): Promise<void> {
    try {
      if (data.trainees) {
        for (const t of data.trainees) {
          await this.syncTraineeToCloud(t);
        }
      }
      if (data.branches) {
        for (const b of data.branches) {
          await this.syncBranchToCloud(b);
        }
      }
      if (data.courses) {
        for (const c of data.courses) {
          await this.syncCourseToCloud(c);
        }
      }
      if (data.groups) {
        for (const g of data.groups) {
          await this.syncGroupToCloud(g);
        }
      }
      if (data.settings) {
        await this.syncSettingsToCloud(data.settings);
      }
      console.log('[CloudSync] Initial bulk cloud backup/sync finished successfully');
    } catch (err) {
      console.warn('[CloudSync] Error in bulk seed:', err);
    }
  }
}

export const cloudSync = CloudSyncService.getInstance();
