import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  query,
  where,
  onSnapshot,
  Unsubscribe
} from '../lib/firebase';
import { db } from '../lib/firebase';

export type SessionEventType =
  | 'SESSION_REMINDER'
  | 'SESSION_STARTED'
  | 'SESSION_FIVE_MINUTES'
  | 'SESSION_ENDED'
  | 'SESSION_CELEBRATION'
  | 'STAR_WINNER';

export interface SessionEvent {
  id: string;
  sessionId: string;
  groupId: string;
  groupName?: string;
  courseId?: string;
  courseName?: string;
  trainerId?: string;
  trainerName?: string;
  eventType: SessionEventType;
  createdAt: string;
  starWinnerId?: string;
  starWinnerName?: string;
  starWinnerPoints?: number;
  metadata?: Record<string, any>;
}

const LOCAL_PROCESSED_KEY = 'nagah_processed_session_events_v1';

class SessionEventsService {
  /**
   * Check if event has already been processed on this device
   */
  public isEventProcessedLocally(eventId: string): boolean {
    if (typeof localStorage === 'undefined') return false;
    try {
      const raw = localStorage.getItem(LOCAL_PROCESSED_KEY);
      const processed: string[] = raw ? JSON.parse(raw) : [];
      return processed.includes(eventId);
    } catch {
      return false;
    }
  }

  /**
   * Mark event ID as processed on this device (Idempotence guard)
   */
  public markEventProcessedLocally(eventId: string): void {
    if (typeof localStorage === 'undefined') return;
    try {
      const raw = localStorage.getItem(LOCAL_PROCESSED_KEY);
      const processed: string[] = raw ? JSON.parse(raw) : [];
      if (!processed.includes(eventId)) {
        processed.push(eventId);
        // Keep max 200 event IDs
        const trimmed = processed.slice(-200);
        localStorage.setItem(LOCAL_PROCESSED_KEY, JSON.stringify(trimmed));
      }
    } catch (err) {
      console.warn('[SessionEventsService] Failed to record processed event:', err);
    }
  }

  /**
   * Dispatch a Session Event to Firestore atomically
   * Event ID formula: `${sessionId}_${eventType}` (Guarantees single doc per event type per session)
   */
  public async dispatchSessionEvent(
    eventData: Omit<SessionEvent, 'id' | 'createdAt'>
  ): Promise<SessionEvent | null> {
    if (!db) return null;
    const eventId = `${eventData.sessionId}_${eventData.eventType}`;
    const docRef = doc(db, 'sessionEvents', eventId);

    try {
      // Check if event document already exists in Firestore
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        console.log(`[SessionEventsService] Event ${eventId} already exists in Firestore. Skipping duplicate dispatch.`);
        return { id: snap.id, ...(snap.data() as any) };
      }

      const newEvent: SessionEvent = {
        ...eventData,
        id: eventId,
        createdAt: new Date().toISOString()
      };

      await setDoc(docRef, newEvent);
      console.log(`[SessionEventsService] Dispatched event ${eventId} to Firestore successfully.`);
      return newEvent;
    } catch (err) {
      console.warn(`[SessionEventsService] Error dispatching event ${eventId}:`, err);
      return null;
    }
  }

  /**
   * Listen to real-time session events for a group
   */
  public listenToGroupSessionEvents(
    groupId: string,
    onNewEvent: (event: SessionEvent) => void
  ): Unsubscribe {
    if (!groupId || !db) return () => {};

    try {
      const q = query(
        collection(db, 'sessionEvents'),
        where('groupId', '==', groupId)
      );

      return onSnapshot(
        q,
        (snapshot) => {
          snapshot.docChanges().forEach((change) => {
            if (change.type === 'added' || change.type === 'modified') {
              const event = { id: change.doc.id, ...(change.doc.data() as any) } as SessionEvent;
              if (event.id && !this.isEventProcessedLocally(event.id)) {
                this.markEventProcessedLocally(event.id);
                onNewEvent(event);
              }
            }
          });
        },
        (err) => {
          console.warn(`[SessionEventsService] Realtime listener error for group ${groupId}:`, err);
        }
      );
    } catch (err) {
      console.warn(`[SessionEventsService] Failed to setup listener for group ${groupId}:`, err);
      return () => {};
    }
  }

  /**
   * Listen to all session events (for Trainer / Admin portal)
   */
  public listenToAllSessionEvents(
    onNewEvent: (event: SessionEvent) => void
  ): Unsubscribe {
    try {
      const q = query(collection(db, 'sessionEvents'));
      return onSnapshot(
        q,
        (snapshot) => {
          snapshot.docChanges().forEach((change) => {
            if (change.type === 'added' || change.type === 'modified') {
              const event = { id: change.doc.id, ...(change.doc.data() as any) } as SessionEvent;
              if (event.id && !this.isEventProcessedLocally(event.id)) {
                this.markEventProcessedLocally(event.id);
                onNewEvent(event);
              }
            }
          });
        },
        (err) => {
          console.warn('[SessionEventsService] Listener error for all events:', err);
        }
      );
    } catch (err) {
      console.warn('[SessionEventsService] Setup error for all events:', err);
      return () => {};
    }
  }
}

export const sessionEventsService = new SessionEventsService();
