import {
  collection,
  doc,
  setDoc,
  getDocs,
  getDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  Unsubscribe
} from '../lib/firebase';
import { db } from '../lib/firebase';
import { Trainee, Trainer, Course, Group, Branch, Payment, AttendanceRecord, ExamResult, PointTransaction, CenterSettings } from '../types';

/**
 * Cloud Real-Time Database Sync Engine (Firebase Firestore)
 * Enables live multi-device instant synchronization for Mobile, Tablet, and Desktop.
 */

export const cloudDb = {
  // --- Trainees / Students ---
  async syncTrainee(trainee: Trainee): Promise<void> {
    try {
      if (!db || !trainee.id) return;
      const ref = doc(db, 'trainees', trainee.id);
      await setDoc(ref, {
        ...trainee,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.warn('[CloudDb] syncTrainee error:', err);
    }
  },

  async deleteTrainee(traineeId: string): Promise<void> {
    try {
      if (!db || !traineeId) return;
      const ref = doc(db, 'trainees', traineeId);
      await deleteDoc(ref);
    } catch (err) {
      console.warn('[CloudDb] deleteTrainee error:', err);
    }
  },

  async getAllTrainees(): Promise<Trainee[]> {
    try {
      if (!db) return [];
      const q = query(collection(db, 'trainees'));
      const snapshot = await getDocs(q);
      const list: Trainee[] = [];
      snapshot.forEach(d => {
        list.push({ id: d.id, ...(d.data() as any) });
      });
      return list;
    } catch (err) {
      console.warn('[CloudDb] getAllTrainees error:', err);
      return [];
    }
  },

  listenToTrainees(callback: (trainees: Trainee[]) => void): Unsubscribe {
    try {
      if (!db) return () => {};
      const q = query(collection(db, 'trainees'));
      return onSnapshot(q, (snapshot) => {
        const list: Trainee[] = [];
        snapshot.forEach(d => {
          list.push({ id: d.id, ...(d.data() as any) });
        });
        callback(list);
      }, (err) => {
        console.warn('[CloudDb] listenToTrainees error:', err);
      });
    } catch (err) {
      console.warn('[CloudDb] listenToTrainees init error:', err);
      return () => {};
    }
  },

  // --- Trainers ---
  async syncTrainer(trainer: Trainer): Promise<void> {
    try {
      if (!trainer.id) return;
      const ref = doc(db, 'trainers', trainer.id);
      await setDoc(ref, {
        ...trainer,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.warn('[CloudDb] syncTrainer error:', err);
    }
  },

  async getAllTrainers(): Promise<Trainer[]> {
    try {
      const snapshot = await getDocs(collection(db, 'trainers'));
      const list: Trainer[] = [];
      snapshot.forEach(d => {
        list.push({ id: d.id, ...(d.data() as any) });
      });
      return list;
    } catch (err) {
      console.warn('[CloudDb] getAllTrainers error:', err);
      return [];
    }
  },

  // --- Courses & Groups & Branches ---
  async syncCourse(course: Course): Promise<void> {
    try {
      if (!course.id) return;
      await setDoc(doc(db, 'courses', course.id), {
        ...course,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.warn('[CloudDb] syncCourse error:', err);
    }
  },

  async deleteCourse(courseId: string): Promise<void> {
    try {
      if (!courseId) return;
      await deleteDoc(doc(db, 'courses', courseId));
    } catch (err) {
      console.warn('[CloudDb] deleteCourse error:', err);
    }
  },

  async getAllCourses(): Promise<Course[]> {
    try {
      const snapshot = await getDocs(collection(db, 'courses'));
      const list: Course[] = [];
      snapshot.forEach(d => {
        list.push({ id: d.id, ...(d.data() as any) });
      });
      return list;
    } catch (err) {
      console.warn('[CloudDb] getAllCourses error:', err);
      return [];
    }
  },

  async syncGroup(group: Group): Promise<void> {
    try {
      if (!group.id) return;
      await setDoc(doc(db, 'groups', group.id), {
        ...group,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.warn('[CloudDb] syncGroup error:', err);
    }
  },

  async deleteGroup(groupId: string): Promise<void> {
    try {
      if (!groupId) return;
      await deleteDoc(doc(db, 'groups', groupId));
    } catch (err) {
      console.warn('[CloudDb] deleteGroup error:', err);
    }
  },

  async getAllGroups(): Promise<Group[]> {
    try {
      const snapshot = await getDocs(collection(db, 'groups'));
      const list: Group[] = [];
      snapshot.forEach(d => {
        list.push({ id: d.id, ...(d.data() as any) });
      });
      return list;
    } catch (err) {
      console.warn('[CloudDb] getAllGroups error:', err);
      return [];
    }
  },

  async syncBranch(branch: Branch): Promise<void> {
    try {
      if (!branch.id) return;
      await setDoc(doc(db, 'branches', branch.id), {
        ...branch,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.warn('[CloudDb] syncBranch error:', err);
    }
  },

  async getAllBranches(): Promise<Branch[]> {
    try {
      const snapshot = await getDocs(collection(db, 'branches'));
      const list: Branch[] = [];
      snapshot.forEach(d => {
        list.push({ id: d.id, ...(d.data() as any) });
      });
      return list;
    } catch (err) {
      console.warn('[CloudDb] getAllBranches error:', err);
      return [];
    }
  },

  // --- Push full local state to cloud (Initial or On-Demand Master Sync) ---
  async syncFullCenterToCloud(data: {
    trainees?: Trainee[];
    trainers?: Trainer[];
    courses?: Course[];
    groups?: Group[];
    branches?: Branch[];
  }): Promise<{ success: boolean; syncedCount: number }> {
    let count = 0;
    try {
      if (data.trainees) {
        for (const t of data.trainees) {
          await this.syncTrainee(t);
          count++;
        }
      }
      if (data.trainers) {
        for (const tr of data.trainers) {
          await this.syncTrainer(tr);
          count++;
        }
      }
      if (data.courses) {
        for (const c of data.courses) {
          await this.syncCourse(c);
          count++;
        }
      }
      if (data.groups) {
        for (const g of data.groups) {
          await this.syncGroup(g);
          count++;
        }
      }
      if (data.branches) {
        for (const b of data.branches) {
          await this.syncBranch(b);
          count++;
        }
      }
      return { success: true, syncedCount: count };
    } catch (err) {
      console.error('[CloudDb] syncFullCenterToCloud error:', err);
      return { success: false, syncedCount: count };
    }
  },

  // --- Live Listeners for Real-time Updates ---
  listenToCollection<T>(collectionName: string, callback: (items: T[]) => void): Unsubscribe {
    try {
      const q = query(collection(db, collectionName));
      return onSnapshot(q, (snapshot) => {
        const list: T[] = [];
        snapshot.forEach(d => {
          list.push({ id: d.id, ...(d.data() as any) });
        });
        callback(list);
      }, (err) => {
        console.warn(`[CloudDb] listenToCollection(${collectionName}) error:`, err);
      });
    } catch (err) {
      console.warn(`[CloudDb] listenToCollection(${collectionName}) init error:`, err);
      return () => {};
    }
  },

  // --- Student Messages & Homework ---
  async syncStudentMessage(message: any): Promise<void> {
    try {
      if (!message.id) return;
      await setDoc(doc(db, 'student_messages', message.id), {
        ...message,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.warn('[CloudDb] syncStudentMessage error:', err);
    }
  },

  async syncHomeworkSubmission(submission: any): Promise<void> {
    try {
      if (!submission.id) return;
      await setDoc(doc(db, 'homework_submissions', submission.id), {
        ...submission,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.warn('[CloudDb] syncHomeworkSubmission error:', err);
    }
  }
};
