import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from './firebase';

export async function uploadFile(file: File, path: string): Promise<string> {
  try {
    const storageRef = ref(storage, path);
    await uploadBytes(storageRef, file);
    return await getDownloadURL(storageRef);
  } catch (error) {
    console.warn('Firebase Storage upload failed, falling back to local server upload:', error);
    
    // Fallback: Convert to Base64 and upload to our local Express /api/upload endpoint
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const res = await fetch('/api/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileData: reader.result,
              fileName: file.name
            })
          });
          const data = await res.json();
          if (res.ok && data.success) {
            resolve(data.url);
          } else {
            // Ultimate fallback (not recommended due to size, but better than crashing)
            resolve(reader.result as string);
          }
        } catch (e) {
          resolve(reader.result as string);
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
}
