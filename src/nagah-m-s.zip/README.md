# Nagah Management & Smart Education System 🌟
## مركز النجاح للتدريب والاستشارات — المنصة التعليمية والإدارية الذكية

نظام إدارة التدريب والاستشارات والمختبر اللغوي الذكي (AI Language Lab) المتكامل مع بوابات الطلاب، المدربين، وأولياء الأمور.

---

## 🚀 المميزات الرئيسية (Key Features)

1. **بوابة الطالب التفاعلية (Student Portal)**:
   - متابعة الدروس والجداول والحضور.
   - تسليم الواجبات والتصحيح الفوري بالذكاء الاصطناعي مع رصد الأوسمة والنقاط.
   - **معملي الذكي (AI Language Lab)**: اختبار تشخيصي لمستويات CEFR، معمل المحادثة التفاعلي، التدريب الصوتي، بطاقات التكرار المتباعد (Leitner Spaced Repetition)، ومعمل الكتابة.

2. **بوابة المدرب المحاضر (Trainer Portal)**:
   - رصد الحضور والغياب، تقييم الواجبات والدرجات.
   - البث المباشر وقاعات التدريب التفاعلية.
   - **استوديو اللغات للمدربين**: توليد الأنشطة الذكية بالأوامر الطبيعية، محلل أداء المجموعات اللغوي، ومساعد تحضير الحصص.

3. **بوابة ولي الأمر (Parent Portal)**:
   - متابعة الأداء الأكاديمي والمالي والأوسمة لكل متدرب.
   - نافذة مؤشرات معمل اللغات الذكي (CEFR Level, Speaking Time, Mastered Vocabulary).

4. **لوحة الإدارة الشاملة (Admin Dashboard)**:
   - إدارة الفروع، القاعات، المجموعات، الكورسات، المدربين، والماليات.
   - استيراد وتصدير إكسل، طباعة الشهادات المعتمدة، وإدارة الحسابات.

5. **التشغيل المزدوج والموثوقية (Offline-First & Resilience)**:
   - دعم التخزين المحلي والمزامنة التلقائية عند عودة الاتصال.
   - دعم Firebase Firestore للبيانات السحابية الحية.

---

## 🛠️ التقنيات المستخدمة (Tech Stack)

- **Frontend**: React 18, TypeScript, Tailwind CSS, Lucide Icons, Vite
- **Backend API**: Express.js, Node.js, RESTful Endpoints
- **AI Integration**: Google Gemini API (`@google/genai`) with fallback model cascades
- **Persistence**: Firebase Firestore & Offline LocalStorage Cache Sync
- **Deployment Ready**: Cloud Run, Vercel, Docker

---

## 📦 البدء والتثبيت (Getting Started)

### 1. استنساخ المستودع (Clone Repository)
```bash
git clone https://github.com/your-username/nagah-system.git
cd nagah-system
```

### 2. تثبيت الحزم (Install Dependencies)
```bash
npm install
```

### 3. إعداد متغيرات البيئة (Environment Variables)
قم بإنشاء ملف `.env` استناداً إلى `.env.example`:
```env
GEMINI_API_KEY=your_gemini_api_key_here
FIREBASE_PROJECT_ID=your_firebase_project_id
FIREBASE_CLIENT_EMAIL=your_firebase_client_email
FIREBASE_PRIVATE_KEY="your_firebase_private_key"
```

### 4. تشغيل التطبيق في وضع التطوير (Development)
```bash
npm run dev
```
التطبيق سيعمل محلياً على: `http://localhost:3000`

### 5. بناء المشروع للإنتاج (Production Build)
```bash
npm run build
npm start
```

---

## 📂 هيكل المشروع (Project Structure)

```
├── server/                    # Express backend & API routes
│   ├── gemini.ts             # AI client & model cascade
│   ├── languageLabRoutes.ts  # AI Language Lab endpoints
│   ├── routes.ts             # Main API router
│   └── index.ts              # Server entry point
├── src/
│   ├── components/           # UI components & widgets
│   │   ├── language/         # Student & Trainer Language Lab UIs
│   │   ├── trainer/          # Trainer portal components
│   │   └── ...
│   ├── services/             # Core business logic & API clients
│   │   ├── languageLabCore.ts
│   │   ├── api.ts
│   │   └── resilientOfflineService.ts
│   ├── views/                # Full-page portal views
│   ├── types.ts              # TypeScript domain types
│   ├── App.tsx               # Root application component
│   └── main.tsx              # React DOM entry point
├── metadata.json             # App metadata & capabilities
├── package.json
└── README.md
```

---

## 📄 الترخيص (License)
جميع الحقوق محفوظة لـ **مركز النجاح للتدريب والاستشارات**.
