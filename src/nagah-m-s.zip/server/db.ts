import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import os from 'os';
import {
  User,
  Branch,
  Trainee,
  Trainer,
  Course,
  Program,
  Group,
  AttendanceRecord,
  Payment,
  Expense,
  TrainerSettlement,
  PointRule,
  PointTransaction,
  Exam,
  ExamQuestion,
  ExamResult,
  InteractiveSession,
  Device,
  DeviceCommand,
  Certificate,
  TrainerAttestation,
  CertificateTemplate,
  AuditLog,
  CenterSettings,
  SystemNotification,
  TraineeScreenshot,
  ComputerLab,
  AssignmentTask
} from '../src/types.ts';

export interface DatabaseSchema {
  assignments?: AssignmentTask[];
  users: User[];
  branches: Branch[];
  trainees: Trainee[];
  trainers: Trainer[];
  courses: Course[];
  programs: Program[];
  groups: Group[];
  attendance: AttendanceRecord[];
  payments: Payment[];
  expenses: Expense[];
  trainerSettlements: TrainerSettlement[];
  pointRules: PointRule[];
  pointTransactions: PointTransaction[];
  exams: Exam[];
  questions: ExamQuestion[];
  examResults: ExamResult[];
  interactiveSessions: InteractiveSession[];
  devices: Device[];
  deviceCommands: DeviceCommand[];
  certificates: Certificate[];
  certificateTemplates?: CertificateTemplate[];
  trainerAttestations?: TrainerAttestation[];
  auditLogs: AuditLog[];
  settings: CenterSettings;
  notifications: SystemNotification[];
  traineeScreenshots?: TraineeScreenshot[];
  secretFinancialArchives?: any[];
  deletedDeviceIds?: string[];
  labSchedules?: any[];
  traineeBadges?: any[];
  traineeEvaluations?: any[];
  homeworkSubmissions?: any[];
  computerLabs?: ComputerLab[];
  googleDriveSync?: any;
  studentPosts?: any[];
  socialComments?: any[];
  portalMessages?: any[];
}

const isServerless = Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME || process.env.VERCEL_ENV);
const ACTUAL_DATA_DIR = isServerless ? path.join(os.tmpdir(), 'nagah_data') : path.join(process.cwd(), 'data');
const BACKUPS_DIR = path.join(ACTUAL_DATA_DIR, 'backups');
const DB_FILE = path.join(ACTUAL_DATA_DIR, 'database.json');
const BACKUP_FILE = path.join(ACTUAL_DATA_DIR, 'database.backup.json');
const BUNDLED_DB_FILE = path.join(process.cwd(), 'data', 'database.json');

// Simple secure hash
export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + '_success_v7_salt').digest('hex');
}

const defaultPointRules: PointRule[] = [
  { id: 'rule-1', title: 'تسجيل الحضور', pointValue: 10, ruleType: 'attendance', description: 'نقاط الحضور في الموعد المحدد', isActive: true },
  { id: 'rule-2', title: 'المشاركة والتفاعل', pointValue: 20, ruleType: 'participation', description: 'التفاعل الإيجابي أثناء المحاضرة', isActive: true },
  { id: 'rule-3', title: 'إنجاز المهمة / الواجب', pointValue: 30, ruleType: 'task', description: 'تسليم التطبيقات العملية والواجبات', isActive: true },
  { id: 'rule-4', title: 'التميز والتفوق', pointValue: 50, ruleType: 'excellence', description: 'الحصول على المركز الأول أو عمل مميز', isActive: true },
  { id: 'rule-5', title: 'مخالفة أو تأخير', pointValue: -10, ruleType: 'violation', description: 'التأخير أو عدم الالتزام بقواعد القاعة', isActive: true },
];

const initialData: DatabaseSchema = {
  computerLabs: [
    {
      id: 'lab-1',
      name: 'معمل النجاح',
      branchId: 'branch-1',
      branchName: 'فرع النجاح',
      capacity: 25,
      devicesCount: 20,
      status: 'active',
      notes: 'معمل الحاسب والبرمجة الرئيسي - فرع النجاح'
    },
    {
      id: 'lab-2',
      name: 'معمل بدر',
      branchId: 'branch-2',
      branchName: 'فرع بدر',
      capacity: 25,
      devicesCount: 20,
      status: 'active',
      notes: 'معمل الحاسب والتكنولوجيا الرئيسي - فرع بدر'
    }
  ],
  branches: [
    {
      id: 'branch-1',
      name: 'فرع النجاح',
      code: 'NGAH',
      address: 'المقر الرئيسي - مبنى النجاح للتدريب',
      phone: '01012345678',
      managerName: 'مدير فرع النجاح',
      status: 'active',
      createdAt: new Date().toISOString()
    },
    {
      id: 'branch-2',
      name: 'فرع بدر',
      code: 'BADR',
      address: 'فرع مدينة بدر - سنتر التدريب',
      phone: '01087654321',
      managerName: 'مدير فرع بدر',
      status: 'active',
      createdAt: new Date().toISOString()
    }
  ],
  users: [
    {
      id: 'user-admin',
      username: 'admin',
      fullName: 'مدير عام النظام',
      role: 'super_admin',
      phone: '01000000000',
      email: 'admin@nagah.eg',
      status: 'active',
      createdAt: new Date().toISOString()
    },
    {
      id: 'user-accountant',
      username: 'accountant',
      fullName: 'المدير المالي',
      role: 'accountant',
      branchId: 'branch-1',
      phone: '01055556666',
      email: 'finance@nagah.eg',
      status: 'active',
      createdAt: new Date().toISOString()
    },
    {
      id: 'user-reception',
      username: 'reception',
      fullName: 'مسئول التسجيل',
      role: 'receptionist',
      branchId: 'branch-1',
      phone: '01077778888',
      email: 'reception@nagah.eg',
      status: 'active',
      createdAt: new Date().toISOString()
    },
    {
      id: 'user-trainer',
      username: 'trainer',
      fullName: 'مدرب معتمد',
      role: 'trainer',
      branchId: 'branch-1',
      phone: '01099990000',
      email: 'trainer@nagah.eg',
      status: 'active',
      createdAt: new Date().toISOString()
    },
    {
      id: 'user-branch-1',
      username: 'manager_ngah',
      fullName: 'مدير فرع النجاح',
      role: 'branch_manager',
      branchId: 'branch-1',
      phone: '01011112222',
      email: 'ngah@nagah.eg',
      status: 'active',
      createdAt: new Date().toISOString()
    },
    {
      id: 'user-branch-2',
      username: 'manager_badr',
      fullName: 'مدير فرع بدر',
      role: 'branch_manager',
      branchId: 'branch-2',
      phone: '01033334444',
      email: 'badr@nagah.eg',
      status: 'active',
      createdAt: new Date().toISOString()
    }
  ],
  trainers: [
    {
        "id": "trainer-1787349806643",
        "name": "د. محمد رمضان بخيت",
        "photoUrl": "",
        "phone": "01001500686",
        "email": "M_bkeet@yahoo.com",
        "branchId": "branch-1",
        "specialty": "ICT",
        "courseIds": [
            "course-1787347401956"
        ],
        "programIds": [],
        "commissionType": "percentage",
        "commissionRate": 40,
        "status": "active",
        "contractDate": "2026-08-21",
        "notes": "",
        "totalEarned": 0,
        "totalPaid": 0,
        "balanceDue": 0,
        "commissionValue": 40
    },
    {
        "id": "trainer-1787349870400",
        "name": "د. عماد حامد ابو النيل",
        "photoUrl": "",
        "phone": "01066264312",
        "email": "",
        "branchId": "branch-2",
        "specialty": "تكنولوجيا معلومات",
        "courseIds": [
            "course-1787347401956"
        ],
        "programIds": [],
        "commissionType": "percentage",
        "commissionRate": 40,
        "status": "active",
        "contractDate": "2026-08-21",
        "notes": "",
        "totalEarned": 0,
        "totalPaid": 0,
        "balanceDue": 0,
        "commissionValue": 40
    }
],
  trainees: [
    {
        "id": "trainee-1787361330810-d1if",
        "code": "A001",
        "fullName": "مرام محمد رمضان بخيت",
        "nationalId": "",
        "birthDate": "",
        "gender": "female",
        "phone": "01001500686",
        "parentPhone": "01001500686",
        "parentName": "محمد رمضان بخيت",
        "address": "",
        "branchId": "branch-1",
        "courseId": "course-1787347569318",
        "groupId": "grp-1787358595611",
        "trainerId": "trainer-1787349806643",
        "registrationDate": "2026-08-22",
        "status": "active",
        "feeAmount": 0,
        "discountAmount": 0,
        "netAmount": 0,
        "paidAmount": 0,
        "remainingAmount": 0,
        "notes": "ابنة الإدارة - إعفاء كامل",
        "totalPoints": 277,
        "ranking": 1,
        "points": 277,
        "courseIds": [
            "course-1787347569318"
        ],
        "isExempt": true,
        "exemptReason": "management_children",
        "siblingIds": [
            "trainee-1787361410293-aeko",
            "trainee-1787459300939-62ly"
        ],
        "siblingNames": [
            "رفيف محمد رمضان بخيت",
            "لين محمد رمضان بخيت"
        ]
    },
    {
        "id": "trainee-1787361410293-aeko",
        "code": "A002",
        "fullName": "رفيف محمد رمضان بخيت",
        "nationalId": "",
        "birthDate": "",
        "gender": "female",
        "phone": "01005400325",
        "parentPhone": "01001500686",
        "parentName": "محمد رمضان بخيت",
        "address": "",
        "branchId": "branch-1",
        "courseId": "course-1787347462419",
        "groupId": "grp-1787431608023",
        "trainerId": "trainer-1787349806643",
        "registrationDate": "2026-08-22",
        "status": "active",
        "feeAmount": 0,
        "discountAmount": 0,
        "netAmount": 0,
        "paidAmount": 0,
        "remainingAmount": 0,
        "notes": "ربط إخوة مع (مرام محمد رمضان بخيت - A001) - تم تطبيق خصم الأخوات",
        "totalPoints": 200,
        "ranking": 2,
        "points": 200,
        "courseIds": [
            "course-1787347462419"
        ],
        "isExempt": true,
        "exemptReason": "management_children",
        "siblingIds": [
            "trainee-1787361330810-d1if",
            "trainee-1787459300939-62ly"
        ],
        "siblingNames": [
            "مرام محمد رمضان بخيت",
            "لين محمد رمضان بخيت"
        ]
    },
    {
        "id": "trainee-1787459300939-62ly",
        "code": "A003",
        "fullName": "لين محمد رمضان بخيت",
        "nationalId": "",
        "birthDate": "",
        "gender": "female",
        "phone": "01001500686",
        "parentPhone": "01001500686",
        "parentName": "محمد رمضان بخيت",
        "address": "",
        "branchId": "branch-1",
        "courseId": "course-1787347401956",
        "groupId": "grp-1787350487970",
        "trainerId": "trainer-1787349806643",
        "registrationDate": "2026-08-23",
        "status": "active",
        "feeAmount": 0,
        "discountAmount": 0,
        "netAmount": 0,
        "paidAmount": 0,
        "remainingAmount": 0,
        "notes": "ربط إخوة مع (مرام ورفيف محمد رمضان بخيت) - إعفاء أبناء الإدارة",
        "totalPoints": 133,
        "ranking": 3,
        "points": 133,
        "courseIds": [
            "course-1787347401956"
        ],
        "isExempt": true,
        "exemptReason": "management_children",
        "siblingIds": [
            "trainee-1787361330810-d1if",
            "trainee-1787361410293-aeko"
        ],
        "siblingNames": [
            "مرام محمد رمضان بخيت",
            "رفيف محمد رمضان بخيت"
        ]
    }
],
  courses: [
    {
        "id": "course-1787347401956",
        "code": "CRS-472",
        "name": "ICT4",
        "branchId": "branch-1",
        "hoursCount": 8,
        "lecturesCount": 64,
        "feeAmount": 200,
        "trainerPercentage": 40,
        "centerPercentage": 60,
        "startDate": "",
        "endDate": "",
        "maxTrainees": 20,
        "status": "active",
        "description": "دورة منهج مادة الحاسب الالي للصف الرابع",
        "category": "دورة منهج ICT",
        "billingType": "monthly",
        "trainerSharePercentage": 50,
        "centerSharePercentage": 50
    },
    {
        "id": "course-1787347462419",
        "code": "CRS-695",
        "name": "ICT5",
        "branchId": "branch-1",
        "hoursCount": 8,
        "lecturesCount": 64,
        "feeAmount": 200,
        "trainerPercentage": 40,
        "centerPercentage": 60,
        "startDate": "",
        "endDate": "",
        "maxTrainees": 20,
        "status": "active",
        "description": "دورة منهج الحاسب الالي الصف الخامس",
        "category": "دورة منهج ICT",
        "billingType": "monthly",
        "trainerSharePercentage": 50,
        "centerSharePercentage": 50
    },
    {
        "id": "course-1787347508908",
        "code": "CRS-182",
        "name": "ICT6",
        "branchId": "branch-1",
        "hoursCount": 8,
        "lecturesCount": 64,
        "feeAmount": 200,
        "trainerPercentage": 40,
        "centerPercentage": 60,
        "startDate": "",
        "endDate": "",
        "maxTrainees": 20,
        "status": "active",
        "description": "دورة منهج الحاسب الالي الصف السادس",
        "category": "دورة منهج ICT",
        "billingType": "monthly",
        "trainerSharePercentage": 50,
        "centerSharePercentage": 50
    },
    {
        "id": "course-1787347569318",
        "code": "CRS-892",
        "name": "ICT-P1",
        "branchId": "branch-1",
        "hoursCount": 8,
        "lecturesCount": 64,
        "feeAmount": 200,
        "trainerPercentage": 40,
        "centerPercentage": 60,
        "startDate": "",
        "endDate": "",
        "maxTrainees": 20,
        "status": "active",
        "description": "دورة منهج الحاسب الالي الصف الاول الاعدادي",
        "category": "دورة منهج ICT",
        "billingType": "monthly",
        "trainerSharePercentage": 50,
        "centerSharePercentage": 50
    },
    {
        "id": "crs-1787427719238",
        "code": "CRS-573",
        "name": "ICT-P2",
        "branchId": "branch-1",
        "hoursCount": 8,
        "lecturesCount": 64,
        "feeAmount": 200,
        "trainerPercentage": 40,
        "centerPercentage": 60,
        "startDate": "",
        "endDate": "",
        "maxTrainees": 20,
        "status": "active",
        "description": "دورة منهج الحاسب الالي الصف الثاني الاعدادي",
        "category": "دورة منهج ICT",
        "billingType": "monthly",
        "trainerSharePercentage": 50,
        "centerSharePercentage": 50
    },
    {
        "id": "crs-1787427763144",
        "code": "CRS-644",
        "name": "ICT-P3",
        "branchId": "branch-1",
        "hoursCount": 8,
        "lecturesCount": 64,
        "feeAmount": 200,
        "trainerPercentage": 40,
        "centerPercentage": 60,
        "startDate": "",
        "endDate": "",
        "maxTrainees": 20,
        "status": "active",
        "description": "دورة منهج الحاسب الالي الصف الثالث الاعدادي",
        "category": "دورة منهج ICT",
        "billingType": "monthly",
        "trainerSharePercentage": 50,
        "centerSharePercentage": 50
    },
    {
        "id": "crs-1787427970903",
        "code": "CRS-220",
        "name": "ICT-S1",
        "branchId": "branch-1",
        "hoursCount": 8,
        "lecturesCount": 64,
        "feeAmount": 250,
        "trainerPercentage": 40,
        "centerPercentage": 60,
        "startDate": "",
        "endDate": "",
        "maxTrainees": 20,
        "status": "active",
        "description": "دورة منهج الحاسب الالي الصف الاول الثانوي",
        "category": "دورة منهج ICT",
        "billingType": "monthly",
        "trainerSharePercentage": 50,
        "centerSharePercentage": 50
    },
    {
        "id": "crs-1787428009076",
        "code": "CRS-796",
        "name": "ICT-S2",
        "branchId": "branch-1",
        "hoursCount": 8,
        "lecturesCount": 64,
        "feeAmount": 250,
        "trainerPercentage": 40,
        "centerPercentage": 60,
        "startDate": "",
        "endDate": "",
        "maxTrainees": 20,
        "status": "active",
        "description": "دورة منهج الحاسب الالي الصف الثاني الثانوي",
        "category": "دورة منهج ICT",
        "billingType": "monthly",
        "trainerSharePercentage": 50,
        "centerSharePercentage": 50
    },
    {
        "id": "crs-1787428039994",
        "code": "CRS-131",
        "name": "ICT-S3",
        "branchId": "branch-1",
        "hoursCount": 8,
        "lecturesCount": 64,
        "feeAmount": 250,
        "trainerPercentage": 40,
        "centerPercentage": 60,
        "startDate": "",
        "endDate": "",
        "maxTrainees": 20,
        "status": "active",
        "description": "دورة منهج الحاسب الالي الصف الثالث الثانوي",
        "category": "دورة منهج ICT",
        "billingType": "monthly",
        "trainerSharePercentage": 50,
        "centerSharePercentage": 50
    },
    {
        "id": "crs-1787502480417-0ggk",
        "name": "الصف الأول الإعدادي لغات",
        "code": "ICT-p1-L",
        "branchId": "branch-1",
        "category": "المدارس",
        "hoursCount": 20,
        "lecturesCount": 10,
        "feeAmount": 500,
        "status": "active"
    },
    {
        "id": "crs-1787502489944-bf2a",
        "name": "الصف الثاني الإعدادي",
        "code": "ICT-p1",
        "branchId": "branch-1",
        "category": "المدارس",
        "hoursCount": 20,
        "lecturesCount": 10,
        "feeAmount": 500,
        "status": "active"
    },
    {
        "id": "crs-1787502587826-q429",
        "name": "الصف الثالث الإعدادي لغات",
        "code": "ICT-p3-L",
        "branchId": "branch-1",
        "category": "المدارس",
        "hoursCount": 20,
        "lecturesCount": 10,
        "feeAmount": 500,
        "status": "active"
    }
],
  programs: [],
  groups: [
    {
        "id": "grp-1787350487970",
        "name": "ICT4 - 1",
        "branchId": "branch-1",
        "courseId": "course-1787347401956",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "الاثنين",
            "الخميس"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 11,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "الاثنين",
            "الخميس"
        ],
        "startTime": "15:00",
        "endTime": "16:00",
        "maxCapacity": 11,
        "startDate": "",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/LbqSa2quIAt3cvKjOTI5rI",
        "notes": ""
    },
    {
        "id": "grp-1787350488774",
        "name": "ICT4 - 2",
        "branchId": "branch-1",
        "courseId": "course-1787347401956",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "الاثنين",
            "الخميس"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 11,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "الاثنين",
            "الخميس"
        ],
        "startTime": "16:00",
        "endTime": "17:00",
        "maxCapacity": 11,
        "startDate": "2026-09-01",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/LbqSa2quIAt3cvKjOTI5rI",
        "notes": ""
    },
    {
        "id": "grp-1787351870532",
        "name": "ICT4 - 3",
        "branchId": "branch-1",
        "courseId": "course-1787347401956",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "الاثنين",
            "الخميس"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 11,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "الاثنين",
            "الخميس"
        ],
        "startTime": "18:00",
        "endTime": "19:00",
        "maxCapacity": 11,
        "startDate": "2026-09-01",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/LbqSa2quIAt3cvKjOTI5rI",
        "notes": ""
    },
    {
        "id": "grp-1787358559234",
        "name": "ICT - p1 - 1",
        "branchId": "branch-1",
        "courseId": "course-1787347569318",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "الأحد",
            "الأربعاء"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 11,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "الأحد",
            "الأربعاء"
        ],
        "startTime": "15:00",
        "endTime": "16:00",
        "maxCapacity": 11,
        "startDate": "2026-08-22",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/LhAXWwUy35uJaFODxXZfdH",
        "notes": ""
    },
    {
        "id": "grp-1787358595611",
        "name": "ICT - p1 - 2",
        "branchId": "branch-1",
        "courseId": "course-1787347569318",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "الأربعاء"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 11,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "الأربعاء"
        ],
        "startTime": "16:00",
        "endTime": "17:00",
        "maxCapacity": 11,
        "startDate": "2026-09-01",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/LhAXWwUy35uJaFODxXZfdH",
        "notes": ""
    },
    {
        "id": "grp-1787358828709",
        "name": "ICT - p1 - 3",
        "branchId": "branch-1",
        "courseId": "course-1787347569318",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "الاثنين",
            "الخميس"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 11,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "الاثنين",
            "الخميس"
        ],
        "startTime": "17:00",
        "endTime": "18:00",
        "maxCapacity": 11,
        "startDate": "2026-08-22",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/LhAXWwUy35uJaFODxXZfdH",
        "notes": ""
    },
    {
        "id": "grp-1787431608023",
        "name": "ICT5 - 1",
        "branchId": "branch-1",
        "courseId": "course-1787347462419",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "الاثنين",
            "الخميس"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 11,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "الاثنين",
            "الخميس"
        ],
        "startTime": "14:00",
        "endTime": "15:00",
        "maxCapacity": 11,
        "startDate": "2026-08-22",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/FoJVTjwgWDtLNEE4X38Qo3",
        "notes": ""
    },
    {
        "id": "grp-1787431802246",
        "name": "ICT6 - 1",
        "branchId": "branch-1",
        "courseId": "course-1787347508908",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "الأحد",
            "الأربعاء"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 11,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "الأحد",
            "الأربعاء"
        ],
        "startTime": "14:00",
        "endTime": "15:00",
        "maxCapacity": 11,
        "startDate": "2026-09-01",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/JjcTmBV8vnnKh9nhVTnQD1",
        "notes": ""
    },
    {
        "id": "grp-1787431825818",
        "name": "ICT6 - 2",
        "branchId": "branch-1",
        "courseId": "course-1787347508908",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "الأحد",
            "الأربعاء"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 11,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "الأحد",
            "الأربعاء"
        ],
        "startTime": "17:00",
        "endTime": "18:00",
        "maxCapacity": 11,
        "startDate": "2026-09-01",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/JjcTmBV8vnnKh9nhVTnQD1",
        "notes": ""
    },
    {
        "id": "grp-1787432103884",
        "name": "ICT4 - B1",
        "branchId": "branch-2",
        "courseId": "course-1787347401956",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "السبت",
            "الثلاثاء"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 12,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "السبت",
            "الثلاثاء"
        ],
        "startTime": "18:00",
        "endTime": "19:00",
        "maxCapacity": 12,
        "startDate": "2026-09-01",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/LbqSa2quIAt3cvKjOTI5rI",
        "notes": "",
        "feeAmount": 250
    },
    {
        "id": "grp-1787432635686",
        "name": "ICT5 - B1",
        "branchId": "branch-2",
        "courseId": "course-1787347462419",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "السبت",
            "الثلاثاء"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 12,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "السبت",
            "الثلاثاء"
        ],
        "startTime": "15:00",
        "endTime": "16:00",
        "maxCapacity": 12,
        "startDate": "2026-09-01",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/FoJVTjwgWDtLNEE4X38Qo3",
        "notes": "",
        "feeAmount": 250
    },
    {
        "id": "grp-1787433082510",
        "name": "ICT6 - B1",
        "branchId": "branch-2",
        "courseId": "course-1787347508908",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "الثلاثاء"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 12,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "الثلاثاء"
        ],
        "startTime": "16:00",
        "endTime": "17:00",
        "maxCapacity": 12,
        "startDate": "2026-09-01",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/JjcTmBV8vnnKh9nhVTnQD1",
        "notes": "",
        "feeAmount": 250
    },
    {
        "id": "grp-1787433160347",
        "name": "ICT - p1 - B1",
        "branchId": "branch-2",
        "courseId": "course-1787347569318",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "السبت",
            "الثلاثاء"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 12,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "السبت",
            "الثلاثاء"
        ],
        "startTime": "17:00",
        "endTime": "18:00",
        "maxCapacity": 12,
        "startDate": "2026-09-01",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/LhAXWwUy35uJaFODxXZfdH",
        "notes": "",
        "feeAmount": 250
    },
    {
        "id": "grp-1787433234491",
        "name": "ICT - S1 - B1",
        "branchId": "branch-2",
        "courseId": "course-1787347569318",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "السبت",
            "الثلاثاء"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 12,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "السبت",
            "الثلاثاء"
        ],
        "startTime": "14:00",
        "endTime": "15:00",
        "maxCapacity": 12,
        "startDate": "2026-09-01",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/GTFUoMgvlkQ413pntoZAT9",
        "notes": "",
        "feeAmount": 250
    },
    {
        "id": "grp-1787433327552",
        "name": "ICT - S2 - B1",
        "branchId": "branch-2",
        "courseId": "course-1787347569318",
        "trainerId": "trainer-1787349806643",
        "hallName": "قاعة 1",
        "days": [
            "السبت",
            "الثلاثاء"
        ],
        "timeSlot": "04:00 م - 06:00 م",
        "maxStudents": 12,
        "status": "active",
        "roomName": "قاعة 1",
        "scheduleDays": [
            "السبت",
            "الثلاثاء"
        ],
        "startTime": "19:00",
        "endTime": "20:00",
        "maxCapacity": 12,
        "startDate": "2026-08-22",
        "endDate": "",
        "whatsappGroupLink": "https://chat.whatsapp.com/GTFUoMgvlkQ413pntoZAT9",
        "notes": "",
        "feeAmount": 250
    },
    {
        "id": "grp-1787502480417-ltuf",
        "name": "ICT-p1-L - 1",
        "branchId": "branch-1",
        "courseId": "crs-1787502480417-0ggk",
        "maxStudents": 10,
        "maxCapacity": 10,
        "status": "active",
        "days": [
            "الجمعة"
        ],
        "timeSlot": "04:00 م - 06:00 م"
    },
    {
        "id": "grp-1787502489945-o2sh",
        "name": "ICT-p1 - 1",
        "branchId": "branch-1",
        "courseId": "crs-1787502489944-bf2a",
        "maxStudents": 12,
        "maxCapacity": 12,
        "status": "active",
        "days": [
            "الجمعة"
        ],
        "timeSlot": "04:00 م - 06:00 م"
    },
    {
        "id": "grp-1787502587826-wvu7",
        "name": "ICT-p3-L - 1",
        "branchId": "branch-1",
        "courseId": "crs-1787502587826-q429",
        "maxStudents": 10,
        "maxCapacity": 10,
        "status": "active",
        "days": [
            "الجمعة"
        ],
        "timeSlot": "04:00 م - 06:00 م"
    }
],
  attendance: [
    {
        "id": "att-1787466295224-u89e",
        "date": "2026-08-23",
        "time": "٠٦:٢٤ ص",
        "branchId": "branch-1",
        "groupId": "grp-1787350487970",
        "courseId": "course-1787347401956",
        "traineeId": "trainee-1787459300939-62ly",
        "status": "present",
        "notes": "تسجيل حضور تلقائي من جهاز المعمل (جهاز PC-83 - IP: ais-dev-7wkppak7c63am6ebvulppu-481160813332.europe-west2.run.app)"
    },
    {
        "id": "att-1787464456274-6gb2",
        "date": "2026-08-23",
        "time": "٠٥:٥٤ ص",
        "branchId": "branch-1",
        "groupId": "grp-1787358595611",
        "courseId": "course-1787347569318",
        "traineeId": "trainee-1787361330810-d1if",
        "status": "present",
        "notes": "تسجيل حضور تلقائي من جهاز المعمل (جهاز PC-83 - IP: ais-dev-7wkppak7c63am6ebvulppu-481160813332.europe-west2.run.app)"
    }
],
  payments: [],
  expenses: [],
  trainerSettlements: [],
  pointRules: defaultPointRules,
  pointTransactions: [
    {
        "id": "pt-1787466295224",
        "traineeId": "trainee-1787459300939-62ly",
        "groupId": "grp-1787350487970",
        "branchId": "branch-1",
        "points": 10,
        "reason": "حضور المحاضرة عبر جهاز المعمل (جهاز PC-83)",
        "ruleId": "rule-1",
        "addedByUserId": "system",
        "addedByUserName": "النظام الآلي للمعمل",
        "createdAt": "2026-08-23T06:24:55.224Z"
    },
    {
        "id": "pt-reinf-1787465508933-s3j0",
        "traineeId": "trainee-1787361330810-d1if",
        "groupId": "grp-1787358595611",
        "branchId": "branch-1",
        "points": 16,
        "reason": "[تعزيز وتحفيز مباشر]: مشاركة وتعاون متميز! - دعم ومساعدة الزملاء في حل التحديات البرمجية!",
        "addedByUserId": "trainer",
        "addedByUserName": "المدرب",
        "createdAt": "2026-08-23T06:11:48.933Z"
    },
    {
        "id": "pt-1787464456275",
        "traineeId": "trainee-1787361330810-d1if",
        "groupId": "grp-1787358595611",
        "branchId": "branch-1",
        "points": 10,
        "reason": "حضور المحاضرة عبر جهاز المعمل (جهاز PC-83)",
        "ruleId": "rule-1",
        "addedByUserId": "system",
        "addedByUserName": "النظام الآلي للمعمل",
        "createdAt": "2026-08-23T05:54:16.275Z"
    },
    {
        "id": "pt-1787459955413-444o",
        "traineeId": "trainee-1787361410293-aeko",
        "groupId": "grp-1787431608023",
        "branchId": "branch-1",
        "points": 100,
        "reason": "مشاركة ممتازة وتسليم المشروع العملي",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-23T04:39:15.413Z"
    },
    {
        "id": "pt-1787459946569-3pse",
        "traineeId": "trainee-1787459300939-62ly",
        "groupId": "grp-1787350487970",
        "branchId": "branch-1",
        "points": 100,
        "reason": "مشاركة ممتازة وتسليم المشروع العملي",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-23T04:39:06.569Z"
    },
    {
        "id": "pt-1787459938649-2nop",
        "traineeId": "trainee-1787459300939-62ly",
        "groupId": "grp-1787350487970",
        "branchId": "branch-1",
        "points": 23,
        "reason": "مشاركة ممتازة وتسليم المشروع العملي",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-23T04:38:58.649Z"
    },
    {
        "id": "pt-1787430858701-5izp",
        "traineeId": "trainee-1787361330810-d1if",
        "groupId": "grp-1787358595611",
        "branchId": "branch-1",
        "points": 100,
        "reason": "إنجاز أسطوري وجائزة التميز الكبرى",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T20:34:18.701Z"
    },
    {
        "id": "pt-reinf-1787362796188-3kij",
        "traineeId": "trainee-1787361330810-d1if",
        "groupId": "grp-1787358595611",
        "branchId": "branch-1",
        "points": 51,
        "reason": "[تعزيز وتحفيز مباشر]: تحية وتشجيع لجميع متدربي القاعة! 🚀 - تفاعل ممتاز وجهد جماعي رائع في هذا التمرين التدريبي!",
        "addedByUserId": "trainer",
        "addedByUserName": "المدرب",
        "createdAt": "2026-08-22T01:39:56.188Z"
    },
    {
        "id": "pt-1787362695962-fjl7",
        "traineeId": "trainee-1787361410293-aeko",
        "groupId": "grp-1787358559234",
        "branchId": "branch-1",
        "points": 15,
        "reason": "إجابة صحيحة في الجلسة التفاعلية",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-22T01:38:15.962Z"
    },
    {
        "id": "pt-1787362526303-m12r",
        "traineeId": "trainee-1787361410293-aeko",
        "groupId": "grp-1787358559234",
        "branchId": "branch-1",
        "points": 10,
        "reason": "مشاركة ممتازة وتسليم المشروع العملي",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-22T01:35:26.303Z"
    },
    {
        "id": "pt-1787362380117-64xv",
        "traineeId": "trainee-1787361410293-aeko",
        "groupId": "grp-1787358559234",
        "branchId": "branch-1",
        "points": 15,
        "reason": "إجابة صحيحة في الجلسة التفاعلية",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-22T01:33:00.117Z"
    },
    {
        "id": "pt-1787362271687",
        "traineeId": "trainee-1787361410293-aeko",
        "groupId": "grp-1787358559234",
        "branchId": "branch-1",
        "points": 10,
        "reason": "حضور المحاضرة عبر جهاز المعمل (جهاز PC-71)",
        "ruleId": "rule-1",
        "addedByUserId": "system",
        "addedByUserName": "النظام الآلي للمعمل",
        "createdAt": "2026-08-22T01:31:11.687Z"
    },
    {
        "id": "pt-reinf-1787362006056-suqi",
        "traineeId": "trainee-1787361330810-d1if",
        "groupId": "grp-1787358595611",
        "branchId": "branch-1",
        "points": 51,
        "reason": "[تعزيز وتحفيز مباشر]: تحية وتشجيع لجميع متدربي القاعة! 🚀 - تفاعل ممتاز وجهد جماعي رائع في هذا التمرين التدريبي!",
        "addedByUserId": "trainer",
        "addedByUserName": "المدرب",
        "createdAt": "2026-08-22T01:26:46.056Z"
    },
    {
        "id": "pt-1787361922519",
        "traineeId": "trainee-1787361330810-d1if",
        "groupId": "grp-1787358595611",
        "branchId": "branch-1",
        "points": 10,
        "reason": "حضور المحاضرة عبر جهاز المعمل (جهاز PC-71)",
        "ruleId": "rule-1",
        "addedByUserId": "system",
        "addedByUserName": "النظام الآلي للمعمل",
        "createdAt": "2026-08-22T01:25:22.519Z"
    },
    {
        "id": "pt-1787361433577-8oxr",
        "traineeId": "trainee-1787361410293-aeko",
        "groupId": "grp-1787358559234",
        "branchId": "branch-1",
        "points": 30,
        "reason": "إجابة نموذجية وسرعة بديهة",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T01:17:13.577Z"
    },
    {
        "id": "pt-1787361426705-x0vc",
        "traineeId": "trainee-1787361330810-d1if",
        "groupId": "grp-1787358595611",
        "branchId": "branch-1",
        "points": 30,
        "reason": "إجابة نموذجية وسرعة بديهة",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T01:17:06.705Z"
    },
    {
        "id": "pt-1787360877177",
        "traineeId": "trainee-1787352042655-o2znr",
        "branchId": "branch-1",
        "points": 10,
        "reason": "حضور المحاضرة عبر جهاز المعمل (جهاز PC-71)",
        "ruleId": "rule-1",
        "addedByUserId": "system",
        "addedByUserName": "النظام الآلي للمعمل",
        "createdAt": "2026-08-22T01:07:57.177Z"
    },
    {
        "id": "pt-1787359878296",
        "traineeId": "trainee-1787352042655-bkzr9",
        "groupId": "grp-1787358559234",
        "branchId": "branch-1",
        "points": 10,
        "reason": "حضور المحاضرة عبر جهاز المعمل (جهاز PC-71)",
        "ruleId": "rule-1",
        "addedByUserId": "system",
        "addedByUserName": "النظام الآلي للمعمل",
        "createdAt": "2026-08-22T00:51:18.296Z"
    },
    {
        "id": "pt-1787359713319",
        "traineeId": "trainee-1787352042654-aj70e",
        "groupId": "",
        "branchId": "branch-1",
        "points": 10,
        "reason": "حضور المحاضرة عبر جهاز المعمل (جهاز PC-71)",
        "ruleId": "rule-1",
        "addedByUserId": "system",
        "addedByUserName": "النظام الآلي للمعمل",
        "createdAt": "2026-08-22T00:48:33.319Z"
    },
    {
        "id": "pt-1787356997939-907a",
        "traineeId": "trainee-1787352054266-40z66",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-59aa",
        "traineeId": "trainee-1787352054266-s4ys4",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-ubxr",
        "traineeId": "trainee-1787352054266-jijye",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-pk4l",
        "traineeId": "trainee-1787352054266-1fxlt",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-5mia",
        "traineeId": "trainee-1787352054266-te1p2",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-fua0",
        "traineeId": "trainee-1787352054266-ab5pp",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-r3p6",
        "traineeId": "trainee-1787352054266-whiuc",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-z7py",
        "traineeId": "trainee-1787352054265-b1r9p",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-jin9",
        "traineeId": "trainee-1787352054265-mvg2v",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-k78n",
        "traineeId": "trainee-1787352054265-e68mx",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-r8hk",
        "traineeId": "trainee-1787352054265-tnqmk",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-6tg2",
        "traineeId": "trainee-1787352054265-89sik",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-mehg",
        "traineeId": "trainee-1787352054265-s3igz",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-v46t",
        "traineeId": "trainee-1787352054265-jd4tp",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-7ffv",
        "traineeId": "trainee-1787352054265-hx8no",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-a2vo",
        "traineeId": "trainee-1787352054265-i39ds",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-p4jl",
        "traineeId": "trainee-1787352054265-h6wwj",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-b4g6",
        "traineeId": "trainee-1787352054265-x6x9f",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-rfh1",
        "traineeId": "trainee-1787352054264-rv552",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-4wwh",
        "traineeId": "trainee-1787352054264-zxwq0",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997939-1jqb",
        "traineeId": "trainee-1787352054264-kl9ca",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997938-qyyb",
        "traineeId": "trainee-1787352054264-0vyqu",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.939Z"
    },
    {
        "id": "pt-1787356997938-e6it",
        "traineeId": "trainee-1787352054264-b4aee",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-vyhk",
        "traineeId": "trainee-1787352054264-xkezz",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-khrh",
        "traineeId": "trainee-1787352054263-tuyfw",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-2n68",
        "traineeId": "trainee-1787352054263-81qro",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-f7v9",
        "traineeId": "trainee-1787352054263-wuwwn",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-lkua",
        "traineeId": "trainee-1787352054263-e6srh",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-qbe5",
        "traineeId": "trainee-1787352054263-d4hmz",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-tz9l",
        "traineeId": "trainee-1787352054263-2wlgz",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-leow",
        "traineeId": "trainee-1787352054263-zrex8",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-i5ym",
        "traineeId": "trainee-1787352054262-fehxv",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-rhmr",
        "traineeId": "trainee-1787352054262-hvrlu",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-lvks",
        "traineeId": "trainee-1787352042663-wgwj3",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-z072",
        "traineeId": "trainee-1787352042663-jye60",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-g4qj",
        "traineeId": "trainee-1787352042663-lrb0e",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-ik96",
        "traineeId": "trainee-1787352042662-kh71r",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-cqb3",
        "traineeId": "trainee-1787352042662-58hi5",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-216e",
        "traineeId": "trainee-1787352042662-b5noo",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-k6tj",
        "traineeId": "trainee-1787352042662-avarj",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-mjlw",
        "traineeId": "trainee-1787352042662-t70xe",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-07j9",
        "traineeId": "trainee-1787352042662-b9go0",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-q89t",
        "traineeId": "trainee-1787352042662-z17c5",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-0cjj",
        "traineeId": "trainee-1787352042662-3tq3x",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-gme9",
        "traineeId": "trainee-1787352042661-yss51",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-i9yq",
        "traineeId": "trainee-1787352042661-vllz8",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-0cc2",
        "traineeId": "trainee-1787352042661-2h51r",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-n4r6",
        "traineeId": "trainee-1787352042661-4ky49",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-g88v",
        "traineeId": "trainee-1787352042661-gatx4",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-yr8d",
        "traineeId": "trainee-1787352042661-kwgj5",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-fd0x",
        "traineeId": "trainee-1787352042661-bn13o",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-v49t",
        "traineeId": "trainee-1787352042661-lazq8",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-985m",
        "traineeId": "trainee-1787352042661-5wiuu",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-9s5r",
        "traineeId": "trainee-1787352042660-83zkl",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-lciy",
        "traineeId": "trainee-1787352042660-3jdfj",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-s8uv",
        "traineeId": "trainee-1787352042660-rc13v",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-se6g",
        "traineeId": "trainee-1787352042660-3pzc7",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-5rl3",
        "traineeId": "trainee-1787352042660-oq0mk",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-4zwj",
        "traineeId": "trainee-1787352042660-fg0l2",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-xc39",
        "traineeId": "trainee-1787352042660-tm3jn",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-fon5",
        "traineeId": "trainee-1787352042660-55ejb",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-00pc",
        "traineeId": "trainee-1787352042660-fvl4h",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-0d04",
        "traineeId": "trainee-1787352042660-rhqwa",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-s81f",
        "traineeId": "trainee-1787352042660-9dlhd",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-s2ix",
        "traineeId": "trainee-1787352042659-ar42s",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-o6wx",
        "traineeId": "trainee-1787352042659-gqgsy",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-nz5m",
        "traineeId": "trainee-1787352042659-jh7kz",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-angs",
        "traineeId": "trainee-1787352042659-e04f9",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-9tib",
        "traineeId": "trainee-1787352042659-vjfom",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-yyio",
        "traineeId": "trainee-1787352042659-evsvu",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-47rb",
        "traineeId": "trainee-1787352042659-30u4t",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-zkpq",
        "traineeId": "trainee-1787352042659-6w8y1",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-ajmv",
        "traineeId": "trainee-1787352042659-iulgm",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-ux8q",
        "traineeId": "trainee-1787352042658-h207g",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-tndb",
        "traineeId": "trainee-1787352042658-ftf8i",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-9pqe",
        "traineeId": "trainee-1787352042658-sthr3",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-q0rl",
        "traineeId": "trainee-1787352042658-ch8fv",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-zt8u",
        "traineeId": "trainee-1787352042658-ghc76",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-89ri",
        "traineeId": "trainee-1787352042658-1n9q9",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-weog",
        "traineeId": "trainee-1787352042657-1a5h3",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-2e73",
        "traineeId": "trainee-1787352042657-2qd5a",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-4dp6",
        "traineeId": "trainee-1787352042657-8fcyh",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-hvnv",
        "traineeId": "trainee-1787352042657-q46jv",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-125j",
        "traineeId": "trainee-1787352042656-rv47j",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-bv2g",
        "traineeId": "trainee-1787352042656-jn14r",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-kag7",
        "traineeId": "trainee-1787352042656-gud54",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-i9tu",
        "traineeId": "trainee-1787352042656-l3txa",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-fs6o",
        "traineeId": "trainee-1787352042655-3lihh",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-1s9h",
        "traineeId": "trainee-1787352042655-o2znr",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-ft81",
        "traineeId": "trainee-1787352042655-bkzr9",
        "groupId": "",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-vzcx",
        "traineeId": "trainee-1787352042654-pluyz",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-ll3o",
        "traineeId": "trainee-1787352042654-aj70e",
        "groupId": "",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-1787356997938-4g1k",
        "traineeId": "trainee-1787347185722-0aw8",
        "groupId": "",
        "branchId": "branch-1",
        "points": 30,
        "reason": "سلوك راقٍ ومساعدة الزملاء",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-22T00:03:17.938Z"
    },
    {
        "id": "pt-reinf-1787356402355-8ix9",
        "traineeId": "trainee-1787347185722-0aw8",
        "groupId": "",
        "branchId": "branch-1",
        "points": 6,
        "reason": "[تعزيز وتحفيز مباشر]: تقدير وتميز للمتدرب (جهاز PC-71) 🌟 - إجابة متقنة وتطبيق عملي متميز خلال التمرين!",
        "addedByUserId": "trainer",
        "addedByUserName": "المدرب",
        "createdAt": "2026-08-21T23:53:22.355Z"
    },
    {
        "id": "pt-reinf-1787356276902-zudl",
        "traineeId": "trainee-1787347185722-0aw8",
        "groupId": "",
        "branchId": "branch-1",
        "points": 21,
        "reason": "[تعزيز وتحفيز مباشر]: إجابة نموذجية وإبداع برمجي! - طريقة تفكير وحل استثنائي يستحق الإشادة!",
        "addedByUserId": "trainer",
        "addedByUserName": "المدرب",
        "createdAt": "2026-08-21T23:51:16.902Z"
    },
    {
        "id": "pt-1787356160111-dw3h",
        "traineeId": "trainee-1787352042654-pluyz",
        "branchId": "branch-1",
        "points": 50,
        "reason": "تفوق واختبار متميز 🌟",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-21T23:49:20.111Z"
    },
    {
        "id": "pt-1787356156650-h18e",
        "traineeId": "trainee-1787352042654-aj70e",
        "groupId": "",
        "branchId": "branch-1",
        "points": 50,
        "reason": "تفوق واختبار متميز 🌟",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-21T23:49:16.650Z"
    },
    {
        "id": "pt-1787355883695-uifc",
        "traineeId": "trainee-1787347185722-0aw8",
        "groupId": "",
        "branchId": "branch-1",
        "points": 30,
        "reason": "إجابة نموذجية وسرعة بديهة",
        "addedByUserId": "user-admin",
        "addedByUserName": "مدير عام النظام",
        "createdAt": "2026-08-21T23:44:43.695Z"
    },
    {
        "id": "pt-1787352904987",
        "traineeId": "trainee-1787347185722-0aw8",
        "branchId": "branch-1",
        "points": 10,
        "reason": "حضور المحاضرة عبر جهاز المعمل (جهاز PC-71)",
        "ruleId": "rule-1",
        "addedByUserId": "system",
        "addedByUserName": "النظام الآلي للمعمل",
        "createdAt": "2026-08-21T22:55:04.987Z"
    },
    {
        "id": "pt-1787352484632-vnjm",
        "traineeId": "trainee-1787352042654-aj70e",
        "groupId": "",
        "branchId": "branch-1",
        "points": 15,
        "reason": "مشاركة ممتازة وتسليم المشروع العملي",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-21T22:48:04.632Z"
    },
    {
        "id": "pt-1787352471508-uvf6",
        "traineeId": "trainee-1787352042654-aj70e",
        "groupId": "",
        "branchId": "branch-1",
        "points": 10,
        "reason": "مشاركة ممتازة وتسليم المشروع العملي",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-21T22:47:51.508Z"
    },
    {
        "id": "pt-1787350954168-igdw",
        "traineeId": "trainee-1787347185722-0aw8",
        "branchId": "branch-1",
        "points": 10,
        "reason": "مشاركة ممتازة وتسليم المشروع العملي",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-21T22:22:34.168Z"
    },
    {
        "id": "pt-1787349991130-8r97",
        "traineeId": "trainee-1787347185722-0aw8",
        "branchId": "branch-1",
        "points": 15,
        "reason": "مشاركة ممتازة وتسليم المشروع العملي",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-21T22:06:31.130Z"
    },
    {
        "id": "pt-1787349976876-o45n",
        "traineeId": "trainee-1787347185722-0aw8",
        "branchId": "branch-1",
        "points": 10,
        "reason": "مشاركة ممتازة وتسليم المشروع العملي",
        "addedByUserId": "admin",
        "addedByUserName": "مسؤول النقاط",
        "createdAt": "2026-08-21T22:06:16.876Z"
    },
    {
        "id": "pt-1787446474044",
        "traineeId": "trainee-1787361330810-d1if",
        "groupId": "grp-1787358595611",
        "branchId": "branch-1",
        "points": 55,
        "reason": "تسليم واجب: واجب تطبيق الدرس العملي والمشروع الرئيسي (تقييم ذكي: 100%)",
        "ruleId": "rule-3",
        "addedByUserId": "ai-engine",
        "addedByUserName": "نظام تصحيح الذكاء الاصطناعي",
        "createdAt": "2026-08-23T00:54:34.044Z"
    },
    {
        "id": "pt-1787451229685-5xl3",
        "traineeId": "trainee-1787361410293-aeko",
        "groupId": "grp-1787431608023",
        "branchId": "branch-1",
        "points": 20,
        "reason": "⭐ مكافأة إتقان (واجب تطبيق الدرس - الكتاب المدرسي): درجة 90/100 (90%)",
        "addedByUserId": "ai-scanner",
        "addedByUserName": "مصحح الذكاء الاصطناعي",
        "createdAt": "2026-08-23T02:13:49.685Z"
    }
],
  exams: [
    {
        "id": "exam-1787446743699",
        "title": "امتحان مادة تكنولوجيا المعلومات والاتصالات - الصف الخامس الابتدائي - الفصل الدراسي الأول",
        "branchId": "branch-1",
        "courseId": "course-1787347401956",
        "examDate": "2026-08-23",
        "totalMarks": 100,
        "passingMarks": 50,
        "durationMinutes": 90,
        "status": "scheduled",
        "instructions": "اختبار شامل لمادة تكنولوجيا المعلومات والاتصالات للصف الخامس الابتدائي، يغطي المفاهيم الأساسية لشبكات الإنترنت والإنترانت، مكونات الحاسوب ووحدات القياس، حماية حقوق النشر، التمييز بين الحقائق والآراء، استخدام برامج Microsoft Office، ومفاهيم الأمان الرقمي والتوصيل."
    },
    {
        "id": "hw-scan-1787451229685",
        "title": "واجب تطبيق الدرس - الكتاب المدرسي",
        "courseId": "course-1787347401956",
        "groupId": "grp-1787431608023",
        "branchId": "branch-1",
        "examDate": "2026-08-23",
        "totalMarks": 100,
        "passingMarks": 60,
        "durationMinutes": 30,
        "status": "completed",
        "instructions": "تصحيح ورقي آلي عبر الماسح الذكي وكود المتدرب"
    },
    {
        "id": "exam-1787463526231",
        "title": "الاختبار القبلي للدورة",
        "branchId": "branch-1",
        "courseId": "course-1787347401956",
        "examDate": "2026-08-23",
        "totalMarks": 100,
        "durationMinutes": 60,
        "status": "scheduled",
        "instructions": "يرجى الإجابة عن جميع الأسئلة والالتزام بالوقت المحدد."
    }
],
  questions: [
    {
        "id": "q-1787446743699-0-m40",
        "examId": "exam-1787446743699",
        "questionType": "mcq",
        "questionText": "يتم استخدام حرف ........ داخل دائرة وهو الرمز الدولي لحماية حقوق النشر.",
        "options": [
            "A",
            "B",
            "C",
            "D"
        ],
        "correctAnswer": "C",
        "marks": 5
    },
    {
        "id": "q-1787446743699-1-0ij",
        "examId": "exam-1787446743699",
        "questionType": "mcq",
        "questionText": "..... هي بوابة تستخدم لتوصيل جهاز الكمبيوتر بالإنترنت.",
        "options": [
            "word",
            "الراوتر",
            "بنك المعرفة المصري",
            "لوحة المفاتيح"
        ],
        "correctAnswer": "الراوتر",
        "marks": 5
    },
    {
        "id": "q-1787446743699-2-rg3",
        "examId": "exam-1787446743699",
        "questionType": "mcq",
        "questionText": "........ وحدة قياس لعدد الدورات التي تنفذها وحدة المعالجة المركزية في الثانية.",
        "options": [
            "ميجابايت في الثانية",
            "جيجا هرتز",
            "بايت",
            "كيلوبايت"
        ],
        "correctAnswer": "جيجا هرتز",
        "marks": 5
    },
    {
        "id": "q-1787446743699-3-van",
        "examId": "exam-1787446743699",
        "questionType": "mcq",
        "questionText": "لحل مشكلة بطء التحميل.............",
        "options": [
            "أعد تشغيل الكمبيوتر والراوتر",
            "حذف برنامج word",
            "تحديث النظام",
            "إيقاف تشغيل الشاشة"
        ],
        "correctAnswer": "أعد تشغيل الكمبيوتر والراوتر",
        "marks": 5
    },
    {
        "id": "q-1787446743699-4-v64",
        "examId": "exam-1787446743699",
        "questionType": "mcq",
        "questionText": "يستخدم ............. لمشاركة المعلومات عبر شبكة مغلقة، وهو أكثر أماناً.",
        "options": [
            "الإنترنت",
            "الإنترانت",
            "الويب",
            "وسائل التواصل الاجتماعي"
        ],
        "correctAnswer": "الإنترانت",
        "marks": 5
    },
    {
        "id": "q-1787446743699-5-ppk",
        "examId": "exam-1787446743699",
        "questionType": "true_false",
        "questionText": "WWW هو اختصار لـ world wide web.",
        "options": [
            "صح",
            "خطأ"
        ],
        "correctAnswer": "صح",
        "marks": 5
    },
    {
        "id": "q-1787446743699-6-pyf",
        "examId": "exam-1787446743699",
        "questionType": "true_false",
        "questionText": "مواقع التسوق المزيفة ترسل لك العناصر الصحيحة التي قمت بشرائها.",
        "options": [
            "صح",
            "خطأ"
        ],
        "correctAnswer": "خطأ",
        "marks": 5
    },
    {
        "id": "q-1787446743699-7-22x",
        "examId": "exam-1787446743699",
        "questionType": "true_false",
        "questionText": "واحدة من المشكلات الشائعة التي تواجهها عند استخدام الكمبيوتر والإنترنت هي بطء التحميل.",
        "options": [
            "صح",
            "خطأ"
        ],
        "correctAnswer": "صح",
        "marks": 5
    },
    {
        "id": "q-1787446743699-8-xpd",
        "examId": "exam-1787446743699",
        "questionType": "true_false",
        "questionText": "يمكننا ترتيب المعلومات أبجدياً في برنامج Excel باستخدام خاصية Sort.",
        "options": [
            "صح",
            "خطأ"
        ],
        "correctAnswer": "صح",
        "marks": 5
    },
    {
        "id": "q-1787446743699-9-n8l",
        "examId": "exam-1787446743699",
        "questionType": "true_false",
        "questionText": "مواقع الجوائز والمكافآت تقدم عروضاً مالية كبيرة وجوائز غير حقيقية.",
        "options": [
            "صح",
            "خطأ"
        ],
        "correctAnswer": "صح",
        "marks": 5
    },
    {
        "id": "q-1787446743699-10-7gz",
        "examId": "exam-1787446743699",
        "questionType": "short_answer",
        "questionText": "البايت هو وحدة قياس مساحة ............ بجهاز الكمبيوتر.",
        "options": [],
        "correctAnswer": "التخزين",
        "marks": 5
    },
    {
        "id": "q-1787446743699-11-8lm",
        "examId": "exam-1787446743699",
        "questionType": "short_answer",
        "questionText": "يستخدم برنامج ................ لكتابة التقارير.",
        "options": [],
        "correctAnswer": "Word",
        "marks": 5
    },
    {
        "id": "q-1787446743699-12-9c7",
        "examId": "exam-1787446743699",
        "questionType": "short_answer",
        "questionText": "يستخدم ................ الإنترنت لاقتحام أنظمة الكمبيوتر وسرقة المعلومات.",
        "options": [],
        "correctAnswer": "المخترقون",
        "marks": 5
    },
    {
        "id": "q-1787446743699-13-khg",
        "examId": "exam-1787446743699",
        "questionType": "short_answer",
        "questionText": "تستند الآراء إلى وجهة ............ الشخص وخبراته.",
        "options": [],
        "correctAnswer": "نظر",
        "marks": 5
    },
    {
        "id": "q-1787446743699-14-jvs",
        "examId": "exam-1787446743699",
        "questionType": "short_answer",
        "questionText": "يستخدم برنامج ................ لعمل الجداول الحسابية.",
        "options": [],
        "correctAnswer": "Excel",
        "marks": 5
    },
    {
        "id": "q-1787446743699-15-k02",
        "examId": "exam-1787446743699",
        "questionType": "mcq",
        "questionText": "1 جيجابايت تساوي:",
        "options": [
            "1024 ميجابايت",
            "1000 بايت",
            "1024 كيلوبايت",
            "8 بت"
        ],
        "correctAnswer": "1024 ميجابايت",
        "marks": 5
    },
    {
        "id": "q-1787446743699-16-2lq",
        "examId": "exam-1787446743699",
        "questionType": "mcq",
        "questionText": "سلك إيثرنت (Ethernet):",
        "options": [
            "هو سلك يربط جهاز الكمبيوتر بجهاز التوجيه (الراوتر)",
            "هي خدمة الإنترنت التي تقدمها الشركات المصرية",
            "تساعد المكفوفين على القراءة",
            "إدخال الصور والرسوم للكمبيوتر"
        ],
        "correctAnswer": "هو سلك يربط جهاز الكمبيوتر بجهاز التوجيه (الراوتر)",
        "marks": 5
    },
    {
        "id": "q-1787446743699-17-1qr",
        "examId": "exam-1787446743699",
        "questionType": "mcq",
        "questionText": "مزود خدمة الإنترنت (ISP):",
        "options": [
            "هي خدمة الإنترنت التي تقدمها الشركات للمستخدمين",
            "إدخال الصور والرسوم للكمبيوتر",
            "تساعد المكفوفين على القراءة",
            "وحدة قياس سرعة المعالج"
        ],
        "correctAnswer": "هي خدمة الإنترنت التي تقدمها الشركات للمستخدمين",
        "marks": 5
    },
    {
        "id": "q-1787446743699-18-blv",
        "examId": "exam-1787446743699",
        "questionType": "mcq",
        "questionText": "طريقة برايل (Braille):",
        "options": [
            "تساعد المكفوفين على القراءة",
            "إدخال الصور والرسوم للكمبيوتر",
            "سلك لربط الأجهزة",
            "برنامج للجداول الحسابية"
        ],
        "correctAnswer": "تساعد المكفوفين على القراءة",
        "marks": 5
    },
    {
        "id": "q-1787446743699-19-e3v",
        "examId": "exam-1787446743699",
        "questionType": "mcq",
        "questionText": "الماسح الضوئي (Scanner):",
        "options": [
            "إدخال الصور والرسوم للكمبيوتر",
            "تساعد المكفوفين على القراءة",
            "خدمة تزويد الإنترنت",
            "وحدة تخزين للبيانات"
        ],
        "correctAnswer": "إدخال الصور والرسوم للكمبيوتر",
        "marks": 5
    }
],
  examResults: [
    {
        "id": "res-1787451229685-hea2",
        "examId": "hw-scan-1787451229685",
        "traineeId": "trainee-1787361410293-aeko",
        "traineeName": "رفيف محمد رمضان بخيت",
        "score": 90,
        "totalMarks": 100,
        "percentage": 90,
        "status": "passed",
        "rating": "ممتاز",
        "notes": "أداء رائع ومتميز جداً! تم فحص وتصحيح الصفحة وإضافة الدرجات والنقاط التشجيعية إلى الملف بنجاح.",
        "submittedAt": "2026-08-23T02:13:49.685Z"
    }
],
  interactiveSessions: [
    {
        "id": "is-1787362644609",
        "title": "مسابقة التحدي التفاعلي - بايثون وتطوير الويب",
        "platform": "Kahoot",
        "url": "https://kahoot.ithttps://kahoot.it/challenge/04274914?challenge-id=6f2f94ac-6722-4128-b6c1-72224d86b6ff_1787362624408",
        "groupId": "grp-1",
        "branchId": "branch-1",
        "sessionDate": "2026-08-22",
        "notes": "",
        "questions": [
            {
                "id": "q-1787362688971",
                "text": "ما هي الدالة المسؤولة عن تشغيل كود عند تحميل المكون في React؟",
                "options": [
                    "useState()",
                    "useEffect()",
                    "useRef()",
                    "useMemo()"
                ],
                "correctOptionIndex": 1,
                "points": 15,
                "timeLimitSeconds": 30
            }
        ],
        "currentQuestionIndex": 0
    },
    {
        "id": "is-1787362394743",
        "title": "مسابقة التحدي التفاعلي - بايثون وتطوير الويب",
        "platform": "Kahoot",
        "url": "https://kahoot.it",
        "groupId": "grp-1",
        "branchId": "branch-1",
        "sessionDate": "2026-08-22",
        "notes": ""
    },
    {
        "id": "is-1787362337448",
        "title": "مسابقة التحدي التفاعلي - بايثون وتطوير الويب",
        "platform": "Kahoot",
        "url": "https://kahoot.it",
        "groupId": "grp-1",
        "branchId": "branch-1",
        "sessionDate": "2026-08-22",
        "notes": "",
        "questions": [
            {
                "id": "q-1787362348311",
                "text": "ما هي الدالة المسؤولة عن تشغيل كود عند تحميل المكون في React؟",
                "options": [
                    "useState()",
                    "useEffect()",
                    "useRef()",
                    "useMemo()"
                ],
                "correctOptionIndex": 1,
                "points": 15,
                "timeLimitSeconds": 30
            },
            {
                "id": "q-1787362373107",
                "text": "ما هي الدالة المسؤولة عن تشغيل كود عند تحميل المكون في React؟",
                "options": [
                    "useState()",
                    "useEffect()",
                    "useRef()",
                    "useMemo()"
                ],
                "correctOptionIndex": 1,
                "points": 15,
                "timeLimitSeconds": 30
            }
        ],
        "currentQuestionIndex": 1
    }
],
  devices: [
    {
        "id": "dev-1787352892067",
        "deviceId": "PC-71",
        "name": "جهاز PC-71",
        "assignedUser": "رفيف محمد رمضان بخيت",
        "userType": "trainee",
        "branchId": "branch-1",
        "ipAddress": "ais-dev-7wkppak7c63am6ebvulppu-481160813332.europe-west2.run.app",
        "lastHeartbeat": "2026-08-23T06:02:06.440Z",
        "isOnline": false,
        "status": "active",
        "currentTraineeId": "trainee-1787361410293-aeko",
        "lastScreenshotUrl": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAHCAyADASIAAhEBAxEB/8QAGwABAAMBAQEBAAAAAAAAAAAAAAIDBAUBBgf/xABGEAABAwICBgYIBQMCBQMFAAAAAQIDBBEFUhITFCExoQZBUVSRkxUiM2FyksHRMlNxdIE0NsJCsQcWI1XwYpTxJENjouH/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAX/xAAyEQEAAQQBAgQDCAICAwAAAAAAAQIRElEDITEEMkFxE2GBFCKRobHB0fAF4RVyM1Ji/9oADAMBAAIRAxEAPwD8rAB6XIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaqCg29727XTU2gl71Emgi7+CdplXidroxV0NFWzS10rGMWJWo2SBZWvRVS7bJwVU6yeE4LPWYm2p2NqYddZHSSL/02x7/APUi8UTq43TeeOrxHw668+0RFv4jbvHFlTTj3lzKLDp8QSdYNFVgjWRUXi5OxE61K6mlkpVjSRWrrY2yNVrr7l+p9DTJgNAqOpukVWxLaEjYYZGLKt1s690siX4e73lro+j1fVwT+lFbHSoqLA+kkk0mNeqoqqnUqKcp8XVFczjOP/Wf4dPgRNNrxf3h8oxum9rbol1tdVsiG/FMHmwuR+lJHLG2VYkkYu5VREX/AGVDsxRdFGUtVSOxJHOm9ZlQ6kfdm/cjd991lv23TfuMeOYhRz076emqFqE17HpJoK3StGjVWy8LqhqnxNfJyxFNMxHreJjXVJ4qaaJmZi/ylwjfheFPxTXoyohhdCxHIkrrI66oluZtoqDB8Qo6dsmKOpKljXI+JtG6VXb1XSu33f7G6Fej1BHrYMXbLIyndG5jaSRuuVVui3XgvDwHN4qYiaaInL/rP8W6px8PW9Uxb3hxEwmTYKuqdPE1aSVI3xqvrOVVtu/87SVBg0uI0j5oZoke2ZkSROWyuV3X/wCe8+ip6nAKV9bNDjzUnq5dY10lC96Rb1VLN4KqKvHkeVeJ4QlTJXR4uk88j4FcxKV7LuY5Lvva3C+73nnnxfNMzFNM+lvuz8unb363dfgccWmZj8Y+fz9nylMynSrRlbrkiS6O1KIr79Vr7uIrYmQVs0UbZGMY9Wo2W2klu2265rocSpaPF5a2Sj2liq5Y2LJoaKqu5b2Xeh0529Hq+qfXzYw+CWoajliSmeupeqJdb33pdF8T1181VHJeqmbW9OvX2jr9ZcaeOKqbRMXv7fq5VTglXSSTMkWO8MSSqqO3ORVRN3bZVsv6KU0OHT4i6ZsGiqxRrIqLxdbqTtXefRurMEkjdDLjdVO+SN0LqiZkjkaioi6SNVV3KqfqUUzcCoFR9N0iq2KjdGRIYJGLKvU699yJdNy9i9pwp8VyYTE0zl6fdn+HSeGjLpMW94fMg6Ei4UuNyrI+ofh6yOs6H2ip1fi+p4rsLZjEToEqFoUe1XJOjVfbr3JuPb8X/wCZ7X/17vNh82AH0kOF9Hopo6uTHtbCkm9rsPkRrrb1bf8AQ8xDA4EoIWYVrK2V0ivulK+NysVEtZHfiRN29OF9/E4x43jyim0xf1mJiPziHX7PXa/T8Yn9HzrWOeqoxquVEVVsl9ycVOrH0drEmdFVrHSLqHTNWRyLpI3im6516WmosExKnfXYhDQVMMDUmhZA6ZH3ve6pwW1rkaWLo1TLCqY21XRpI17ko5EWRr0tZf0ucOTxlU/+OJtuKZnfra2t93SngiPNMfjEf7/RwMRw9cOkhYs8c2thbKisW9tJOCmNN62OxiOxyV+HwUNW2tSONkSyOicxHLpLZFavuVDZjvSrE51mwxHNip41WJyJGiOkRN2/s4dVjtRzcs4xFN7979Pyt/DnVRR1mZt7dfzu4NXSyUVU+nlVqvYu9WrdF3X3Ke0tFVVqyJTQPmWNivejEvZO0+rw6swxmJNr4MbSOWaJjZaZ2HvluiNRFbdP06ilYeirMUlq6fGtVDI1yajZZV0dJqotlS3acfttUfdmib2/9au+u34dZh0+z098otfcdvxcXEMFmoItdropokbGqujW9leiqicv9jHS0lRXVDaelidLK5FVGt4rZLnaxStoGYfJRUtYtWixQtSTVuZdWK7qX3KiGPBsJxKsrKaajgV7UkRdYi+qyy79JU/DyXsO1HNVHDNXJNtX6emujnVx0zyRTT19uqmbB6umw9tbUIyFj3WjZI6z39SqjeNk679phPrMUiwyropKKmxRtZUxSLskSQOa5qX3xo9dzk7Ou/DjYzw4LSUWFwy48/YnulV8caRq6WZiIl2ql/V9yr2qY4/GRheu95npFpv8rRPWfnPv6NV8H3rU9rd7/v2fNn1XRPonS9IaOWaerlhdHJoIjERbpZF6/wBTk9IZMNlxFsmGOYsTom6aRxLG1H8Fs1eHUfYdAqaphwV07Vh0ZpVVqOeqLZN3Ui9aKfR8LXRXaquLRO3g8XTy00THDN5Tq/8AhlQ09FNO3EahyxxueiK1u+yXPzg/cZpKmaimpl2dFljcxF1q7rpbKfh7mq1ytcioqLZUXih15cL/AHHDwkeIxn4/f6fs8ABxewAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAd3AujnpOFamokdHDezUZxd7xjvRz0ZClTTyOkhvZyP4t950OjON0kVC2iqZWwujVdFz1sjkVb8f1UdJsbpJaF1FTStmdIqaTmLdGoi34/qhzvOT4vxfF/bMbfdv8ASz5IAHR9oAAAAAC1lTURwPp2TyNhkW740eqNcvvTgpUCTET3WJsF9JW1VBKstLO+F7mq1VavFF4oUATTFUWmOhEzE3gABUXUtXUUVQ2opZXRSs4Oau8qc5z3q97lc5y3VV4qp4CWi9/VbzawACoAAAAAAAAvStqm0TqJJ37O5yPWO/q3TrPVxCtV8T1rJ1dD7N2tddnVu37uBnBjCnTWU7SkkfLI6SR7nvct3Oct1Ve1VIgGuzL1FVFRUWypwVDsVPSeqrKdY6iioJZnN0Vqn0yLKv8AK7uRxgc6+KjkmJqi9m6a6qYmInuupauooallRSyuilYt2uapU97pHue9Vc5y3VV61PAdMYve3Vm82sFsNTUU7XtgnkiSRui9GPVqOTsW3FCoCYiekkTbsFs9TUVUiSVM8kz0SyOkerlt2XUqAtF7lw69F0qxzDqFtDSV74qZt7RoxqpvW68U7VOQCo7sfTbpHFfV4m9l+OjGxL8jizTSVE8k0rtKSRyuctrXVVupABbgACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADNrX5uQ1r83IiDLSWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAlrX5uQ1r83IiAJa1+bkNa/NyIgCWtfm5DWvzciIAAAACTWPcl2scqe5D3VSflu8FAgCeqk/Ld4KNVJ+W7wUCAJ6qT8t3go1Un5bvBQIAnqpPy3eCjVSflu8FAgCeqk/Ld4KNVJ+W7wUCAJ6qT8t3go1Un5bvBQIAnqpPy3eCjVSflu8FAgCeqk/Ld4KNVJ+W7wUCAJ6qT8t3go1Un5bvBQIAnqpPy3eCjVSflu8FAgCeqk/Ld4KNVJ+W7wUCAJ6qT8t3go1Un5bvBQIAnqpPy3eCjVSflu8FAgCeqk/Ld4KNVJ+W7wUCAJ6qT8t3go1Un5bvBQIAnqpPy3eCjVSflu8FAgCeqk/Ld4KNVJ+W7wUCAJ6qT8t3go1Un5bvBQIAnqpPy3eCjVSflu8FAgCeqk/Ld4KNVJ+W7wUCAJ6qT8t3go1Un5bvBQIAnqpPy3eCjVSflu8FAgD1zXNWzmqi+9DwACcUMsztGKN8jkS9mNVVsW+j63uc/lr9iTVTHeViJlnBo9H1vc5/LX7D0fW9zn8tfsTOnZjOmcGj0fW9zn8tfsPR9b3Ofy1+wzp2YzpnBo9H1vc5/LX7D0fW9zn8tfsM6dmM6ZwaPR9b3Ofy1+w9H1vc5/LX7DOnZjOmcGj0fW9zn8tfsPR9b3Ofy1+wzp2YzpnBo9H1vc5/LX7D0fW9zn8tfsM6dmM6ZwaPR9b3Ofy1+w9H1vc5/LX7DOnZjOmcGj0fW9zn8tfsPR9b3Ofy1+wzp2YzpnBo9H1vc5/LX7D0fW9zn8tfsM6dmM6ZwaPR9b3Ofy1+w9H1vc5/LX7DOnZjOmcGj0fW9zn8tfsPR9b3Ofy1+wzp2YzpnBo9H1vc5/LX7D0fW9zn8tfsM6dmM6ZwaPR9b3Ofy1+w9H1vc5/LX7DOnZjOmcGj0fW9zn8tfsPR9b3Ofy1+wzp2YzpnBo9H1vc5/LX7D0fW9zn8tfsM6dmM6ZwaPR9b3Ofy1+w9H1vc5/LX7DOnZjOmcGj0fW9zn8tfsPR9b3Ofy1+wzp2YzpnBo9H1vc5/LX7D0fW9zn8tfsM6dmM6ZwaPR9b3Ofy1+w9H1vc5/LX7DOnZjOmcGj0fW9zn8tfsPR9b3Ofy1+wzp2YzpnBo9H1vc5/LX7D0fW9zn8tfsM6dmM6ZwaPR9b3Ofy1+w9H1vc5/LX7DOnZjOmcGj0fW9zn8tfsPR9b3Ofy1+wzp2YzpnBo9H1vc5/LX7EJaWohbpSwSxtVbXexUS4iqmfUtOlQANIA9AHQw9VSnfZbev9DTpOzL4mWg/p3/AB/Q0mmZe6Tsy+I0nZl8TwBHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AHuk7MviNJ2ZfE8AGDEP6hPgQymrEP6hPgQzEah0sDcrJatzVVHJSvVFRd6cDzbqzvc/mKMF/HWftJPoUHGmmJrqvGnSZmKYsv26s73P5ijbqzvc/mKUA6YU6Yyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKNurO9z+YpQBhToyna/bqzvc/mKW1csk2ANdLI6RyVVruddfwmM1Tf28n7v/A58lNMWtHq3RMzf2coHoOrAACjfQf07/j+hpM9B/Tv+P6GgrMgB0JMOlmo4KiCFrWrEquvIiK9Wqt1RFW67k6gjng3xUMM0UKXqIpdPQmV7G6KXXdbei9l/wBfGyvpYmUEczYkZIiMa7R4cHIv83aBzATlhfDIkb0stkXxS/1JupJkqpKZGo+SPSujV423rbt3IBSDc3DWvo1qGVCOcrEc2JGrpL62ivusi/8AwbIcK1TZaWqiYsrVRyOaq3S7XJa/uciAcUEpEjR3/Tc5zbJvc2y36+tSIAAAADp4VgFZjFDXVFFFLPJSJH/0YY1e9+kqpuRN9ksvaFcwHZn6LYlSYHPidbTVFJqZWR6qop3xq5HX9ZFVLLvS1v8AxdmAdDp8Tr6FKnXLQ1cSv19JG6bVqqqiI7RRdFdJN993v7JeCz5oH203QnH8UloEnpkha+SVkro8MSHUNav4nIxqad03p28Lnci6NNoMKTBMSw9kzYquoihq3QK1Xo6BXteir1XS1kXiidhMoLPy0A/S8F6N1dDiXRp8WEQVKsdM2qnhYr41a5EVrnu4X0XLa/6IhZmxEPzQH6VX9E8VjqqWSjWmlSedaeZP+XWtbTJx0rOj9dvVp2T9eJld0WxReiGIRz4XHLWMk0YGx4ckc6I2Rt1RUaivRWqq9fDiTIs/PwdTGcAqsEhoX1SPY6riWRY5InRvjVHKitVHJfs3+85ZoAAEAAAAAAAAAAAAAAAAAAAAAGDEP6hPgQzGrEP6hPgQykah0cF/HWftJPoUGjBvx1n7ST6Gc5Ueer6N1eWAA14ZU09JXxzVMGujau9qcU9/vOtUzEXhiIvNpZAfrWN9L8MTonFHPGtVDVKjootHdLoqiqiqvBL2RV4p1H5Kebw3PVzUzNVOLtzcUcVVom4DZFhOIS1DoYaGeeSNEV7ImK9WovC9r2PoMS6I19bjFS6gw19JSpG17Ecx9lu1FVE3ceO7qXd2Gq/E8VFURVPpf9P5Yp4qqovEPkwfZv6IJhE06SQy4jDJh75Wyup3xNiem9Lr1LZOtU7LHAxihb/zDPS0MVmKqOjZwREVqO6+CInWY4vF8fLVanta91q4aqI6uWD6Kn6M7d0XZiNJBVSVSzaCtaivbo3VFciNbfcqdq9vWbsA6L4tS4o9ZsPZIxUlhcs0LlanqrZ6IqWVL24XX3Er8bxU01TfrF+nsscNczHTu+PB9XP0RqqREipaNcRbNC56TS0tRE6Nzb3aiXtderSTeV9K8Oo6djHUlFsr1qFase+9ljY5Ny8N6ruFHjeKuuKaet/77/kTw1REzL5gHXl6OVdPjdNhU7mtlqEaqK1FWyLfqW2/cv69ppp+js70a6bCcQpUgYss0lQ12hIjd6tRNBNG+/iqnSfE8URe7McVU+j58HcdSws6SV1HDR00zGySKxsznN0Wtutm6LkutupbmufobidbiVdslIsLGSvWGN8UjUe2900XaOj+l3IZnxXHTbKbdLrHFVPbq+YB9HS4TDT0CMxzC5qVZnrDDUNZIkrZFsqKrXLoubxT1d+79CePUVHBR1UbKNkFVRywRSuYq2eqxu0lS/DenK5I8XRNeMR/ekfuvwptd8yDs0HRyrr8GnrIqeqdKxzdU1sD1bK1Vs5UVE3qi24e8vb0Ix187Ym0jrOkVmmrXI1EREXSW6cN+7rWy7jU+K4aZmJqiLMxxVzF4h8+DsY5gHoeeljbUulbUNujpYHQK1b2W6P3295zKqnkpKqWmltpxPVjrLdLp2HXj5aOSImme7NVM0zaVQAOjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGqb+3k/d/4GU1Tf28n7v/AAOXL6e7pR6+zlgA6MgPQBvoP6d3x/Q0Geh/p3fH9DQVmXrXOY5HNVWuRboqLZUU1+mMU/7lV+e77mMBGz0xin/cqvz3fconqqmpW9RUSzL2yPV3+/6lQA2Q4rWwwLE2sq22REjRlQrWtT9P/glFiEUSLOkEj61UX/rvmuiKv+rRte9u1f4MIA1+l8TXjiNX57vuQfiFbJEkUlZO+NODHSuVE/i5nAEpHI912xtjSyJZt7c1UiAAAAA00OI1uGT66iq56d6pZywyuYrk7FVqotjMAO/UdK5sSfJHi0dTUUb2Imzx4hMiNci3R6LI56X/AFRU7LEa3pZXOljZhD5sHpIY0jip6Wdybrqt3OS2kqqqrdThAloW7pSdJcflZoSY5iL2rZbOq5FTd/JGfpDjdS1G1GMV8qJdUSSpe5EuiovFexVT+TngWG/DarDIEVMRwx9YiPR7ViqVhWycWrucitX3Ii+82VnS/Gqitlnpa6ow+J6po09JM+NjEREREsi9iJvOIBYdX/mrpF/3/E//AHkn3PE6T4/rWSuxvEXuZw0quTh1pe999jlgWHfq+mFVXRSsqaCjqNYjUa+o1s74rLf1HSPcrb9aXsU1XSTao6xnoTCIdqRqaUNLorDbrZv9W/WcYCxcABUAAAAAAAAAAAAAAAAAAAAAGGv/AKhPgQymqv8A6hPgQzEah0cG/HWftJPoZzRg346z9pJ9DOcqPPV9G6vLAX0UsUNZFLOxXxsddWol7lAOzETabvp67pNhtZh2yJhyx2YrUem/fa17Ktk/ix83FIsMzJWoiqxyORF4LYgDFNFNMWhuvkqrm8vrqvpXTRYfNLhNOyirK5VWdYauZVaq71doq1GIvYqKtrnAXHcYc9r1xatV7UVEctQ+6IvHrMAOPH4Xi44tEX9+v6rVy11erc7G8WdG+J2KVisffSatQ+zr8bpffcnhOIQUuJLNiEUlTDKx0UqI719FyWVUXtQ5wOk8VE0zTa19dGIrqvd9R/zJh2E0WzYF6Tej3XftlS5jWp2NSJycV679XvOdUdKcXmaxI62pp1be6x1cyq6/bpPXh7rHIByp8LxUzeYvPz6tzy1y6P8AzDjf/ea//wBy/wC55T4vJtay4kxcSif7SOokcqu4b0fxau5N6dluBzwdfg8dukW/JnOrbp4zjc2LYo2tRq0+qa1kLWvVzmNbw9Zd6r7yuTHcYljdHJi1a9jks5rqh6oqdipcwARw8cUxTEdI7E11TMzd1afF6amhkkZh+lXyRqzaXzK5qKvFyMVPxKi8VW3XYU/SbFoI3sWuqpdJui1X1Uqav3povRPG6HKBJ4OOb3i58Sr0l1KbHsR9IUs9XidZI2CVHorn61WdqtR62vbtKMVxGbEsQqKiSollSWTSvIiNVyJuaqo3de3YYgWOGimrKI69ia6pi0y6NBj2JYfq2RVlQsEd7QbRIxng1yKn8KeydIcYfO+VmJ1kSv8A9LKmSyJ1JdXKtkv1qc0CeHjmb4wZ1Wtd1oMajlkZLjEE+KPideNZatyJbK66LdL791v1OdVVMlZVS1MttZK9Xu0Usl17EKgWniopm8R/f2SapmLSAA6MgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAapv7eT93/gZTVN/byfu/8AA5cvp7ulHr7OWD0HRkAAG+h/p3fH9DQZ6H+nd8f0NBWZADf6LVZ00J6Z0CqnrbVEi2/RVRUX3KgRgBqjoknqaiKKVv8A0kVWuVUs5EW29eCfrwOi7DKR1LbWU0Uy6CuetYxyN6nIiI6/v6+xAOLou0UdoroqtkW2654fQSxU1FQVMDKuKWJ2+K0zXrdW79yLu3onV1nKpaZklNPLKsSNRi6KrM1HI5N+5t7rfhwAyA7uH0TaeljnbURNdUtVEm1sbHQKnZpLdeO+1lT/AH409klVmixFZ6quY5VR6p13Vev3bgKwAAAAAA7vReXUtxSTXywaNGq62FLvb6zd6b0/3Q5c3J8OiarXbopyqs4QPq6bEY61JZKZ89TXUdE9YqioRNa9dK6qiXXe1qrbepyp1rMSpqaXEp4oWrppFV1Gm58qIqXRVajlVEvuVU7UucaPETM2qpt+v0i3+/l0bnjiI6S5IO/FiFbRdG51WumkbUPWlhasjlY1iJdyoi8OKIm7rUqxKdJ+jOGqkMUKNmlajY0VE3I3et1VVUsc9U1RGPS9u/yvr6JNEWvf0u4oAPU5AAAAAAAAAAAAAAAAAAAAAAAAAAAAADDX/wBQnwIZjTX+3T4EMxGodHBvx1n7ST6Gc0YN+Os/aSfQznOjz1fRurywAA6uYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9RFcqNRLqu5EQ11eF1VDC2Wpa1mk5W6GkiuTr4EZmumJiJnrLGC2SlnihjmfE9sciXY9U3L/JBjHyPRkbXPcvBGpdVKsTExeEQOACgAAAAAAAAAAAAAAAAAAAAAapv7eT93/gZTXN/b6fu/8AA5cvp7ulHr7OWADoyA9AG6h/p3fH9DQZ6H+nd8f0NBWZCSSOSJY7N0XLdVVqX8eKEQEaX4hUvplp1e1I1tpI2NrVdbhpKiXX+TMAAJRyOikbIxURzVul0vyUiALqmrnq3NdM5F0G6LWtajWtT3IiIiFb5HyaOm9ztFui3SW9k7E9xEAAAAAAAnHNLE17Y5HsSRui9GuVNJOxe1CAJMX7qlFNLBK2WGR8cjVu17HKiovuVCdTVVNZLraqolnktbSlerlt2XUqBMYve3UvNrJOlkdE2J0jljYqq1iuWzb8bIFlkdE2JZHLG1VVrFctkVeKohEFtBcABUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGKv8Abp8CGU1V/t0+BDMRqHQwb8dZ+0k+hnNODfjrP2kn0Mxzo89X0bq8sBrw2JairSnZTxTvlRWsSVzkRF91lTeZDo0GJU1BozModKsYipHKsq6KLm0bb1T9be46ua6Hovi00sMaUsjElbpK98b0Rm+1nbty/c30+DSxwzvq8FaxG08rUVElSz2oio5VcqpvstlTcu85VVjuI1MiOSqnhRLKjGVEipdOv1nKtyp+MYpIxzH4lVua5LOa6dyoqdnEDqQUSp0xbHQ0euiZK12r0btaxUS9/cl+s11XRt9PTVcsbFqZ5Lq2NtI9mrcj2qugip6yWVeCHzcNbV08rpYKqaKRyWc9kitVU/VC1cYxRzkcuJVaubeyrO66X/kDvYpgFREyKdKJsivpVdKr4dW2NyJdVTVoiIu/dpdm852DYNHiNJPUOXS1T2tcmvbEkbVRfXcqtXd7kMT8YxSRjmPxKrc1yWc107lRU8TZhzsMqsJdRV1fJQvZNrGuSJZGvRURLKidaW5gZaDCKjEqySmplY90aKquS6tVEW26ydZqi6LYq+Bkz6d8TXO0Va6KRXN471RrVW24nSY1T4Q6VKOnbPM1qxw1m+JdFeN2Iqo73X38DFFjWJxS6zb6p13I5yLO9NP9bKi9QGqTorjEdclKtI9UX/7zWuWO3bdE5cfcZK2hjoWat9SjqtkjmSwIxbMROC6XBbkqjG8SqHuVa2oYxVRUjSeRWttwtpOVePvKqivkqaZkUscTnter3Tq28r1XM7rAygAAAAAAAAAAAAOz0Xo4qvFbzMR7ImK/RVLoq8EN8NS/HsMxFlW1jnQevCqNRFZx3cjB0XrIqTFFSZ6MZKxWaSrZEXqN8NM/AcMxF9U5jXT+pCiORVfx38zE93yPE3+NO/u4/j1t+75hrXPejWoquVbIidanVxTD1paCGSSVJajWubM5FvZbJZt/ciHOpqh1LUx1DGtc6N2kiOS6XO03pFDXayPGabXRLZWNh3aKp/Pv7Szd7eeeWK6aqYvEd9pNp63GsEoIIERUic9r1XciWtZV/hSWHUlZhVfLRTzMgj0EmfPG3SVGpu3Kqe/rQtkxvAJKVlM6iqkhZwY1dFP5s7f/ACTb0iwRkzJW0lUj449W1d34ey2lvM9dPnzPNNM0Rxzab9LRu+/2c+njnw7pDNTRwx1b36TU1v8AqRUvfwOK6+mt0st96WtY+nfjfR+SsbVuoanXNVLOTda3DcjrHzUr0kme9ODnKqXNQ93hprqm9VMxNo77QABp7AAAAAAAAAAAAAAAAAAADXL/AG8n7v8AwMhrl/t9P3f+By5fT3dKPX2csHoOjIAAN1D/AE7vj+hoM9F/Tu+P6GgrMhJ8ckaNV7HNR6aTbpa6dqEU47+B3HVtBidXFLJBVI+NisWJrEm0m2XfpKqLdN/FF4cQjhg7E1LBNA+Gjo6t9Q1GIulTIyyoi79zl3qnVbfa55HHS4bJDtiyxT6tdbCyNJLot7aSK5LLa279OAHPZRzSUi1LERzGqqOsu9trb1Ts3lB26rF6SSnlax08j5GI1dKJrGpZtrpZy26t3uM1PUNmwh2GxxPkqJJNNrWsTfb3ot13X3Ki8dwHNLKeB9TIrGK1FRqu9Z1r2S504sHl0qRklFI6TSvPG1fWRir6quT/AE9fZw6izacKpJpWMmnexsrlY1sKK1EVFaqI5X3sqKm/3AcaWJ8Mjo5Gq17VsqL1ETXW1ElSqyo9Uic7cxZEWzrIiro33X7TIAAAA9ZG+RVRjHOVEVV0UvZE4qeG7Dq6GkZPFNHI5s7dBXMfbRTff1V3Lx936lpiJnqzXMxF4i7CSfE+NrHOaqJImk1e1L2/3Q6D48LSni031jdy2kSmamnv+Pfben/weSPwqVGt1lVG2NFa3Rhat/et37t99xrD5sfEv2ifwZEplWidVX3JIjLbuy/aQWGRsDZlbaN7la1b8VTj/uhpqJqRtOsFKkrmqrXK6RqNW6aV9yKvUqeArHMcykpo5Gq2ONNJUXdpOW6+F0T+BMQsVTf+9mXVP1KzaK6CO0dL38bciJ11lwiGVsTmTo1jmrIiRIqOc1VTgr+tF7ergYq+anmka6BHKqJ6zlibGi9nqt3J+t94mmIjulPJNU9mUAGHUAAAAAAAAAAAAAAAAAAAAAAAAAAGKv8Abp8CGY013t0+BDMRqHRwb8dZ+0k+hmNOD/jrP2kn0Mxzo89X0bq8sAAOrmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAa5f7eT93/gZDXL/AG+n7v8AwOXL6e7pR6+zmAA6MgAA3UX9O74/oaCii/p3fH9C8rMhJkskbXtZI5rXpZyItkcnYvaRARJZZHRtiWRysaqq1qruRV42QiAAAAAAAAAAAAAAASkkkldpSPc9UREu5b7k4IRAAAAAqqq3XeoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMVd7dPgQzGmu9unwIZiNQ6OD/jrP2kn0Mxpwf8dZ+0k+hmOdHnq+jdXlgAB1cwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADXL/b6fu/8DIa5f7fT93/gcuX093Sj19nMAB0ZegADdRf07vj+heUUX9O74voXlZkNcuF1ccsULY1mklj1jWwor938ceHVcyItludN2OzytelVTU1S57dFXPYrVVLotvVVE4px4hHNc1zHK1yK1yLZUVLKihY3pGkiscjHKqI625V/U6mH1sTMQ9JTzwxuYq3hSJ13JbcjbbvddVT33JRY/IisibTUsLGr6jkWVurTf1tdfrXtXeByWRvkdoxsc9URVs1L7k4m2qw5I2tkhkuxyXTWKjVT1Edxvbr5Gj0/IyqknZQ0TXyfjc1r7P8A/wBu3f1X6zLPX7W1IpGNgiYnqtiart6JZPxOvzAxgAAAAAAAAHXwXDqTEKarSaaBk7HRLG2WoZCrmaS6eir1RqutbcqhVFPQQT4DWVunKlRTTRt0URFYrHX/AJvdDdhWD0mM4ZHT008bcT2i8jFa9Xancl28GrZbqrd6qm9F3KhuxOfCIZ6vBaB1BR0lTGxz6rRlkVHIuk1iq2SRq+9zUXjwQurOlmHQdKaXEmU64hsVI2Bj4nup2rIl7vRFRVt61kRbfQz1HCxTAnYdLTMZVxVCVD5GNf8AgaitkVm9XWtwvv3JzPazoxi1JiU9BHSS1k1Oxr5FpYnyI1FS6dXPgU+m6tjqN0KsjWhkdJAqtR6tVztK66V0Xf7jqv6c1k8aJV4ZhtVLpskWZ8b2uV7L6LrMe1qKl14Il+u5ep0fNFktPPCyN8sMkbJW6UbnNVEenC6dqH03R7GKTC5qrGKqspZZainkZJQpTPY57lXciKxEa1q7lVUXtTR4KaKX/iDXvmjR1PhlLqm+pIu0MSyWsxUjfvT1WpZUstt/WLyPk6WndPItoppI4005libpKxiKl3e7jxXcdTpNgDcBq2NiqHTRTK9WK5tnNRrlSy9Sr+hrp+m0tGtRs2B4RCyqvrmRxyo1+5U/M9VLKu5LJvObjeP1WOyRuqIoYkivoMiRURL2vxVV6k6x1HMABUAAAAAAAAAAAAAAAAAAAAAAAAYq726fAhnNFd7dPgQzkah0MH/FWftJPoZjTg/4qz9pJ9DMc6PPV9G6vLAaVoJUw5K9XM1SyatER13Xsq70Thw6zMb4cYnZSNo5oYKmnZ+GORltFb3vdqo7t6zq5sT45I9HWMczSajm6SWunanuJ0up2qLaFtDppp8fw338Doz4+tUrVqcMoZnNRERzmvTde/U5ELY8RgbBW1L5odZVwapKaNj7tW1k3rutbfxW/Z2BTJgyOV0kdTGsb3u1Oi11ntRquRUv+lrLvRTlHRfirW09HFTQLEtNpXc6TTRyuTetrJYsqKingwTYIqmOpc+fW3jY5uglrb9K11X3JutxA5QO2+ugqn09PrqenhpFa6KSVsj1clkui2v4IiJe5fWdJEmSpaympZYJHaOqmWZVd/67aWii+/iBz4MJWalVznqyXc5qJZzVarXOTgvG7VQ58kbonaLlaq2RfVcjk3+9DpLj0qQtiho6aFGpZHN01VE3rb1nLmU5siRo60TnObZN7m6K36911AiAAAAAAACynpp6uVIqaCSaReDI2K5V/hD7fAv+Hr63BKmTEGSU9bIi7M1ztHRVE3aSe9ePuPlcCxaowbFYqqmaj3fhcxf9aKqbvd1H7gxVe1jl3K5EWx8P/K+L5uC1NHSJ9fXo9nhuKiu8y/C8QwbE8KVExCgqKZFXRR0sao1y+5eC/wAGI+3/AOJeLVUuKNwhzEZTwI2VF4rI5W8f0S6p4+63xB9PwvLXy8NNdcWmdPPyUxTVNMAAPS5gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABrl/t9P3f+BkNcv8Ab6fu/wDA5cvp7ulHr7OaADoyAADdRf07vj+heUUX9O74voXlZkAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAY6726fChmNNd7dPgQzEah0cH/FWftJPoZTVg/4qz9o/wChlOdHnq+jdXlgAB1cwAAAAAAAAAAAAAAAAAAese6N7XsVWuat0VOpTqz9KMaqKmOofiErXx20UYui3d7k3L/JyQYq46KpvVF2oqmO0tmJ4rWYxWbXXTa2XRRt7IlkTglkMYBaaYpjGmLQkzMzeQAGkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADXJ/b6fu/8AAyGuT+30/d/4HLl9Pd0o9fZzQAdGQHoA20X9O74/oXlFEirA6yX9b6GjRdlXwKzLwHui7KvgNF2VfAI8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwA8B7ouyr4DRdlXwAxV3t0+FDMaa726fChnI1DoYP+Ks/aSfQymvBmq6Sra1FVy0r0RETeq7ivYazuk/lqcaaoiuq86dJiZpiygF+w1ndJ/LUbDWd0n8tTpnTtjGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKAX7DWd0n8tRsNZ3Sfy1GdOzGdKDXJ/b6fu/wDAr2Gs7pP5al9RFJDgKNljdG5aq9nNVF/Cc+SqmbWn1boiYv7OUD0HZgAAHqPe1LNcqJ7lPdbJnd4kQBLWyZ3eI1smd3iRAEtbJnd4jWyZ3eJEAS1smd3iNbJnd4kQBLWyZ3eI1smd3iRAEtbJnd4jWyZ3eJEAS1smd3iNbJnd4kQBLWyZ3eI1smd3iRAEtbJnd4jWyZ3eJEAS1smd3iNbJnd4kQBLWyZ3eI1smd3iRAEtbJnd4jWyZ3eJEAS1smd3iNbJnd4kQBLWyZ3eI1smd3iRAEtbJnd4jWyZ3eJEAS1smd3iNbJnd4kQBLWyZ3eI1smd3iRAEtbJnd4jWyZ3eJEAS1smd3iNbJnd4kQBLWyZ3eI1smd3iRAEtbJnd4jWyZ3eJEAS1smd3iNbJnd4kQB6rnOW7lVV954ABOKWWF2lFI+Nypa7XKi2LNvrO9z+YpQDM00z3hYmYX7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xRt9Z3ufzFKAMKdGU7X7fWd7n8xSMtTUTN0ZZ5JGot7OeqpcqAiimO0GUgANIAAIAuip3zNVzVaiItt62J7FLmZ8wGYGnYpczPmGxS5mfMC7MDTsUuZnzDYpczPmBdmBp2KXMz5hsUuZnzAuzA07FLmZ8w2KXMz5gXZgadilzM+YbFLmZ8wLswNOxS5mfMNilzM+YF2YGnYpczPmGxS5mfMC7MDTsUuZnzDYpczPmBdmBp2KXMz5hsUuZnzAuzA07FLmZ8w2KXMz5gXZgadilzM+YbFLmZ8wLswNOxS5mfMNilzM+YF2YGnYpczPmGxS5mfMC7MDTsUuZnzDYpczPmBdmBp2KXMz5hsUuZnzAuzA07FLmZ8w2KXMz5gXZgadilzM+YbFLmZ8wLswNOxS5mfMNilzM+YF2YGnYpczPmGxS5mfMC7MDTsUuZnzDYpczPmBdmBp2KXMz5hsUuZnzAuzA07FLmZ8w2KXMz5gXZgadilzM+YbFLmZ8wLswNOxS5mfMNilzM+YF2YGnYpczPmGxS5mfMC7MDTsUuZnzDYpczPmBdmBp2KXMz5hsUuZnzAuzA07FLmZ8w2KXMz5gXZgadilzM+YbFLmZ8wLswNOxS5mfMNilzM+YF2YGnYpczPmGxS5mfMC7MDTsUuZnzDYpczPmBdmBp2KXMz5hsUuZnzAuzA07FLmZ8w2KXMz5gXZgadilzM+YbFLmZ8wLswNOxS5mfMNilzM+YF2YGnYpczPmGxS5mfMC7MDTsUuZnzDYpczPmBdmBp2KXMz5hsUuZnzAuzA07FLmZ8w2KXMz5gXZgadilzM+YbFLmZ8wLswNOxS5mfMNilzM+YF2YGnYpczPmGxS5mfMC7MDTsUuZnzDYpczPmBdmBp2KXMz5hsUuZnzAuzA07FLmZ8w2KXMz5gXZgadilzM+YhLTvhajnK1UVbblApAAHoAA20fsHfF9C4po/YO+L6FxUAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACms9g34voXFNZ7BvxfQKxAAigAA20nsHfF9C4ppPYO+L6FxUDbh+DYhiqPWhpnTIxUR1lRLeKmI+26A66KmqpWxucx0jW3S3FE/8A6h046aaqrVTaHHnrro45qoi8vnaroxjVFTPqamgfHFGl3OVzd3M5Z+sdJZ3T9GK6NI36Wqvv7EW68kPy+ho31tQsbVVGtY6R7kS+i1qXVbdZObDj6xPRnwtfLy035KbTdQ1jnu0WNVy8bIlzw+n6M4TLTzUuMuxLD6eBHq1UlqER6XRUtayoi2W9rl+H9H8EiekmIYxQVLmSf9VjavRa5qovCyXVU3LuXfw3WPnV+O46Kqo721vr0/s+r308FUxEvk2xSOajmxuVFVURUTiqb1IoiqtkS6qfcf8A0OExrHDiNA+jfWOeyKKoSRzWOjc31uvs7T5nDMOqZ6Z1bSU01TLDMxGsiYrrcVuqWXdusXj8XFcTVMWjp+aVcVpiHOc1zHK1zVa5q2VFSyopbHR1UqvSOmlesbdN+ixV0W8br2J7z7HHcOwdr56irr6JlRK56yXV8szHL+FEaxyIm7dvTd2rc8wyjwyrk2+vxLDVSaiZGkc0yLIxyNRFWy8F3blOP/IUzx5xTP4T3+W/Vv7POWN3xbY3vRVYxzkS17Je1+BOCmkqJtUxY2u//LI2NPFyoh9pS6WGxPqJ+kVHVyOYxHptqSuVWyIqI26Xta90OBhzsK/5hnqa6pSOnikdJEiMc9JF0vVSydXgdKPFzXFcxT27d5v9LQzPDETETPdyo6aSWp2drokeiql3Sta3d/6lW3MjLC+F6teiblVLtcjmrbsVNy/wfVR4Bh3pGarfi+FSxLJrIY3ViNul72citXq/XenBTF0pko12aCkdTqkTpLpTyI9qaWi7cqIm66u6kLx+Ljk5YopjpP5FXDjTMy+fB9NH0Xokaiz4pDG+amSSGBz0bLpq29nNt2qiIl7rf3b+f6HiTo1LiTpHJURVCROivbR9ypa9/ff+DpT4viq7T6xHbbE8NcOSD6zCcCoYIaStqavD21G6R1NV1bUa9iovFqtu1d6L/qL6jAcNr6+pnrekVC50u+OZtVGit3IiIrEbZey6OT9DjPj+OK5i3SG48PVMXfGtY566LGq5bKtkS/Deoc1zVs5FReNlQ+0wyidQy00s3Segl2dXNazbtJrWK23qtVNy8jiVEceMdIYWMfGrZIo9Y7WaDUtGmld1ltwXfZTVHi4rrmLdIi9/7EJVw2iNy5MNPNO+NkUTnukfoMsn4ndnMjJG+GR0crHMe1bOa5LKi9iofYxYbRQSRUtJj9FGynqWVCPkqUWyK2yo1UsjlRW+7inA14hSUVVLBJT47SwSQzKqS+l1c5Y1423WYvDcm44z/kIiqIt0+v0b+zzbu+BBZUIiVMqJJrER6+ve+lv4lZ9OJvF3mAAVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApq/YN+L6FxTV+wb8X0CsQAIr0AAbKT2Dvi+hcU0nsHfF9C4qB28L6V1+E4fsVPBSrHpK5XPiu5VX33OIAPoZum2Jz0c9K6GkRk7HMcurVXIipZbKq7jjUFfU4bWMqqWV0UjP9TbcOtN908TODNVMVRMTHSVvMTd08bx2qxqZjppZnRxpZrJXtWy9a+q1qcjmAE4+OjjpimiLRBVVNU3kLqatq6JXLSVU1Or0s5YpFbf9bFINTEVRaUiZjsKqqt1W6qACoAACzaahKbZtfJqFdparTXRv224XLKOvqKB6up3tTStdHxte1bb0WzkVLp2mcGZopmJiYW8x1WVNTNV1ElRUSLJLI7Sc53FVNNZjOJYhSw01XVvlhh/A11ufb/JiBPh0TbpHTt8vZcp69e66oqXVKQ6TURYo0jv2ol7f72/gpANRERFoSZuF1HUuo6qOdrUcrF4L1pwVCkCYiYtJE26gAKgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFNX7BvxfQuKav2Dfi+gVjABFAABspPYO+L6FxTSewd8X0LioAAIAAAD3Rdoo7RXRVbItt1zwAAAAPWtc9yNa1XOXgiJdVPAAAAAAAAAAAAA9RrlarkRdFFsq23IeAAAAB7ou0dLRXRRbXtuueAAA1qucjWoqqq2RE4qAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKav2Dfi+hcU1fsG/F9ArGACK9AAGuk9g74voXFVL7B3xfQtKgb/AEWqzpoT0zoFVPW2qJFt+iqiovuVDASSRyRLHZui5bqqtS/jxQI0R0ST1NRFFK3/AKSKrXKqWciLbevBP14HRdhlI6ltrKaKZdBXPWsY5G9TkREdf39fYhzX4hUvplp1e1I1tpI2NrVdbhpKiXX+TMB9BLFTUVBUwMq4pYnb4rTNet1bv3Iu7eidXWcSka19VGx7Ucj3I3eira+6+5UUqNNPiFTSMVkD2t42dq2q5t0stnKl0/hQOpJhC1jqqpdLCuhG3R0Zo2+siIi3RV3JftsY6rCWQUiTx1tPI5Nz4tbHpfq3Rct08F9xkhq54I5Y432bKlnoqIt/HhxXenaVukV7WtVG2Ylks1EX+VTj/IHapW0uy0TqaembUwytklVX6p1uy7rX4dS9fDrVNh0NdXSSuxCmjY5Go1+tjtdEst0VyKibupFOGALahmpfqFSJXRqqLJE/SR/83t4fyVEnSPcxsbnuVjL6LVXc2/GxEAAAAAA3U9Axy1CSu0nQt9m2RrFVbXVfW42tvRENMdGxcO1DpaZkr3o51qiNbonXfSsi+su66cDPLjE8tEsFmtfJ7WVrWtdInUiqiIqp23vcwGbS4RRyVeabO9TQQ4fJK1K2Gancsa6WtYl1vv8AURyruRV8DisgV7dPSa1umjLu3cSs10Fe6icqOjZNEq6Sxva1yKqcF3ovKy+8tliiqiJmJvLzEKaOlqGxsvo6KLpaxr9L3po7v45nWTC420+yVVdTJq5HtZeVqq1Ft62jppbgvau/gctMWrEqH1Gsasj3aV3xtfor1W0kW1vcZHOc9yve5XOct1VVuqqS0szRyVRETNrO/BHBSU9nz07WuRumxlQ16aXrNVbI5epUX7HLo6Snmhlmqqp1OyPc1Uj01evYiXTf/wCLYxminrVgifC+CKeJ630JUXcvaioqKniLL8OqmJmJ6z/fV5BTsqa5lPHI7RkejWvcyy7+F0v9Tp01JJBEjHSYcjo3pK2RKlmsvu9W+klk/wDPeYG4lURtcyBI4WORURGMS7UXiiOW7kT+TIXqtVFdXebR/fZ0cTRtRXRsgc2Ry3b6qot103W3/pYlLg8esVKfEKaViMujnysZd2Wyu58DnwyvgmbLGqI5i3S6XTwLKmpjqFuykhgW6qqxaW/+FcqJ/BLSYV02imejbUYVTxUazJWw6xsaOWNs0ciKvWl0W9/dZU95krKNKWKnkbMkqTx6e5OC9acfsURSvhkSRltJMzUcn8ou5SdRUzVciSTORyo1GoiNRqNROCIibkQvVaaeSJ6zeH7J0Z6H9HqvonhtTUYVDJNLCx73uvdyqu/rPnv+KHR3CMHw6jnw6ijpnvmVjtXfellXf4HytL00xujpYqaGoRscLEYxLKlkThwUzYt0lxPG4GQ10yPZG7SaiJ12sbxiOt3W8zFrOUADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABTV+wb8X0Liqq9g34voFYwARQAFGyl9g74voWlVL7B3xfQtCAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABVVewb8X0LSqq9g34voFYwAFegADXS+wd8X0LSql9g74voWhAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAqqvYN+L6FpVVewb8X0CsgACgAA10vsHfF9C0qpvYO+L6FoQAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKqr2Dfi+haVVPsG/F9ArIAAr0AAaqb2Dvi+haVU3sHfF9C0IAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFVT7BvxfQtKqn2Dfi+gVlAAUAARfDMyONWuRVut9xPaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kNpiyv5GUAatpiyv5DaYsr+RlAGraYsr+Q2mLK/kZQBq2mLK/kQmmZJGjWo5LLfeUAAAAPQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//2Q==",
        "lastScreenshotTime": "2026-08-22T01:34:48.102Z",
        "currentTraineeName": "رفيف محمد رمضان بخيت",
        "lastArchivedTime": "2026-08-23T06:01:50.050Z"
    },
    {
        "id": "dev-1787362571450",
        "deviceId": "PC-74",
        "name": "جهاز PC-74",
        "assignedUser": "مرام محمد رمضان بخيت",
        "userType": "trainee",
        "branchId": "branch-1",
        "ipAddress": "ais-dev-7wkppak7c63am6ebvulppu-481160813332.europe-west2.run.app",
        "lastHeartbeat": "2026-08-22T01:46:31.883Z",
        "isOnline": false,
        "status": "active",
        "lastScreenshotUrl": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAsICAoIBwsKCQoNDAsNERwSEQ8PESIZGhQcKSQrKigkJyctMkA3LTA9MCcnOEw5PUNFSElIKzZPVU5GVEBHSEX/2wBDAQwNDREPESESEiFFLicuRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUX/wAARCAHCAyADASIAAhEBAxEB/8QAGwABAAIDAQEAAAAAAAAAAAAAAAMEAQIFBgf/xABGEAABAwICBwQJAgUCBAUFAAAAAQIDBBESFAUTITFRUpFBVJKhBiIzYXFygZPBMnQVIzWxwkLRByRi8VWUouHwFkNEY4L/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAX/xAAwEQEAAgIBAwMDAgUEAwAAAAAAAQIRElEDITEEQXETMmGBkRRyocHRBbHh8CIz8f/aAAwDAQACEQMRAD8A+fgA7uQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsUdJm3Obr4IcKXvM/Ci/ArnV0DUUtLVSyVcjGt1eGz4lkRyKu1LJ7jfR2i5amubNl0Sh2vc96+o1nxTtThxPNbr6Wtv4jx/xy7R09ojXzLn0tFLWJLqrKsTMaou9fcnFTSenfTqxHq1cbEemFb7FO1AmiqRcUGmKhuzC9IontWRex2/cl93uJHM0RV1MUueVrIEVFidTvfiajlW6qnuU5T6qYtnWdf5Z/wAN/RiYxmM/MPOtTE5G3RLra69hc0hoySge7E9kjEkWNHsXeqIi/k6kcegW09RTrWorpNrZlp3XZt2Inw2343KulqynlhfDBNrv5rXo/Crb2YiKtl96Go6979SIrWYj8xMcJPSrWkzMxn5cguUGj3aQ1yMmjjWNqO/mLbFdUT8lqlpNHVtNCj651PO1FR0aUznq7aq3unu/sXI10RRsxxaQSR7YXMVqU726xb3Rbru7Og6vqJxNaRO38s/4x3KdLvm0xj5hyU0c/KVM7pY25eRGOYq7VVeBmj0ZJW07pIpI0ckjY0jcu1cR3IJ9E07quWLSqJLUPxor6Vzkj2qu7tVL7/IxUV2jknfVM0gksr3RK5qQOZdWql3X+F9hw/ierOYis/jtP47ePnvl0+jSO8zH7x+fy87A2FKhG1WsSNLo7VIiuv8AX3iqjbFVSxsa9rWuVESS2JPjYs0ldBTaRkqX02vaquVjVfhwqq7FvbsL8rdEVlQ6rl0i6KSZEVY0gcuqfbat+3bfqem3VtS+ZrOMe3fv8Q5VpFq9pjOfhzp9F1FO+Vr1Z/KjSRVR29FVE2cbKu34EVJRS1qypDa8bFeqLvX3J7zuOqdGPYscmk6iVz2OiWaVr3YU2LdEW+xVQigTRVGuKDTFQ1UTC9IontWRexd+xEvu9xyj1PU0nMTn+Wf8Nz0q7dpjHzDgAuvyC6VkV7pnUeNbLH+tU7P1fkwrqFuko3RJMtIjmqqSoiut27th6/qfifGf+Plw1/KmDuxUGiI5WVD9K6yJH7WrRvRru21zFbomJKSNuj8dVIr1ddIHsdhVEtZF/UnvTdf3nH+LptEYn9YmI/rDp9C2M9v3hxGtc5VRqKqol9idh0GaFqUlWOoVlOuqdK3G5NqJ8DpwQU2iq6B1XVx0lRHEiSRNiWRH3ve6puW1jWCPQsCxqmk23Yj0cqUz0V6OS1l+Bxv6q0/ZE4/lmf6+P9/LdejEfdMfvEONW0a0T42rKyTWRtkuzsum4rHTrsu+rooqSdKlGMbGr3Rq1FXEtkVF9yoWdL+kFbMstCjmxwMvG5EYl3omzbw3dljtXq9SdYiM5857f0wxNKd5mf7/AN3IqIH0s74ZFarm71at0MwUs9Ur0gidIrG4nI1L2Q9FRVNE2tSqh0mjJJY2tkgdSOk2I1EVL/TsItXoJlfJPDpLVxPRyarUP2XRUWypbicv4u0dprOccT548ft3w39CPOYx8x/lyqzRclJHrNZHLGiMVXMXcrkVUTy/sVqenmqpkip43SSLezW7zqV9VSNo301PUZi8cTUfgVt1aruxfcqIVtGaOrampgkpYlcmNFx39Vtl/wBSpu/udKdW0dKbdScfPb2YtSJvEV7/AAil0bUQUaVM6Nia5bMY91nv4qib9hUPR18dDUUz6aCubU1Eb1y8aRK1WpfazEuxycPLgQx6Lp6Wgik0u7KuWRXsYjFWSRqIl2qnZ7rmen6qNc38zPjE5/bzP/32at0e+K+Pn+7hA6Gmn0Ula19ArVjViYkYxWIju2yKc89XTtvWLYxlwtXWZjIADbIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADraK0Lno1mmerIr2RG71GldC5GNJoXq+K9lR29C5oPSkEdKlNO9I3MVcKuWyKirfeNOaUgkpVpoHpI56piVq3RERb7zGZy+V9X1P8AE6+2f0w86ADb6oAAAAAEjZ5WQuibK9sT9rmI5Ua74oRgTET5XOAmpqqekkV9PK6NyorVVq70UhBJiLRiSJmO8AAKiWnqJaWZs0Ejo5G7nNI3OVzlc5VVyrdVXtMAmIzlczjAACoAAAAAAAAlSqnSlWmSV2oc7ErL7Lmc5Uq6Ny1EuKP9C41u34cCEGdK8NbTy2e90j1e9yuc5bq5y3VVNQDTIiqi3RbKh1J9PT1MKsmpqN8qtwrO6FFkX67vI5YMX6dLzE2jw3W9q9olLT1EtJM2ankdHI3c5pG5yvcrnKquVbqq9pgGsRnPuzmcYCSOeWFHpFK9iPSzka5UxJwXiRgsxE9pInASTTy1D8c8r5XIlsT3Kq2+pGBiM5MgACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA52am5/JBmpufyQhBGk2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAE2am5/JBmpufyQhAAGQFYBsjHOS7Wqqe5DOqfyO6BGgN9U/kd0GqfyO6AaA31T+R3Qap/I7oBoDfVP5HdBqn8jugGgN9U/kd0GqfyO6AaA31T+R3Qap/I7oBoDfVP5HdBqn8jugGgN9U/kd0GqfyO6AaA31T+R3Qap/I7oBoDfVP5HdBqn8jugGgN9U/kd0GqfyO6AaA31T+R3Qap/I7oBoDfVP5HdBqn8jugGgN9U/kd0GqfyO6AaA31T+R3Qap/I7oBoDfVP5HdBqn8jugGgN9U/kd0GqfyO6AaA31T+R3Qap/I7oBoDfVP5HdBqn8jugGgN9U/kd0GqfyO6AaA31T+R3Qap/I7oBoDfVP5HdBqn8jugGgNlarVs5FRfeYAwDeOKSZ2GKNz3Il7NS5Lkaru0321JNojzK4lXBYyNV3ab7ajI1XdpvtqTevK6zwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tRkaru0321G9eTWeFcFjI1XdpvtqMjVd2m+2o3ryazwrgsZGq7tN9tTSSmmhbilhkY1VtdzVQbRPuYlEDINIAAIv0KqkDrc34LGJeK9StRewd834LBUZxLxXqMS8V6mAEZxLxXqMS8V6mABnEvFeoxLxXqYAGcS8V6jEvFepgAZxLxXqMS8V6mABnEvFeoxLxXqYAGcS8V6jEvFepgAZxLxXqMS8V6mABnEvFeoxLxXqYAGcS8V6jEvFepgAZxLxXqMS8V6mABnEvFeoxLxXqYAGcS8V6jEvFepgAZxLxXqMS8V6mABnEvFeoxLxXqYAGcS8V6jEvFepgAZxLxXqMS8V6mABnEvFeoxLxXqYAGcS8V6jEvFepgAZxLxXqMS8V6mABnEvFeoxLxXqYAFKu9unyoVizXe3T5UKxGodHQ6q2Wqc1VRUp3qip2bjGcqe8TeNRoj9dX+2f+CE51rE3tn8NzMxWMJs5U94m8ajOVPeJvGpCDeleGNp5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41Gcqe8TeNSEDSvBtPKbOVPeJvGozlT3ibxqQgaV4Np5TZyp7xN41JaqWSXQqOke565i13Lf/SVCzN/Q0/c/4mL1iMYj3brMzlzAAdGAGQBeovYO+b8E5BRewd834JyoAF99BJLSwTQRNa1Y1V13oiuVFW6oirddidgRQBeioopY4k/nxyY8MquamFL7rbUXhf49ZK2mjbRRytjRkiYGuw7tzkX63aBzQbyROifgfsWyL1S5utLKlQ+BERz2XujV3232AhBdbo9H0qzMmRzsCObGjVxLtwr5/wDYtxaN1bZKepjYsiKjkcirdLtclr/MiAccGz0Yjv5bnObbe5ttvVTUAAAAB0tG6EqtK0dZNRxyTPpcH8qKNXudiW25OFlA5oOvN6N19Loeavq4JqbVSNZqp4XsVyOvtRVSy7U3FvQnopNpGto0qNatHUx49dSsWXAu1ER1kXCt023GVedB7Kb0Q0zpGShSaBImufIyR0dAkWpa1f1KjGpium1Olzsxej7aLRqaJ0hRNlbHUzRxVLoVar0dCrmvRV7LpbZ2onAmTD5oAfRdEaAqaOv9HXR6NhnVrpW1E0LVfGrVRFRznbtzltf6FmcD50D6JW+jOkWVNM+ky8iTTLBKn8Da1sCb72WP1k7MVvqVV9G9IL6L1zJtHskq2PwwtZQ6uZML23VFRqK9FRV4kyYeFB0tLaEqNDxUb6lHNdUxq9Y3xuY6NUVUVFRdvDac0qAAAAAAAAAAAAAAAAAAAAAAAAKVd7dPlQrFmu9unyoVyNQv6J/XV/tn/ghJtE/rq/2z/wAEJiv32/Rq32wAFrR1RDS1sctRFrY29idnv95uZxGYZiMzhVB9R0x6U0CejMTJmLUQ1KosceHZJhVFVFvu4cUPlxw9P1rdWJm1cOnV6cdO2M5AWo9GVsszooqSaaRiIr2RMV6tReNtx3dIei9ZV6VqFoqB9NTIxr2o5jrL6t1RNm/fs+nA1f1HTpOLT/3t/lmOnaYzEPMA9c/0WTRcs6SRSV0L6J8jZHQPjSN6bUuvYuw4elaNv8cmp6KOzFVFY3ciIrUXt4Gen6np9ScV8YzlbdK1Y7uaDvwej2c9HGV1LDUyVKy4Fa1Fc3DtS9kbfZ8V4lzQno5pKm0i9ZaJr2KkkKrNE5Wp6q2ftTal/ivuM29X06xac94z/RY6VpmPy8oD083ovUUqaumpVrmyxOekslPPG6NyX9VE4r2Yk2kfpLQ00DGOpqXLPWZWqzbeysY5N+7euwV9X072itff/vyT0rREzLzgOpJoCpg0vT6Onc1ss6IqK1F2It+xbbdilmDQMr0asujq6mSFiySyTtXA9E22RMKYb+9VOk+o6cRnLMdOzhA7LqaNmn62lipoJWNkerElc5uFG3WyWVLrbsW5am9E6+rr63K06xNbI5Yo3xvaj232YXYcPVUMz6np1xtOO2V+nafDzgPQU2i4oKJG6Y0fLTLK7VRTox6SI9dqKrVXC5u9Nm0203SUsNLUxspmQ1NLJDHI5l7OXAuJUvu2p5E/iazbWIPpzjLzoOtRaAqK3RU9VHBULI1zdW1sLlbI29nKiom1U2eZO30P0u6ZsbaZbK9WY1RyNRERFxLdN2347F2Gp9R0omYm0RhI6d57xDhA6umdCfwqamY2dZGztuiyQuhVq3st0dtt7znVMD6WplgktjjcrVst0uh0p1K3iJrPlLVms4lGADbIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFmb+hp+5/xKxZl/oafuf8Tn1Pb5bp7uYDINsgAAvUXsHfN+CcgovYO+b8E5UZa5WuRzVVFRboqdha/iukO/VP3nf7lQBFv+K6Q79U/ed/uQzVM9Qt55pJV4vcq/3IgBbi0lVRQrG2qqm2REYjJlRrfp/wBjaOujivKkL3Viov8AOfLdEVf9VrXv9SkALf8AFK9f/wA6p+67/cjfXVckaRvqpnMTc1ZFVE+hAANnuR7rtY1iW3Nv+VNQAAAAFiir6rR82to6iaB67FWKRzFcnBVRUWxXAHdn9JpNIOezSbKiele1E1DK2VEa5F/Uivc/b8UVPga1npPVukjbop0ui6WJiRxwU0zk2XVbuclsS3VdpxAMK6L/AEh0zI3DJpavc3g6peqf3NZtO6WqGo2fSdbKibkfUPW2y3avBVT6lAAXqCpoIUVK+gfVIj0cixzrEtk3tXYqKi+5EX3lur9KdKT1cs1NVz0MT1TDBSyuYxqIlkSyLwRNpxgB0/8A6k03/wCM6Q/80/8A3MJ6RaZ1rZHaVrnObuvUv3dqbzmgYHdqfSqorI5GVFHSzY0ajXz6yZ0dlv6rnvcqX7SGp0/mY6tv8K0XFmUal4qfCsVuTbsv2nIAwAACAAAAAAAAAAAAAAAAAAAAACnW+3T5UKxZrfbJ8qFYNQ6Gif11f7Z/4ICfRP66v9s/8EBzr99v0at9sBNSSRw1UckzFfG1bq1O0hB0ZicTl6Ss9IaGrocslErLNVEcm3ba17Ktk+h52KRYpWSIiKrHI5EXdsNQZikVjENX6k3nMvVVXpLBFRSyaLgZSVdWqrMsVTMqtVd64VRGovvRVtc4S6a0mr0eukatXNRURyzuul9/aUgcun6bp9OO0Z+e/wDutupay4umNJOjdG7SFWrH3xNWZ1nX33S5vouuipq/W10b6iGRjo5ER3rWcllVF4lAHSenWYmuMZZ2nOXpP4/Q6MpNRoX+IORzruzc6ta1P+lI3Jv437ChP6SaSla1GVVRCrb3WOplXF8cT13e45QOdfTdOveYzP5anqWlf/julv8AxSt/8w//AHMQaUfmdZpBi18bv1snet13bnb0XYm1OBRBv6VPaGdrcujpbTEulNItq0asOra1kSNeqqxG7vWXaq+8jfprScrHMk0jVvY5LK107lRU6lICOlSIiMeCb2mc5dODSkFPDI9lHeuexWa98qual97kaqfqVF33t7hB6Q6ShjexauokxNwtV1RKmD3pZyedzmAk9Hpz5hd7OjT6ars7TTVNfVPbDIj0VX6xW8VRHLa9iHSVfLX108z5pJEkfe70RqqibEVUTZe3AqAsdKkW2iEm0zGJlfotNV1DgbHUzrCy9odfI1n/AKXIvQy/Tuk3TPkZX1Uau7G1D9idiXVVW3xU54H0unM5wb2xjLpw6WZI9smloZtIvjW7FkqXbuC3RbpfbssUKmofVVMk8tscjlc6yWS6kYLXp1rOYJtMxiQAG2QAAAAAAAAAAAAAAAAAAAAAAAAAAAAALMv9DT9z/iVizL/Q0/c/4nPqe3y3T3c0AG2QGQUXaP2Dvm/BOQUfsHfN+CcIAF7+GqsyYZoFhVU9bMRotvgqotwiiC1HSJNPPHFIn8tFVqqqWciLbfuT4l92jqZ1NbHTxyrhVXLVMcjexyIiL9e3ggHHwrhR1lwqtr9hg7sscFJRVMLKmKSJ22P+a1y3VvBN21E7O05lNTtkgmkkWNGo1cKrK1HI5ODb3W+7cUVQduhpEgp45mzxI6oRUSXWRtWFU4Yluu/bayp/fkTWSRW2Zdnqq5iqqOXje5BGAAAAAAE0cCyU8011RsVtyX2quz4dpJmI8rjKJzHMcrXtVrk7FSxg7K0DtJ6S1cs+rlyzHprLXVUYmzaqW4/AVeh42xwvpqqikVPVexaiNrlXiv8AMVLfBU+Bxj1FO0WnvLf07eYcdWORqOVqo125bbFDWOe5GsarnLuREup6CobBTaPmh18KsXHqmNnbJa+BbbFW21FQ5+joJIq3R8savxzS+rhTsRbb7/ElevtWbE0xOHOB2J9BtSFHw19K+S9nxyVETV+KLjVFT42X3GIdCJjTMVtIjcdlwVUS+rt9b9Xw2e8v8R0sZyfTtnGHIRLrZN5lzVa5WuRUci2VF3oX6DRq1UMsq1McCs9msj2tR7k22urk925F37bGml1R2lKhySJJidixNejkuqX3pvNx1Im+kJrMVzKkADowAAAAAAAAAAAAAAAAAAAAAAAAp1vtk+VCsWa32yfKhXDUL+if11f7Z/4ICfRP6qv9s/8ABAc6/fb9GrfbAADowAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACIrlRES6rsRC1VaNqKOJslQjWYnK3DiRXJ9AzNqxMRM+VUEj6aaOJkr43JHJ+lypsU0Yx0jkaxqucu5ES6qFzE92ANwCgAAAAAAAAAAAAAAAAAAAAAWZf6Gn7n/ErFmX+hp+5/wATn1Pb5bp7uaDIOjIAALtH7B3zfgnIKP2Dvm/BOEDZJFSNWWbZVvfCl+u81ARYfXVD6dYFc1I1tiwsa1XW3XVEuv1K4AA2jkdFI17Fs5q3S6XNQBNUVUtU5qyuRcKYWo1qNRqe5E2IRvkfJhxvc7CmFLreycDUAAAAAAAlp6qopHq+mnlhcqWV0b1aqp9CICYiYxK5wufxSsWGSNZr6xFR71aivcirdUV9sVvdcpgErWtfEYJmZ8hYir6uCF0MNVNHE692MkVGr8UQrgTET2kiZjw2dIr2MaqNsxLJZqIv1VN/1N6efLvV+qjkdZUTWNxI1eNty/W6EQExExgy31rtSkWzAjsSfG1jQAuMAAAgAAAAAAAAAAAAAAAAAAAAAAACnW+2T5UK5YrfbJ8qFcNQv6J/VV/tn/ggJ9E/qq/2z/wQHOv32/Rq32wFmgjWepSFkMUz5EVrUkVyIi+6yptKxfotIQUOGVlJiqmIqMkWRcKLzYbb/rb3HRhNF6OaSlliYlO9qSNurnsciM22s7ZvLsGiZGRTOqtFoxGwSNRUSRLPbZUcqqqpt22VNhzKnTVbUPRyVE0SJZUayaRUunb6zlW5G/SukJGKx9dUua5LKizOVFTqUdKGkVPSprKOm1sTZGuwYbojVRN/UtVHo+6CnqpI2LUTvurWNpnNwORyXwoqbUsvA89FWVMEqyQ1EscjksrmPVFVPiSrpXSCuRy11Srm7lWZ108wO3pLQk8TYpcqkivp1WRXRYGxuRLrbV2RN+zFwOfonRLK+lnmcuLVORHJrkiRjVRfWVVRdhUfpXSEjFY+uqXNcllRZnKip1LdA6gqdGOpKysfRubLrEckava+6W2onalvMCrRaLn0hVSQU6sc6NFVXJdUWy22WQtR+jekXwslfC+NHOsqOjerm79qojVW2w3ptLw6LdKlJC2aVqKyKq2xrZd92Itl919u4pR6Xr45MecqFut3Isz0xfGy3AtP9GtJx1iU60z1Rf8A7rWqrLcbonlv9xUrKJlG3A+dFqmyOZJCjF9W3bi7bm0+mK6d6qtVO1qqioxJnqiW+KqpFPWvqKdscjI1ejlcsyp/Mffmd2gVwAQAAAAAAAAAAB1vRyljqdJXlajmxMV9lTYq9heiqHaa0fpBtSjXOh9eJUaiK3fs8ij6OVUdNpK0rka2Visuu5F7C9FTu0Lo/SDqlWtdN6kSI5FV2/b5mZ8vmeo/9s8/+Ov79/8Al5xrVc5GtS7lWyIh09I0OWoopHyJJPrFbK5FvZbJZL+459PO6mqI5mI1zmLiRHJsudhunoqzGzS0GtiWysbFswqn19/Es5errT1ItE1jMR55bNgq9L6IooYURUjc5rlXYiW3X+im1BS1Wja2SlmkZDHhSV8zEuqImzYqp+CR+mNDSU7adaWoSFu5jVwp9bO2/U3bp3RLJWSNp6lHsZq0XZ+nhbFtM93imerNZrpOJz7Rznn+yhAyWg07LAyJlS992prO1FS9zkOviW6WW+1D0b9L6Fkqm1LqSo1zbWcmy1t2xHWPOyuR8r3Juc5VQ1D2enm0zm1cTiGoAK9QAAAAAAAAAAAAAAAAAABZl/oafuf8SsWZf6Gn7n/E59T2+W6e7nAA6MgAAu0fsHfN+Ccgo/YO+b8E4QNnRvYjVexzUcl23S104oapv2nZdWUekKqKSSKpRzGq3VNakuJLLtuqouzb2KEcYHWlpopYXRUtNUvnRGIuKnw2VEXbscu1U7PcYZHT6PkhzSyRzYF1kTWI+972xIrkstrbP7AUG0kr6ZZ2IjmNVUdZdqWtttw2kJ2anSlM+CRrFme+RiNXFG1iJZtrpZy+7Z7ivBOkui3UMcb3zvkxNRrE2296Lddl9iou8o5xJBA6oerGK1FRqu9ZbbkudGPRUmKla+lkc/FeaNq+sjVXYrk/09vD6EmY0dTTSMZLM9jZHKxGxIqIioqKiKr9y3Tb7gORJG+KRzJGq1zdiovYalqsnfUKsiOVInO2MV6LZbJdbdl+JVIAAAGzGOkVUY1XKiKq2S9k4mpdoKyKmZNHLG9zZkwqrXfpTt2LsXyNRETPdm0zEZiMqRs6N7Gsc5qoj0u1eKXt+C8+PR6QRY31Tdi2elO1Me359vagkfo6VGtx1LGsRUbaJq39/wCrZtvsLqz9T8f0VUp1WkdUX2I9GW+lzRYXpC2VW2jcqtReKpv/ALlieWmSBYabWORVaque1EW6Yuy68UM1bmqykp43tVGRoquRdmJy3X8J9BiCLTlV1b9UsmFcCOw395qdVZNGxSNjc2ZGscivRI0VHK26bld238txTrZYZntWFHKtvWcsbY0X/wDluxOu0TXEeSt5mfCsADDoAAAAAAAAAAAAAAAAAAAAAAAAAACnW+2T5UK5YrfbJ8qFcNQ6Giv1Vf7Z/wCCuWNFfqq/2z/wVznX77fo1b7YAAdGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACzJ/Q0/c/4lYtSf0NP3P+Jz6nt8t093NAB0ZZAAFyj9g75vwTkNH7B3zfgmCBs2R7Guax7mo9LORFtdPeagI2WR7o2xq9ysaqqjVXYl/cagAAAAAAAAAAAAAAGz5HyLeR7nLZEu5b7DUAAAACrdbrvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABUrfbJ8qFcsVvtk+VCuGoX9Ffqq/2z/wVyxor9VX+2f+Cuc6/fb9GrfbAADowAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWpP6Gn7n/EqlqT+hp+5/xOfU9vlunu5wAOjIAALtH7B3zfgmIaT2Dvm/BMEC3Jo2pjljjaxZZJGaxGxXfs+m/wChUTYp0V01NK1yVMFPO5yYVc9qtW10W3qqib0+IRz3NVrla5FRUWyovYZVjkYj1aqMVbI62xVOlQ1cbK7PTSxMc1VvEka3clv9Ntnuuq9TaPTciKyNsFPExq+q5FkbgTb2tdftXqBy2MdItmNVy2VbIl9hbqaBI2tkhfdjkumNUav6Udxt2+RP/G3tqHzMpKRHv/WrWu9b/wBXHaVpq3NNSORrYYmp6rYmqu1Esm9b+ZRUABAAAAAAADq6IoKaup6pJZYWTMdGrEknbEqtuuPCrlRqra29QIYKKGbQtXV45Enp5Y24URMKtdf63uhd0Zoqm0to6OGnlY3SOvu9qo5XanYl0/0rbaqpvVO3ZYu6Qm0bDNVaKonUVLSzsa51TaSRUci4kaqtke1fe5qKS1fpPRQ+kdNXsgWuylM2Fj43uhar0v6yIqKtttkRSK4mktDLQSU7GVMcyTue1rv0NRWvVu1XWtuvt3Gav0d0lTV81GymkqpYWtfJlo3PRqKl07PPcRfxepa6kWJWsWje58Kq1HKiq7Fdb3vtOm/0yqpmIlVQUFRJia9ZXse1yubfC6zXIiKl+xEv2juPOkkkE0LI3yxPY2VMTHOaqI9OKcT0WgtK02jZarSdTVU0ss8D2Po0gc1znKuxEVqI1rV2Kq34pbtLFN6c1j5Y0dBo+n1Seq9de1LJazbMdtT1USypbZt7RkeXp4HTSLaOV8caY5VibdWsRdq/9zpekOhG6FqWNjmdLFKr8GJtlREcqWXipag9L5KVajL6I0ZE2p9qxkciI7Zbn2b12JZNpz9L6bqNNPjdURxRpHfC2JFREvbiqr2IO45oAKgAAAAAAAAAAAAAAAAAAAAAAACpWe2T5UK5YrPbJ8qFcNQv6K/VV/tn/grljRX6qv8AbP8AwVznX77fo1b7YCwtFIlAlYqs1SvwIiLdb/jd2lcvRaVlZStpZYoZ6dv6Y5G2st73u2y+Z0YU3xvjw42ObiTEl0tdOJtTarMxa/2WJMe/d27joTabWpVq1FBRyualkVzXp7+xyISsr4Ww1k7pYtZUw6vLsY+7Vtbeuy3bvW/ACF+icSq+OePA9ztVha6z2o1XXTpay7UU5hfdpJrYKSOnhWNafFdzn4sSu3rayWJJ54IdEZOOdk7nTay7GObhS1tt7XX4J2bwOYDsPrIqh8EGtgghpVa6OSRr3qu66La/RERN5NV+kCSpUIyCnkhe7Dq5VlVXf9dsVkX37wKMOi1lp1c5ytl2Obazmq1WuXsXf6tijJGsbsLlaq2RfVcjk6odBdNSJE2OKlp4kalkVuNVRNuz1nLxU58iMR38tznNsm1zbLft7VA1AAAAAAABJBTzVMiR08T5ZF3Njarl6Iex0N6Cuq9EVElc18NY9F1DXLbCqJsxJ718jzOhdJz6J0lHUU7Ue79Ks5kVdx9mYuNrXLsVyXsfI/1H1PV6OK07RPv8PV6fp1vmZfFa7RNfoxbV1HPToq2R0jFRHL7l3L9Coex/4g6UqJNIt0a5iMp4UbIi86qm/wCl1TqeOPoem6lup0oveMTLh1KxW0xAADuwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFqT+hp+5/wASqWpP6Gn7n/E59T2+W6e7nAA6MgAAu0nsHfN+CYhpPYO+b8EwQAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVKz2yfKhXLFZ7ZPlQrhqF/RX6qv9s/8FcsaK/VV/tn/AIK5zr99v0at9sAAOjAAAAAAAAAAAAAAAAAAAMsc5j2vatnNW6KnYp0pvSPSs9QyZ1bKj2Wwo1bJ0TYpzAZtStpzaMrFpjxK1pHSVVpWqzNbLrJcKNvZE2J8CqAWtYrGIjsTOe8gAKgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWpP6Gn7n/ABKpak/oafuf8Tn1Pb5bp7ucADoyyAALlJ7B3zfgmIaNFWF1k/1fgnwrwXoEYBnCvBegwrwXoEYBnCvBegwrwXoBgGcK8F6DCvBegGAZwrwXoMK8F6AYBnCvBegwrwXoBgGcK8F6DCvBegGAZwrwXoMK8F6AYBnCvBegwrwXoBgGcK8F6DCvBegGAZwrwXoMK8F6AYBnCvBegwrwXoBgGcK8F6DCvBegGAZwrwXoMK8F6AYBnCvBegwrwXoBgGcK8F6DCvBegGAZwrwXoMK8F6AYBnCvBegwrwXoBgGcK8F6DCvBegGAZwrwXoMK8F6AYBnCvBegwrwXoBgGcK8F6DCvBegFOs9snyoQFis9snyoVw1C/or9VX+2f+CsWdEtVz6prUVVWneiInbuNMnU93m8CnKJiL2zPDcxM1jCEE2Tqe7zeBRk6nu83gU3vXljWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEIJsnU93m8CjJ1Pd5vAo3ryazwhBNk6nu83gUZOp7vN4FG9eTWeEJak/oafuf8SPJ1Pd5vApPPFJFoVGyMcxcxezkt/pMXtE4xPu3WJjLmAA6sAAAyjnNSyOVPgpnWP53dTUAbax/O7qNY/nd1NQBtrH87uo1j+d3U1AG2sfzu6jWP53dTUAbax/O7qNY/nd1NQBtrH87uo1j+d3U1AG2sfzu6jWP53dTUAbax/O7qNY/nd1NQBtrH87uo1j+d3U1AG2sfzu6jWP53dTUAbax/O7qNY/nd1NQBtrH87uo1j+d3U1AG2sfzu6jWP53dTUAbax/O7qNY/nd1NQBtrH87uo1j+d3U1AG2sfzu6jWP53dTUAbax/O7qNY/nd1NQBtrH87uo1j+d3U1AG2sfzu6jWP53dTUAbax/O7qNY/nd1NQBtrH87uo1j+d3U1AG2sfzu6jWP53dTUAZVVct1VV+JgADeOWSF2KJ7mKqWu1bEmdqu8zeNSAGZrE+YXMwnztV3mbxqM7Vd5m8akAGleF2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jUZ2q7zN41IANK8G08p87Vd5m8ajO1XeZvGpABpXg2nlPnarvM3jU0kqJpm4ZZpHpe9nOVSMDWseyZkABpAGQBgEscDpWq5qpZFttU3ycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOoycnFnUCuCxk5OLOppJA6JqK5Usq22KBEDIAAAC5S+xd834JSKl9i75vwShkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiqvYt+b8EpFVexb834CqYACgMgC3S+xd834JSKl9i75vwShkLlDomt0kj1o4FlRi2dZUS3UpnsfQnWx09TI1jlY56JdOKJ/7odOnWLWxacOfWtatJmkZlwan0d0pR0756ijcyJiXc5XJs8zmH1H0hmWf0drWYHYtXfbwTap82o6R1ZOrGqqNa1XvciXwtRLqtu0nV1p3iezPp79TqVzeuJQNa562a1XLvsiXMHpPR7RkkEtNpR1fQwwo5WqkkyI5NlrbrXst7XJqHQeiYno+u0nRVDmP/AJjG1OFqtsu6yXVdy7F9x4L+spW0x5xxy9kdG0xDy6RvciK1jlRVVEVE7TVEutk3ns/+U0YxY4q6jdSPqnPZFFPjVrFY5vrdvDied0fQVE9O6qpYJZ5YpWI1kbcVt63VLbthrp+pi0TaYxH+S3SxMQ57mq1ytcio5FsqLvQkZS1EivSOCV6sbjdhYq4W8V4Iet0zQaMR001VWUjZ5HOWS+OSVjl3IjWuRE4bU2cVGjqXR9VJnK6voFSWlZGjJpUV7HIiIuxdy7NinH+OiabxE/t/ty19CdsZePbG96KrWuciWvZL2ubw0755dWxWNd/+yRrE6uVEPX099HxPmn03S1MisYj0zSSKqteiojbputc4dA7R38cnnrZ0ZBG90kaIxXI9b7EsnZ0OlfUzaLTEePmUnpRGMz5cyOnfJPqWujR91S7pGtbs/wCpVt5mskT4nK16JsVUu1UVFtwVNi/Q9NHoShz81S/SWjZI1kxxRrVI26XvZyK1ez+25Sn6SSUv/Lw0roFSNX3SB6Pal8K7FRE2XV3Yhaeq36kUrCW6WtZmXCB6Nno5SoiLNpCJjpYEkihc9EkxK29lS3HYib1v7ij/AAqNPR+WudIqTxz6t0d7YfcqW/P0Nx6np28fiP3SelaHKB6jRmhqSGGlq6ipoUn2PWnqqluF7VRd6YfVXai/6iefQlDW1lRNWabo3Ok2slbUsRU2bEVmGy/FFT4HKfW9OLTHs1HQtMZeRa1z1s1quW17Ilw5qtWzkVF4Kew0fRrRy08k2n6KTUK5EbnMTWsVtvVRU2KcaeNmldORMY9io+NmN2PC1LMTFd1ltuXsU1T1UWtMY7RGcpPSxEcuXFBLM9jYo3OWR2Btk3rwNZI3xSOZI1zHtWzmuSyovvQ9bHo+lhfFT0umaSNkFQ2dHvqEWyKllRFSyKqKnu3puLVdS0tRLC+DS9NDJFKqpL/E1VysXfbZZq7tiHKfXRFsY7N/QnHl4YEk6WnkRH40Ry+ve+LbvIz6ETmHnAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKq9i35vwSkVV7FvzfgKpgyAoAALdL7F3zfglIqX2Lvm/BKGQ7OjvSas0ZRZSCKmWO6uVXx3cqr77nGAV3pfS+vmpZqd0VMjJmOY5dWqqiKllsqrsOTRVs+j6plRTSOjkb2ttu+uwrgk1i0YnwZnOXS0xpmo0vKx0skqsYnqtkc1bL2r6rWp5HNAJSlenWK0jELa02nMhNT1lTSK5aaolhV2xyxvVt/jYhBZiJjEpE48CrdbrvABUAABJmJtRqNbJqVdi1eJcN+Nt1zelrZ6J6ugc1MVro5jXotty2VFS/vIASa1mMTC5nykqKiWqnfPO9ZJZFu5y9qlir0tXV1PFT1VS+SKL9DVt58fqUwTSvbt48fhdp5TT1C1CRYkRFjjSO/FEvb/AOe4hALEREYhJnITUtQtLUsmaiKrV3L2p2oQgTETGJInHcABUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiqvYt+YlIqr2LfmCqgACgAAt03sXfN+CUipvYu+b8EoZAAAAAAGcK4UdZcKra/YYAAAADLWq9yNaiqq7kRN5gAAAAAAAAAAAAM4VVquRFsmxV4GAAAAAzhXDisuG9r9hgAAZa1XORrUVVVbIidoGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKp9i35iUiqfYt+YKqAAKyAALVN7F3zfglIqb2LvmJQyF7+GqsyYZoFhVU9bMRotvgqotyibJIqRqyzbKt74Uv13gWI6RJp544pE/loqtVVSzkRbb9yfEvu0dTOprY6eOVcKq5apjkb2ORERfr28EOc+uqH06wK5qRrbFhY1qutuuqJdfqVwO7LHBSUVTCypikidtj/mtct1bwTdtROztOPSta+pjY5qOR7sO1FXfsvsVCIsQV09MzDC5rd9nYGq5t0stnKl0+hR05NFrVOqZ3SRLhYmHDKxvrIiIt0VdnkVKnRjYaVJmVcD3JsfHrGYvilnLdOi+4qxVU0McjI32bKlnIqIt+u7epG56ua1qo2zUslmonXj9QOvTNp8vRup5YEqIpEfJd2rdbhd1r7uxfpxTUEdbWPkdWwMY5Go12sjtdEst0xIqJs4KcYASzs1T9SqRq5iqiyRuxI/63t0IjZZHuY1jnuVrb4WquxL77GpAAAAAAXYKJrlnSVcTok/Q2RrVVbXVfW32tuQsMpGLQ6lZIGSucjnWmjW6J23xWv6y7LpuIJdKzSUiw2Rr3+0lRERz07EWyJs+NyiTu463t57O5TwxUL5ESqilp3KxcWsZtW+31Ucu669DjshV7cWJEbiRt195GWqKtWkct2NljVbrG9rVRVTdvRfK3xGFilqxMx3liup2U06MZfDhRcWNr8XvTDs+h1U0axIMtU1cCauRzWXkaqtRbetbGlty8fgcxNJ1STvmxtWR7sV3sR1l7LXRbfQqucr3K5yq5yrdVVdqqMSzNL2iImcYdyGOKlgs+WBrXI3G1szX+t6yKtrr2KinNpKWCaGWWpqFgYzYiozFiXgm1P8A5wKhYgq1hifE6KKaNy3wyIuxeKKioqdRhdLViZie8sQwMqKxkEb3YXuwtc5tl27rpf8AJ0aelfDEjVfQo5j0kbIk7Md9my+LcUW6Qmja5sKMia66IjGJdqLvRHLdyJ9SqFmtreXQ0ijZ6yNkLmvct2+qqLdcS22/CxtJopmNUgraeRmC+J0jGXdy2xee4oRSuhlbIy2Jq3S6XN6idk63bTRQre66vFt6qvkDW0Yis9lyfRkMVKsqVUWsRiOWNsrH3XtS6Le/0VPeVqqkSmjp3tlSRJmY9nZ7iGKR0MiPZbEnFEVOi7FNp6iWpkR8rrqiI1LIiIiJ2IibEHda1vE957PrXo96K6FqfRnR88+j4pJZImue917qqr8Thf8AEbQOjdFUNJNQUjKd7pVauC+1LKv4PM03pdpWkp4oIpkSOJqNall2Im7tK2k/SCv0vCyKslR7GOxIlu3cbxHnLpmcYw5gAMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEVT7FvzEpFU+xb8wVVAAUAAFqm9i75iUjpvYu+YkDIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABFU+xb8xKR1PsW/MFVAAFAZAFqm9i75iQjpvYu+YkDIiXWxvKzVSOZe9u00LMsSOSSZXs2oioiPbdfpvArAlZCj1iu/Cj1VLqm4nq4WRsiY3DjaqtdZU2+9bKvmBTstr22AsxRK5s0ePCxHJiVy2Tt/99hvJRRojlZOxXbMLVe3anxv+CimERVWyJdVLCUzXSyMSRPUZi2Ki3W17bzSJrmvie291fssnAgiBdfTtmfI90zGqqeqmJu1bbl27COsbG18erw/oS6NVF2/RVKKwJ4ad0jEka6PY6yo9yNTzXaTyw61zExQN9ZVcjHtREvbddfcBRRFXclwXo6ZsSYknjx7UciSN3Ki+/aV3prahcGHbt2qjUAhBMsSLUOjaqW22tt7L9hvDSJLE2TWMRFVUVFciW4b1IKwVLLZdil9IcMCxskja5Uurtazb/wBO+5FU4ZJmpjbdXLide9rrx+pRVBJLCscsjL3wLv4m+W/k63WMthuiK5L9L3IIBZbXtsLeXvTNwyRqr1R3rORtt6b1UkSOOBi2mY6N1l/Wi7dqbt/aUUAT08OsRz1e1mDaiutZV4bV/wByzHAirLjli1bnYkTWN27+zEnH3Ac8FiphbC1qNcxy3VLtci3TsVbKtiuQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACOp9i35iQjqfYt+YKqAyAoAALVP7F3zEhHT+xX5iQMhIyVY22a1l73xK26/DaRgCfOTYr4m3RLJ6ier8Nmz6EG8ACSSeWVESSV70TcjnKtjRFsqKqItuxe0wAJlqZFa5qYWtdsXCxE2cL77GrJ5Y2q2OV7GrvRrlRFIwAMtcrXI5N6GABJLM+a2NUs3YiIiIifRDRrlat0t9UuYAAAAStqJGx4GqiIqWujUvbhfeH1Mj7YsKoiWRqMRE6J/ciAGz343Xwtb7mpZENopnwrdmG/vai/3IwBIyZ8bnORUVXb8SI5F+NzCyvdIkiqiuTdsS3TdY0AG8kr5nIr1TYlkRERERPghoABnEuHD2XuYAAyjlaioiqiKllsu8wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI6j2LfmJCOo9inzBVUABQGQEWaf2K/MSEdP7FfmJAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABHUexT5iQjqPYp8wVVBkAAABNDK2Nitcirdb7DfMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XDMR8risALOYj5XGk0zXsRrUVLLfaQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//2Q==",
        "lastScreenshotTime": "2026-08-22T01:46:31.883Z",
        "currentTraineeName": "مرام محمد رمضان بخيت",
        "currentTraineeId": "trainee-1787361330810-d1if"
    },
    {
        "id": "dev-1787464212308",
        "deviceId": "PC-83",
        "name": "جهاز PC-83",
        "assignedUser": "مرام محمد رمضان بخيت",
        "userType": "trainee",
        "branchId": "branch-1",
        "ipAddress": "ais-dev-7wkppak7c63am6ebvulppu-481160813332.europe-west2.run.app",
        "lastHeartbeat": "2026-08-23T06:32:38.297Z",
        "isOnline": false,
        "status": "active",
        "lastScreenshotUrl": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCADhAZADASIAAhEBAxEB/8QAGgABAAMBAQEAAAAAAAAAAAAAAAIDBAUBBv/EADEQAQACAgEDAgQEBAcAAAAAAAABAgMRBBIhMRNBBSJRgWFxkaEUFTLxM0RiorHR8P/EABgBAQEBAQEAAAAAAAAAAAAAAAABAgME/8QAIhEBAQACAQQCAwEAAAAAAAAAAAECETEDEiHwUbFBcYHh/9oADAMBAAIRAxEAPwD4IB0QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAX8Xjzysk44vWluncdXifw/A4+TFWL0zYrXrfX9N+iYn85iYa68vjcWLY8fGydUTOpnkVtG9a9q94+7nnllxjPprGTm1ithmuG2SbV+W/RNe+9/8J5ONNMFc0Wi1ZiJn2mJmZjX+2WvF8Q4eKMmuFe03t1fPlraI8+Imkx7qeVzceXFOPDgnFSfab9Wu8z27R27szLqW8fS6x1yzYcN81umle24ibe1dzrvPshaJraaz5idNnGxRhpPIyZME06J6a9cTabe3yx3jv7y1xn4M/Dsl4xXibZYtbH69dzP3r4+317/AFZdSy+JsmMs8uTSlrzMUrNpiJmYiN9l/F4k8jHlyerjxUxRE2tffvOvaJXc7Lxs81imCvHyVjc3jJFq37biNUrEb/L7vOByq8bicuN19TJWsUi1ItE6nv2mJhbllcdyef8ASSS+Xn8tydf+Li9L0/U9bc9PT4+m/PbWlPI41uP0T1VyUvG6XpvVv17tWHm+vj5GHl5YpGWlYreK6rSazuI1WO0efEKbzxePquOtOVaa/Na3VFYn/TqYn9Uxyzl1l7/ff0WY68Pcnw3NjwerN8czEVtam53WLeJntr90ORw7YMUZYy4suObTSbY5mYi0e3eI/wCm/PyuLfhXp609M0pWmOKz11mPPVPiY86jc+e2mfl5cMfD6ceuema1ckzSaUmkVrr37RuZ7fXx5Zwzztm/n499+Wrjj+HPAehyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOtJtS1txEV1593TyfC+ZzK/xGLHveOtorFJjq+WN6nWv32xl1MceWpjbw5I21+E8+3+UzV+WZ745/Tx5R5vBycKMXqTv1K78eJ94/H+5OphbqU7MpN6ZBr4fAzczXpVm0dUVt01mZrvxM69lvxH4d/B0pPTlraO1/ViKxafrT6wXqYzLt35Oy6254vwYJ5PyYMd7Za1mZiO/V39o/unk4HJw8e+XPhy4orMRHXjmN7/ABle/GXVqdt5ZRu4nw7LyOm0Y8t8dqzPXipNumY9p/T94aLfBs9cmS+HHliKVi2Ot6fNftue3/u+oYvWwl1a1OnlZvTkjf8AFsdaZ41WK2mbdUa1P9U+3t2n9mBvDLum2bNXQA0gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC7ByMnH6vT6dW7TF6RaJ+0xMPMue2a17ZYra9tfN41r2iI7a+yoTtm9m7wJVnptFtROp3qfEoijXPMpasUtxcdcddzGOkzETb6zMzMz+W4ZASYycLbalN5mtazEar41WIn7z7p1y1rli/oY5rrU0nq1P77/dUGom13I5FuRaszWlK1jprSkaisKQJJJqFuwBQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//2Q==",
        "lastArchivedTime": "2026-08-23T06:32:12.588Z",
        "currentTraineeName": "مرام محمد رمضان بخيت",
        "currentTraineeId": "trainee-1787361330810-d1if"
    }
],
  deviceCommands: [
    {
        "id": "cmd-1787353097554-p0hu",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T22:58:17.554Z"
    },
    {
        "id": "cmd-1787353106454-soht",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T22:58:26.454Z"
    },
    {
        "id": "cmd-1787354001394-29ga",
        "deviceId": "PC-71",
        "commandType": "shutdown",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:13:21.394Z"
    },
    {
        "id": "cmd-1787354006700-aj23",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:13:26.700Z"
    },
    {
        "id": "cmd-1787354015351-86zr",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:13:35.351Z"
    },
    {
        "id": "cmd-1787354026862-rr6k",
        "deviceId": "PC-71",
        "commandType": "reboot",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:13:46.862Z"
    },
    {
        "id": "cmd-1787354029696-im13",
        "deviceId": "PC-71",
        "commandType": "shutdown",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:13:49.696Z"
    },
    {
        "id": "cmd-1787354031215-0bch",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:13:51.215Z"
    },
    {
        "id": "cmd-1787354032145-aecj",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:13:52.145Z"
    },
    {
        "id": "cmd-1787354032335-4ijw",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:13:52.335Z"
    },
    {
        "id": "cmd-1787354041352-4hy8",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:14:01.352Z"
    },
    {
        "id": "cmd-1787354064072-vh8f",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "يرجى الانتباه للشرح على شاشة العرض الرئيسية الآن",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:14:24.072Z"
    },
    {
        "id": "cmd-reinf-1787356276902-vhwg",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"reinforcement\",\"title\":\"إجابة نموذجية وإبداع برمجي!\",\"message\":\"طريقة تفكير وحل استثنائي يستحق الإشادة!\",\"stars\":2,\"points\":21,\"icon\":\"💡\",\"trainerName\":\"المدرب\",\"badgeText\":\"إجابة ذكية 💡\",\"reinforcementType\":\"star_award\",\"traineeStats\":{\"id\":\"trainee-1787347185722-0aw8\",\"fullName\":\"مرام محمد رمضان بخيت\",\"code\":\"م001\",\"points\":86,\"totalPoints\":86,\"starsCount\":8,\"overallRank\":1,\"totalTrainees\":93,\"groupRank\":1,\"groupTotal\":1,\"tierName\":\"متقدم ذهبي 🏆\",\"badgeColor\":\"bg-yellow-500/20 text-yellow-300 border-yellow-500/40\",\"rankBadge\":\"🥇\",\"courseName\":\"ICT-P1\",\"groupName\":\"المجموعة التدريبية\"},\"timestamp\":1787356276902}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-21T23:51:16.902Z"
    },
    {
        "id": "cmd-1787356296742-0kh6",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"clean_reset\"}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:51:36.742Z"
    },
    {
        "id": "cmd-reinf-1787356402355-v7bl",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"reinforcement\",\"title\":\"تقدير وتميز للمتدرب (جهاز PC-71) 🌟\",\"message\":\"إجابة متقنة وتطبيق عملي متميز خلال التمرين!\",\"stars\":1,\"points\":6,\"icon\":\"⭐\",\"trainerName\":\"المدرب\",\"badgeText\":\"نجم الحصة 🌟\",\"reinforcementType\":\"star_award\",\"traineeStats\":{\"id\":\"trainee-1787347185722-0aw8\",\"fullName\":\"مرام محمد رمضان بخيت\",\"code\":\"م001\",\"points\":92,\"totalPoints\":92,\"starsCount\":9,\"overallRank\":1,\"totalTrainees\":93,\"groupRank\":1,\"groupTotal\":1,\"tierName\":\"متقدم ذهبي 🏆\",\"badgeColor\":\"bg-yellow-500/20 text-yellow-300 border-yellow-500/40\",\"rankBadge\":\"🥇\",\"courseName\":\"ICT-P1\",\"groupName\":\"المجموعة التدريبية\"},\"timestamp\":1787356402355}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-21T23:53:22.355Z"
    },
    {
        "id": "cmd-1787356411197-0s5l",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:53:31.197Z"
    },
    {
        "id": "cmd-1787356414736-jjr2",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-21T23:53:34.736Z"
    },
    {
        "id": "cmd-1787359735524-d1qd",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T00:48:55.524Z"
    },
    {
        "id": "cmd-1787359750791-8wfc",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T00:49:10.791Z"
    },
    {
        "id": "cmd-1787359794426-l3ti",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"start_broadcast\",\"trainerName\":\"مدرب المعمل\"}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-22T00:49:54.426Z"
    },
    {
        "id": "cmd-1787359844994-ulcx",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T00:50:44.994Z"
    },
    {
        "id": "cmd-1787359857348-su60",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"clean_reset\"}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T00:50:57.348Z"
    },
    {
        "id": "cmd-1787359891812-c3rp",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T00:51:31.812Z"
    },
    {
        "id": "cmd-1787359897685-4kor",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T00:51:37.685Z"
    },
    {
        "id": "cmd-1787361823607-h42c",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"start_broadcast\",\"trainerName\":\"مدرب المعمل\"}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-22T01:23:43.607Z"
    },
    {
        "id": "cmd-1787361853660-46fb",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"open_url\",\"url\":\"https://ekb.eg\"}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-22T01:24:13.660Z"
    },
    {
        "id": "cmd-1787361946709-9afo",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T01:25:46.709Z"
    },
    {
        "id": "cmd-1787361949497-kdv9",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T01:25:49.497Z"
    },
    {
        "id": "cmd-1787361966040-apct",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"open_url\",\"url\":\"https://ekb.eg\"}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-22T01:26:06.040Z"
    },
    {
        "id": "cmd-reinf-1787362006056-hcvq",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"reinforcement\",\"title\":\"تحية وتشجيع لجميع متدربي القاعة! 🚀\",\"message\":\"تفاعل ممتاز وجهد جماعي رائع في هذا التمرين التدريبي!\",\"stars\":5,\"points\":51,\"icon\":\"🌟\",\"trainerName\":\"المدرب\",\"badgeText\":\"أبطال المعمل 🏆\",\"reinforcementType\":\"star_award\",\"traineeStats\":{\"id\":\"trainee-1787361330810-d1if\",\"fullName\":\"مرام محمد رمضان بخيت\",\"code\":\"A001\",\"points\":91,\"totalPoints\":91,\"starsCount\":9,\"overallRank\":1,\"totalTrainees\":2,\"groupRank\":1,\"groupTotal\":1,\"tierName\":\"متقدم ذهبي 🏆\",\"badgeColor\":\"bg-yellow-500/20 text-yellow-300 border-yellow-500/40\",\"rankBadge\":\"🥇\",\"courseName\":\"ICT-P1\",\"groupName\":\"ICT - p1 - 2\"},\"timestamp\":1787362006056}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-22T01:26:46.056Z"
    },
    {
        "id": "cmd-1787362019251-7w0k",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"start_broadcast\",\"trainerName\":\"مدرب المعمل\"}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-22T01:26:59.251Z"
    },
    {
        "id": "cmd-1787362097808-gd69",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"clean_reset\"}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T01:28:17.808Z"
    },
    {
        "id": "cmd-1787362348513-a1gq",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"interactive_question\",\"question\":{\"id\":\"q-1787362348311\",\"text\":\"ما هي الدالة المسؤولة عن تشغيل كود عند تحميل المكون في React؟\",\"options\":[\"useState()\",\"useEffect()\",\"useRef()\",\"useMemo()\"],\"correctOptionIndex\":1,\"points\":15,\"timeLimitSeconds\":30},\"sessionId\":\"is-1787362337448\"}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T01:32:28.513Z"
    },
    {
        "id": "cmd-1787362373263-ez7g",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"interactive_question\",\"question\":{\"id\":\"q-1787362373107\",\"text\":\"ما هي الدالة المسؤولة عن تشغيل كود عند تحميل المكون في React؟\",\"options\":[\"useState()\",\"useEffect()\",\"useRef()\",\"useMemo()\"],\"correctOptionIndex\":1,\"points\":15,\"timeLimitSeconds\":30},\"sessionId\":\"is-1787362337448\"}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T01:32:53.263Z"
    },
    {
        "id": "cmd-1787362689677-yjfn",
        "deviceId": "PC-74",
        "commandType": "message",
        "payload": "{\"action\":\"interactive_question\",\"question\":{\"id\":\"q-1787362688971\",\"text\":\"ما هي الدالة المسؤولة عن تشغيل كود عند تحميل المكون في React؟\",\"options\":[\"useState()\",\"useEffect()\",\"useRef()\",\"useMemo()\"],\"correctOptionIndex\":1,\"points\":15,\"timeLimitSeconds\":30},\"sessionId\":\"is-1787362644609\"}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T01:38:09.677Z"
    },
    {
        "id": "cmd-1787362689678-ea43",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"interactive_question\",\"question\":{\"id\":\"q-1787362688971\",\"text\":\"ما هي الدالة المسؤولة عن تشغيل كود عند تحميل المكون في React؟\",\"options\":[\"useState()\",\"useEffect()\",\"useRef()\",\"useMemo()\"],\"correctOptionIndex\":1,\"points\":15,\"timeLimitSeconds\":30},\"sessionId\":\"is-1787362644609\"}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-22T01:38:09.678Z"
    },
    {
        "id": "cmd-reinf-1787362796188-fq1i",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"reinforcement\",\"title\":\"تحية وتشجيع لجميع متدربي القاعة! 🚀\",\"message\":\"تفاعل ممتاز وجهد جماعي رائع في هذا التمرين التدريبي!\",\"stars\":5,\"points\":51,\"icon\":\"🌟\",\"trainerName\":\"المدرب\",\"badgeText\":\"أبطال المعمل 🏆\",\"reinforcementType\":\"star_award\",\"traineeStats\":{\"id\":\"trainee-1787361410293-aeko\",\"fullName\":\"رفيف محمد رمضان بخيت\",\"code\":\"A002\",\"points\":80,\"totalPoints\":80,\"starsCount\":8,\"overallRank\":2,\"totalTrainees\":2,\"groupRank\":1,\"groupTotal\":1,\"tierName\":\"متقدم ذهبي 🏆\",\"badgeColor\":\"bg-yellow-500/20 text-yellow-300 border-yellow-500/40\",\"rankBadge\":\"🥈\",\"courseName\":\"ICT5\",\"groupName\":\"ICT - p1 - 1\"},\"timestamp\":1787362796188}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-22T01:39:56.188Z"
    },
    {
        "id": "cmd-reinf-1787362796188-vx8o",
        "deviceId": "PC-74",
        "commandType": "message",
        "payload": "{\"action\":\"reinforcement\",\"title\":\"تحية وتشجيع لجميع متدربي القاعة! 🚀\",\"message\":\"تفاعل ممتاز وجهد جماعي رائع في هذا التمرين التدريبي!\",\"stars\":5,\"points\":51,\"icon\":\"🌟\",\"trainerName\":\"المدرب\",\"badgeText\":\"أبطال المعمل 🏆\",\"reinforcementType\":\"star_award\",\"traineeStats\":{\"id\":\"trainee-1787361330810-d1if\",\"fullName\":\"مرام محمد رمضان بخيت\",\"code\":\"A001\",\"points\":142,\"totalPoints\":142,\"starsCount\":14,\"overallRank\":1,\"totalTrainees\":2,\"groupRank\":1,\"groupTotal\":1,\"tierName\":\"متقدم ذهبي 🏆\",\"badgeColor\":\"bg-yellow-500/20 text-yellow-300 border-yellow-500/40\",\"rankBadge\":\"🥇\",\"courseName\":\"ICT-P1\",\"groupName\":\"ICT - p1 - 2\"},\"timestamp\":1787362796188}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-22T01:39:56.188Z"
    },
    {
        "id": "cmd-1787465198118-7q91",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:06:38.118Z"
    },
    {
        "id": "cmd-1787465198120-pvb9",
        "deviceId": "PC-74",
        "commandType": "unlock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:06:38.120Z"
    },
    {
        "id": "cmd-1787465198123-ij0i",
        "deviceId": "PC-83",
        "commandType": "unlock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:06:38.123Z"
    },
    {
        "id": "cmd-1787465201407-6aig",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:06:41.407Z"
    },
    {
        "id": "cmd-1787465201413-919a",
        "deviceId": "PC-74",
        "commandType": "lock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:06:41.413Z"
    },
    {
        "id": "cmd-1787465201417-a9n3",
        "deviceId": "PC-83",
        "commandType": "lock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:06:41.417Z"
    },
    {
        "id": "cmd-1787465219889-1xrf",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:06:59.889Z"
    },
    {
        "id": "cmd-1787465219898-dti6",
        "deviceId": "PC-74",
        "commandType": "unlock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:06:59.898Z"
    },
    {
        "id": "cmd-1787465219906-aue4",
        "deviceId": "PC-83",
        "commandType": "unlock",
        "payload": "{}",
        "status": "delivered",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:06:59.906Z"
    },
    {
        "id": "cmd-1787465249309-e2bi",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:07:29.309Z"
    },
    {
        "id": "cmd-1787465249333-45kp",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:07:29.333Z"
    },
    {
        "id": "cmd-1787465249341-is12",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:07:29.341Z"
    },
    {
        "id": "cmd-1787465251082-86ej",
        "deviceId": "PC-71",
        "commandType": "lock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:07:31.082Z"
    },
    {
        "id": "cmd-1787465255242-lpet",
        "deviceId": "PC-71",
        "commandType": "unlock",
        "payload": "{}",
        "status": "pending",
        "issuedByUserId": "admin",
        "createdAt": "2026-08-23T06:07:35.242Z"
    },
    {
        "id": "cmd-reinf-1787465508933-i05s",
        "deviceId": "PC-71",
        "commandType": "message",
        "payload": "{\"action\":\"reinforcement\",\"title\":\"مشاركة وتعاون متميز!\",\"message\":\"دعم ومساعدة الزملاء في حل التحديات البرمجية!\",\"stars\":2,\"points\":16,\"icon\":\"🤝\",\"trainerName\":\"المدرب\",\"badgeText\":\"تعاون مثالي 🤝\",\"reinforcementType\":\"star_award\",\"traineeStats\":{\"id\":\"trainee-1787361410293-aeko\",\"fullName\":\"رفيف محمد رمضان بخيت\",\"code\":\"A002\",\"points\":200,\"totalPoints\":200,\"starsCount\":20,\"overallRank\":2,\"totalTrainees\":3,\"groupRank\":1,\"groupTotal\":1,\"tierName\":\"متألق أسطوري 🌟\",\"badgeColor\":\"bg-amber-500/20 text-amber-300 border-amber-500/40\",\"rankBadge\":\"🥈\",\"courseName\":\"ICT5\",\"groupName\":\"ICT5 - 1\"},\"timestamp\":1787465508933}",
        "status": "pending",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-23T06:11:48.933Z"
    },
    {
        "id": "cmd-reinf-1787465508933-sin1",
        "deviceId": "PC-74",
        "commandType": "message",
        "payload": "{\"action\":\"reinforcement\",\"title\":\"مشاركة وتعاون متميز!\",\"message\":\"دعم ومساعدة الزملاء في حل التحديات البرمجية!\",\"stars\":2,\"points\":16,\"icon\":\"🤝\",\"trainerName\":\"المدرب\",\"badgeText\":\"تعاون مثالي 🤝\",\"reinforcementType\":\"star_award\",\"traineeStats\":{\"id\":\"trainee-1787361330810-d1if\",\"fullName\":\"مرام محمد رمضان بخيت\",\"code\":\"A001\",\"points\":383,\"totalPoints\":383,\"starsCount\":38,\"overallRank\":1,\"totalTrainees\":3,\"groupRank\":1,\"groupTotal\":1,\"tierName\":\"متألق أسطوري 🌟\",\"badgeColor\":\"bg-amber-500/20 text-amber-300 border-amber-500/40\",\"rankBadge\":\"🥇\",\"courseName\":\"ICT-P1\",\"groupName\":\"ICT - p1 - 2\"},\"timestamp\":1787465508933}",
        "status": "pending",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-23T06:11:48.933Z"
    },
    {
        "id": "cmd-reinf-1787465508933-1vz5",
        "deviceId": "PC-83",
        "commandType": "message",
        "payload": "{\"action\":\"reinforcement\",\"title\":\"مشاركة وتعاون متميز!\",\"message\":\"دعم ومساعدة الزملاء في حل التحديات البرمجية!\",\"stars\":2,\"points\":16,\"icon\":\"🤝\",\"trainerName\":\"المدرب\",\"badgeText\":\"تعاون مثالي 🤝\",\"reinforcementType\":\"star_award\",\"traineeStats\":{\"id\":\"trainee-1787361330810-d1if\",\"fullName\":\"مرام محمد رمضان بخيت\",\"code\":\"A001\",\"points\":383,\"totalPoints\":383,\"starsCount\":38,\"overallRank\":1,\"totalTrainees\":3,\"groupRank\":1,\"groupTotal\":1,\"tierName\":\"متألق أسطوري 🌟\",\"badgeColor\":\"bg-amber-500/20 text-amber-300 border-amber-500/40\",\"rankBadge\":\"🥇\",\"courseName\":\"ICT-P1\",\"groupName\":\"ICT - p1 - 2\"},\"timestamp\":1787465508933}",
        "status": "delivered",
        "issuedByUserId": "trainer",
        "createdAt": "2026-08-23T06:11:48.933Z"
    },
    {
        "id": "cmd-1787465546210-zzpk",
        "deviceId": "dev-1787352892067",
        "commandType": "message",
        "payload": "{\"action\":\"interactive_question\",\"question\":{\"id\":\"q-1787465545797\",\"text\":\"يتم استخدام حرف ........ داخل دائرة وهو الرمز الدولي لحماية حقوق النشر.\",\"options\":[\"A\",\"B\",\"C\",\"D\"],\"correctOptionIndex\":0,\"points\":5,\"timeLimitSeconds\":30},\"sessionId\":\"is-1787362644609\"}",
        "issuedByUserId": "trainer-live",
        "createdAt": "2026-08-23T06:12:26.210Z",
        "issuedAt": "2026-08-23T06:12:26.211Z",
        "status": "pending"
    },
    {
        "id": "cmd-1787465546211-41zl",
        "deviceId": "dev-1787362571450",
        "commandType": "message",
        "payload": "{\"action\":\"interactive_question\",\"question\":{\"id\":\"q-1787465545797\",\"text\":\"يتم استخدام حرف ........ داخل دائرة وهو الرمز الدولي لحماية حقوق النشر.\",\"options\":[\"A\",\"B\",\"C\",\"D\"],\"correctOptionIndex\":0,\"points\":5,\"timeLimitSeconds\":30},\"sessionId\":\"is-1787362644609\"}",
        "issuedByUserId": "trainer-live",
        "createdAt": "2026-08-23T06:12:26.211Z",
        "issuedAt": "2026-08-23T06:12:26.211Z",
        "status": "pending"
    },
    {
        "id": "cmd-1787465546211-4no7",
        "deviceId": "dev-1787464212308",
        "commandType": "message",
        "payload": "{\"action\":\"interactive_question\",\"question\":{\"id\":\"q-1787465545797\",\"text\":\"يتم استخدام حرف ........ داخل دائرة وهو الرمز الدولي لحماية حقوق النشر.\",\"options\":[\"A\",\"B\",\"C\",\"D\"],\"correctOptionIndex\":0,\"points\":5,\"timeLimitSeconds\":30},\"sessionId\":\"is-1787362644609\"}",
        "issuedByUserId": "trainer-live",
        "createdAt": "2026-08-23T06:12:26.211Z",
        "issuedAt": "2026-08-23T06:12:26.211Z",
        "status": "pending"
    },
    {
        "id": "cmd-1787465607959-4kac",
        "deviceId": "dev-1787352892067",
        "commandType": "message",
        "payload": "{\"action\":\"interactive_question\",\"question\":{\"id\":\"q-1787465607546\",\"text\":\"..... هي بوابة تستخدم لتوصيل جهاز الكمبيوتر بالإنترنت.\",\"options\":[\"word\",\"الراوتر\",\"بنك المعرفة المصري\",\"لوحة المفاتيح\"],\"correctOptionIndex\":0,\"points\":5,\"timeLimitSeconds\":30},\"sessionId\":\"is-1787362644609\"}",
        "issuedByUserId": "trainer-live",
        "createdAt": "2026-08-23T06:13:27.959Z",
        "issuedAt": "2026-08-23T06:13:27.959Z",
        "status": "pending"
    },
    {
        "id": "cmd-1787465607959-1z3r",
        "deviceId": "dev-1787362571450",
        "commandType": "message",
        "payload": "{\"action\":\"interactive_question\",\"question\":{\"id\":\"q-1787465607546\",\"text\":\"..... هي بوابة تستخدم لتوصيل جهاز الكمبيوتر بالإنترنت.\",\"options\":[\"word\",\"الراوتر\",\"بنك المعرفة المصري\",\"لوحة المفاتيح\"],\"correctOptionIndex\":0,\"points\":5,\"timeLimitSeconds\":30},\"sessionId\":\"is-1787362644609\"}",
        "issuedByUserId": "trainer-live",
        "createdAt": "2026-08-23T06:13:27.959Z",
        "issuedAt": "2026-08-23T06:13:27.959Z",
        "status": "pending"
    },
    {
        "id": "cmd-1787465607959-f87n",
        "deviceId": "dev-1787464212308",
        "commandType": "message",
        "payload": "{\"action\":\"interactive_question\",\"question\":{\"id\":\"q-1787465607546\",\"text\":\"..... هي بوابة تستخدم لتوصيل جهاز الكمبيوتر بالإنترنت.\",\"options\":[\"word\",\"الراوتر\",\"بنك المعرفة المصري\",\"لوحة المفاتيح\"],\"correctOptionIndex\":0,\"points\":5,\"timeLimitSeconds\":30},\"sessionId\":\"is-1787362644609\"}",
        "issuedByUserId": "trainer-live",
        "createdAt": "2026-08-23T06:13:27.959Z",
        "issuedAt": "2026-08-23T06:13:27.959Z",
        "status": "pending"
    }
],
  certificates: [
    {
        "id": "cert-1787450838230",
        "certificateNumber": "CERT-2026-38230",
        "serialNumber": "CERT-2026-38230",
        "traineeId": "trainee-1787361410293-aeko",
        "traineeName": "رفيف محمد رمضان بخيت",
        "courseId": "course-1787347401956",
        "courseName": "ICT4",
        "branchId": "branch-1",
        "issueDate": "2026-08-23",
        "grade": "امتياز مع مرتبة الشرف (A+)",
        "durationText": "30 ساعة تدريبية معتمدة",
        "qrPayload": "{\"certificateNumber\":\"CERT-2026-38230\",\"traineeName\":\"رفيف محمد رمضان بخيت\",\"courseName\":\"ICT4\",\"issueDate\":\"2026-08-23\",\"center\":\"مركز النجاح للتدريب والاستشارات\"}",
        "trainerName": "المدرب المعتمد",
        "managerName": "د. محمد رمضان بخيت",
        "templateId": "template-1787450798128"
    },
    {
        "id": "cert-1787347853394",
        "certificateNumber": "CERT-2026-53394",
        "serialNumber": "CERT-2026-53394",
        "traineeId": "trainee-1787347185722-0aw8",
        "traineeName": "مرام محمد رمضان بخيت",
        "courseId": "course-1787347401956",
        "courseName": "ICT4",
        "branchId": "branch-1",
        "issueDate": "2026-08-21",
        "grade": "ممتاز مع مرتبة الشرف",
        "durationText": "64 ساعة تدريبية",
        "qrPayload": "{\"certificateNumber\":\"CERT-2026-53394\",\"traineeName\":\"مرام محمد رمضان بخيت\",\"courseName\":\"ICT4\",\"issueDate\":\"2026-08-21\",\"center\":\"مركز النجاح للتدريب والاستشارات\"}",
        "trainerName": "المدرب المعتمد",
        "managerName": "مدير عام المركز"
    }
],
  certificateTemplates: [
    {
      id: 'template-nagah-official-ar',
      name: 'الشهادة المعتمدة الرسمية - عربي (مجلس الاعتماد)',
      theme: 'classic_gold',
      primaryColor: '#c59b27',
      accentColor: '#96741b',
      titleArabic: 'شــهــادة',
      titleEnglish: 'CERTIFICATE',
      subTitleArabic: 'تشهد أكاديمية النجاح للتدريب والاستشارات',
      bodyTemplate: 'أن المشارك قد اجتاز البرنامج التدريبي بنجاح وشارك بتميز وفاعلية مع التمنيات بدوام التوفيق',
      sealText: 'NGAH T&CN - معتمد',
      managerTitle: 'يعتمد: مدير الأكاديمية',
      managerName: 'د. محمد رمضان بخيت',
      trainerTitle: 'المدرب',
      showQrCode: true,
      borderStyle: 'double',
      isDefault: true
    },
    {
      id: 'template-nagah-official-en',
      name: 'Accredited Official Certificate - English (Accreditation Board)',
      theme: 'classic_gold',
      primaryColor: '#c59b27',
      accentColor: '#96741b',
      titleArabic: 'شــهــادة معتمدة بالإنجليزية',
      titleEnglish: 'CERTIFICATE OF COMPLETION',
      subTitleArabic: 'THIS CERTIFICATE IS PROUDLY PRESENTED TO',
      bodyTemplate: 'Successfully Completed Training Program with Distinction & High Performance',
      sealText: 'NGAH ACCREDITED',
      managerTitle: 'Academy Director',
      managerName: 'Dr. Mohamed Bkeet',
      trainerTitle: 'Trainer',
      showQrCode: true,
      borderStyle: 'double',
      isDefault: false
    },
    {
      id: 'template-tech',
      name: 'النموذج المودرن التكنولوجي (Modern Tech)',
      theme: 'modern_tech',
      primaryColor: '#2563eb',
      accentColor: '#1d4ed8',
      titleArabic: 'أكاديمية النجاح لعلوم الحاسب والتكنولوجيا',
      titleEnglish: 'NGAH TECH & CONSULTING ACADEMY',
      subTitleArabic: 'شهادة كفاءة واجتياز تدريبي تخصصي',
      bodyTemplate: 'نقر بأن المتدرب قد أتم جميع المشاريع والتطبيقات العملية والمهام البرمجية بنجاح وحصل على درجة الكفاءة العالية.',
      sealText: 'مصدق إلكترونياً',
      managerTitle: 'مدير البرامج التقنية',
      managerName: 'إدارة مركز النجاح',
      trainerTitle: 'كبير المدربين والمطورين',
      showQrCode: true,
      borderStyle: 'modern',
      isDefault: false
    },
    {
      id: 'template-emerald',
      name: 'النموذج الأكاديمي الزمردي (Academic Emerald)',
      theme: 'royal_emerald',
      primaryColor: '#059669',
      accentColor: '#047857',
      titleArabic: 'مركز النجاح للتأهيل والتطوير المهني',
      titleEnglish: 'NGAH PROFESSIONAL DEVELOPMENT CENTER',
      subTitleArabic: 'شهادة تفوق وتقدير مهني معتمد',
      bodyTemplate: 'تقديراً للأداء الاستثنائي والمواظبة والانضباط تم منح هذه الشهادة الرسمية بعد اجتياز الاختبارات النظرية والعملية.',
      sealText: 'معتمد رسمياً',
      managerTitle: 'المدير التنفيذي',
      managerName: 'د. محمد رمضان بخيت',
      trainerTitle: 'المحاضر المعتمد',
      showQrCode: true,
      borderStyle: 'ornate',
      isDefault: false
    }
  ],
  auditLogs: [
    {
      id: 'log-init',
      userId: 'user-admin',
      userName: 'مدير عام النظام',
      action: 'تهيئة النظام',
      entity: 'النظام',
      details: 'تم بدء تشغيل نظام مركز النجاح V7 وتهيئة قاعدة البيانات بنجاح',
      timestamp: new Date().toISOString()
    }
  ],
  settings: {
    centerName: 'مركز النجاح للتدريب والاستشارات',
    centerSubtitle: 'Nagah M-S',
    logoUrl: '/logo.svg',
    defaultCurrency: 'جنيه مصري',
    traineeCodePrefix: 'A',
    autoCodeLength: 3,
    academicYear: '2026/2027',
    gradePrefixes: {
      'الصف الرابع': 'A',
      'الصف الخامس': 'B',
      'الصف السادس': 'C',
      'الصف الأول الإعدادي': 'D',
      'الصف الثاني الإعدادي': 'E',
      'الصف الثالث الإعدادي': 'F',
      'ICT4': 'A',
      'ICT5': 'B',
      'ICT6': 'C',
      'ICT-P1': 'D',
      'ICT-P2': 'E',
      'ICT-P3': 'F'
    },
    defaultTrainerCommission: 40,
    defaultCenterCommission: 60,
    serverIp: '127.0.0.1',
    primaryPhone: '01001500686',
    phone: '01001500686',
    vodafoneCash: '01001500686',
    instapay: 'm_bkeet@instapay',
    email: 'info@success-center.eg',
    address: 'جمهورية مصر العربية',
    pointRules: defaultPointRules,
    rolePermissions: [
      {
        id: 'super_admin',
        title: 'مدير عام المركز (كامل الصلاحيات)',
        description: 'صلاحيات كاملة وغير مقيدة على جميع الفروع والنظام',
        isSystem: true,
        permissions: ['dashboard', 'trainees', 'trainers', 'courses', 'programs', 'groups', 'attendance', 'finance', 'expenses', 'points', 'exams', 'interactive', 'devices', 'messages', 'reports', 'certificates', 'branches', 'audit', 'settings']
      },
      {
        id: 'branch_manager',
        title: 'مدير الفرع',
        description: 'إدارة شؤون الفرع والطلاب والدورات والتقارير المالية والتشغيلية',
        isSystem: true,
        permissions: ['dashboard', 'trainees', 'trainers', 'courses', 'programs', 'groups', 'attendance', 'finance', 'expenses', 'points', 'exams', 'interactive', 'devices', 'messages', 'reports', 'certificates']
      },
      {
        id: 'accountant',
        title: 'المحاسب المالي',
        description: 'إدارة الخزينة والواردات والمصروفات والرواتب وكشف حساب المدربين',
        isSystem: true,
        permissions: ['dashboard', 'finance', 'expenses', 'reports']
      },
      {
        id: 'receptionist',
        title: 'مسؤول الاستقبال والقبول',
        description: 'تسجيل الطلاب والحضور والغياب والتواصل وطباعة كشوف المجموعات',
        isSystem: true,
        permissions: ['dashboard', 'trainees', 'courses', 'programs', 'groups', 'attendance', 'messages', 'certificates']
      },
      {
        id: 'trainer',
        title: 'المدرب والمحاضر',
        description: 'إدارة مجموعات التدريب ورصد الحضور والغياب ونقاط الطلاب والتحكم بالأجهزة',
        isSystem: true,
        permissions: ['trainees', 'courses', 'groups', 'attendance', 'points', 'exams', 'interactive', 'devices']
      }
    ]
  },
  notifications: [
    {
      id: 'notif-welcome',
      type: 'course_end',
      title: 'مرحباً بك في مركز النجاح V7',
      message: 'تم تجهيز النظام للعمل بكامل الميزات وتخصيص الفرعين (فرع النجاح وفرع بدر).',
      createdAt: new Date().toISOString(),
      read: false
    }
  ],
  traineeScreenshots: [],
  secretFinancialArchives: [],
  deletedDeviceIds: [],
  labSchedules: [
    {
      id: 'sched-1',
      branchId: 'branch-1',
      groupName: 'مجموعة الأساسيات - A1',
      courseName: 'دبلومة الحاسب الآلي الشاملة',
      trainerName: 'محمد رمضان بخيت',
      roomName: 'قاعة المعمل الرئيسية (Hall A)',
      dayOfWeek: 'السبت',
      startTime: '16:00',
      endTime: '17:00',
      isAutoCreated: true
    },
    {
      id: 'sched-2',
      branchId: 'branch-1',
      groupName: 'مجموعة الأساسيات - A1',
      courseName: 'دبلومة الحاسب الآلي الشاملة',
      trainerName: 'محمد رمضان بخيت',
      roomName: 'قاعة المعمل الرئيسية (Hall A)',
      dayOfWeek: 'الثلاثاء',
      startTime: '16:00',
      endTime: '17:00',
      isAutoCreated: true
    }
  ],
  traineeBadges: [],
  traineeEvaluations: [],
  homeworkSubmissions: [],
  googleDriveSync: {
    autoSyncEnabled: true,
    lastSyncTime: new Date().toISOString(),
    syncStatus: 'success'
  },
  studentPosts: []
};

// Store passwords safely in memory/db mapping
const userPasswordMap: Record<string, string> = {
  'user-admin': hashPassword('1234'),
  'user-accountant': hashPassword('1234'),
  'user-reception': hashPassword('1234'),
  'user-trainer': hashPassword('1234'),
  'user-branch-1': hashPassword('1234'),
  'user-branch-2': hashPassword('1234')
};

class DatabaseManager {
  private data: DatabaseSchema;
  private saveTimeout: NodeJS.Timeout | null = null;

  constructor() {
    this.ensureDataDir();
    this.data = this.loadData();
  }

  private ensureDataDir() {
    try {
      if (!fs.existsSync(ACTUAL_DATA_DIR)) {
        fs.mkdirSync(ACTUAL_DATA_DIR, { recursive: true });
      }
      if (!fs.existsSync(BACKUPS_DIR)) {
        fs.mkdirSync(BACKUPS_DIR, { recursive: true });
      }
    } catch (e) {
      console.warn('[DB] Non-critical ensureDataDir notice:', e);
    }
  }

  private loadData(): DatabaseSchema {
    try {
      let rawData: string | null = null;

      // 1. Try primary database file in runtime data dir
      if (fs.existsSync(DB_FILE)) {
        try {
          const content = fs.readFileSync(DB_FILE, 'utf-8');
          if (content && content.trim().length > 10) {
            rawData = content;
          }
        } catch (e) {
          console.warn('[DB] Error reading primary DB_FILE:', e);
        }
      }

      // 2. Try bundled database file (for Vercel / serverless deployments)
      if (!rawData && fs.existsSync(BUNDLED_DB_FILE)) {
        try {
          const content = fs.readFileSync(BUNDLED_DB_FILE, 'utf-8');
          if (content && content.trim().length > 10) {
            console.log('[DB] Loading from bundled database file');
            rawData = content;
          }
        } catch (e) {
          console.warn('[DB] Error reading BUNDLED_DB_FILE:', e);
        }
      }

      // 3. Try backup file
      if (!rawData && fs.existsSync(BACKUP_FILE)) {
        try {
          const content = fs.readFileSync(BACKUP_FILE, 'utf-8');
          if (content && content.trim().length > 10) {
            console.log('[DB] Restoring data from BACKUP_FILE');
            rawData = content;
          }
        } catch (e) {
          console.warn('[DB] Error reading BACKUP_FILE:', e);
        }
      }

      // 4. Try latest timestamped backup in backups dir
      if (!rawData && fs.existsSync(BACKUPS_DIR)) {
        try {
          const backupFiles = fs.readdirSync(BACKUPS_DIR)
            .filter(f => f.endsWith('.json'))
            .sort()
            .reverse();
          if (backupFiles.length > 0) {
            const latestBackup = path.join(BACKUPS_DIR, backupFiles[0]);
            console.log('[DB] Restoring data from latest backup file:', latestBackup);
            rawData = fs.readFileSync(latestBackup, 'utf-8');
          }
        } catch (e) {
          console.warn('[DB] Error reading rotating backups:', e);
        }
      }

      if (rawData) {
        const parsed = JSON.parse(rawData);
        
        // Merge users to ensure all default roles exist and have correct emails
        const existingUsers = Array.isArray(parsed.users) ? parsed.users : [];
        for (const defaultUser of initialData.users) {
          const match = existingUsers.find((u: User) => u.username.toLowerCase() === defaultUser.username.toLowerCase());
          if (!match) {
            existingUsers.push(defaultUser);
          } else {
            // Force update system accounts with required credentials
            match.email = defaultUser.email;
            match.fullName = defaultUser.fullName;
          }
        }

        // Merge with defaults in case of missing or empty keys
        return {
          ...initialData,
          ...parsed,
          branches: (parsed.branches && parsed.branches.length > 0) ? parsed.branches : initialData.branches,
          trainees: (parsed.trainees && parsed.trainees.length > 0) ? parsed.trainees : initialData.trainees,
          trainers: (parsed.trainers && parsed.trainers.length > 0) ? parsed.trainers : initialData.trainers,
          courses: (parsed.courses && parsed.courses.length > 0) ? parsed.courses : initialData.courses,
          groups: (parsed.groups && parsed.groups.length > 0) ? parsed.groups : initialData.groups,
          certificateTemplates: (parsed.certificateTemplates && parsed.certificateTemplates.length > 0) ? parsed.certificateTemplates : initialData.certificateTemplates,
          exams: (parsed.exams && parsed.exams.length > 0) ? parsed.exams : initialData.exams,
          questions: (parsed.questions && parsed.questions.length > 0) ? parsed.questions : initialData.questions,
          pointTransactions: (parsed.pointTransactions && parsed.pointTransactions.length > 0) ? parsed.pointTransactions : initialData.pointTransactions,
          certificates: (parsed.certificates && parsed.certificates.length > 0) ? parsed.certificates : initialData.certificates,
          trainerAttestations: parsed.trainerAttestations || [],
          users: existingUsers,
          settings: {
            ...initialData.settings,
            ...(parsed.settings || {}),
            email: parsed.settings?.email !== undefined ? parsed.settings.email : 'info@success-center.eg',
            address: parsed.settings?.address !== undefined ? parsed.settings.address : 'جمهورية مصر العربية',
            vodafoneCash: (!parsed.settings?.vodafoneCash || parsed.settings.vodafoneCash === '01012345678') ? '01001500686' : parsed.settings.vodafoneCash,
            instapay: (!parsed.settings?.instapay || parsed.settings.instapay === 'nagah@instapay') ? 'm_bkeet@instapay' : parsed.settings.instapay,
            phone: (!parsed.settings?.phone || parsed.settings.phone === '01012345678') ? '01001500686' : parsed.settings.phone,
            primaryPhone: (!parsed.settings?.primaryPhone || parsed.settings.primaryPhone === '01012345678') ? '01001500686' : parsed.settings.primaryPhone,
            rolePermissions: parsed.settings?.rolePermissions?.length ? parsed.settings.rolePermissions : initialData.settings.rolePermissions
          },
          pointRules: parsed.pointRules?.length ? parsed.pointRules : defaultPointRules
        };
      }
    } catch (err) {
      console.warn('[DB] Error loading database, falling back to initialData:', err);
    }
    
    // Attempt saving initial data to writable storage if possible
    try {
      this.saveDataDirect(initialData);
    } catch {}

    return JSON.parse(JSON.stringify(initialData));
  }

  public getData(): DatabaseSchema {
    return this.data;
  }

  public startTransaction(): DatabaseSchema {
    // Returns a deep copy of the database to perform isolated operations
    return JSON.parse(JSON.stringify(this.data));
  }

  public commitTransaction(txData: DatabaseSchema) {
    // Commit the changes by replacing the main database with the transaction state
    this.data = txData;
    this.saveDataDirect(this.data);
  }

  public save() {
    this.saveDataDirect(this.data);
  }

  public saveImmediate() {
    this.saveDataDirect(this.data);
  }

  private saveDataDirect(data: DatabaseSchema) {
    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
      this.saveTimeout = null;
    }
    try {
      this.ensureDataDir();
      const jsonStr = JSON.stringify(data, null, 2);
      const tempFile = `${DB_FILE}.tmp`;
      
      // Write atomic temp file then replace main
      fs.writeFileSync(tempFile, jsonStr, 'utf-8');
      fs.renameSync(tempFile, DB_FILE);

      // Save immediate secondary backup
      try {
        const tempBackup = `${BACKUP_FILE}.tmp`;
        fs.writeFileSync(tempBackup, jsonStr, 'utf-8');
        fs.renameSync(tempBackup, BACKUP_FILE);
      } catch (err) {
        console.warn('[DB] Non-critical BACKUP_FILE write notice:', err);
      }

      // Save hourly rotating backup
      try {
        const now = new Date();
        const dateStr = now.toISOString().slice(0, 13).replace('T', '_');
        const rotateFile = path.join(BACKUPS_DIR, `backup_${dateStr}.json`);
        fs.writeFileSync(rotateFile, jsonStr, 'utf-8');
      } catch (err) {
        console.warn('[DB] Non-critical rotating backup write notice:', err);
      }
    } catch (err) {
      console.warn('[DB] Note: saveDataDirect could not persist to local disk (stateless/read-only environment):', err);
    }
  }

  public logAudit(log: Omit<AuditLog, 'id' | 'timestamp'>) {
    const newLog: AuditLog = {
      ...log,
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      timestamp: new Date().toISOString()
    };
    this.data.auditLogs.unshift(newLog);
    if (this.data.auditLogs.length > 2000) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 2000);
    }
    this.save();
  }

  public addNotification(notification: Omit<SystemNotification, 'id' | 'createdAt' | 'read'>) {
    const newNotif: SystemNotification = {
      ...notification,
      id: 'notif-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      createdAt: new Date().toISOString(),
      read: false
    };
    this.data.notifications.unshift(newNotif);
    if (this.data.notifications.length > 100) {
      this.data.notifications = this.data.notifications.slice(0, 100);
    }
    this.save();
  }

  public getPrefixForGradeOrCourse(gradeOrCourse?: string): string {
    if (!gradeOrCourse) {
      return this.data.settings.traineeCodePrefix || 'A';
    }
    const clean = gradeOrCourse.trim();
    const prefixes = this.data.settings.gradePrefixes || {};
    
    // Exact match in settings
    if (prefixes[clean]) return prefixes[clean];

    // Check if grade matches keys in settings
    for (const [k, v] of Object.entries(prefixes)) {
      if (k.toLowerCase() === clean.toLowerCase() || clean.includes(k) || k.includes(clean)) {
        return v;
      }
    }

    // Default intelligent curriculum mapping
    if (clean.includes('رابع') || clean.toUpperCase().includes('ICT4') || clean.includes('4')) return 'A';
    if (clean.includes('خامس') || clean.toUpperCase().includes('ICT5') || clean.includes('5')) return 'B';
    if (clean.includes('سادس') || clean.toUpperCase().includes('ICT6') || clean.includes('6')) return 'C';
    if (clean.includes('أول إعدادي') || clean.includes('اول اعدادي') || clean.toUpperCase().includes('P1') || clean.toUpperCase().includes('ICT-P1') || clean.includes('إعدادي 1')) return 'D';
    if (clean.includes('ثاني إعدادي') || clean.includes('تاني اعدادي') || clean.toUpperCase().includes('P2') || clean.toUpperCase().includes('ICT-P2') || clean.includes('إعدادي 2')) return 'E';
    if (clean.includes('ثالث إعدادي') || clean.includes('تالت اعدادي') || clean.toUpperCase().includes('P3') || clean.toUpperCase().includes('ICT-P3') || clean.includes('إعدادي 3')) return 'F';
    if (clean.includes('أول ثانوي') || clean.includes('اول ثانوي') || clean.includes('1 ثانوي') || clean.toUpperCase().includes('SEC-1') || clean.toUpperCase().includes('S1')) return 'G';
    if (clean.includes('ثاني ثانوي') || clean.includes('تاني ثانوي') || clean.includes('2 ثانوي') || clean.toUpperCase().includes('SEC-2') || clean.toUpperCase().includes('S2')) return 'H';
    if (clean.includes('ثالث ثانوي') || clean.includes('تالت ثانوي') || clean.includes('3 ثانوي') || clean.toUpperCase().includes('SEC-3') || clean.toUpperCase().includes('S3')) return 'I';

    return this.data.settings.traineeCodePrefix || 'A';
  }

  public getNextTraineeCode(prefixOrGrade?: string): string {
    console.log('[DB] getNextTraineeCode: prefixOrGrade=', prefixOrGrade);
    let p = 'A';
    if (prefixOrGrade && prefixOrGrade.length === 1 && /[A-Za-z0-9\u0600-\u06FF]/.test(prefixOrGrade)) {
      p = prefixOrGrade.toUpperCase();
    } else if (prefixOrGrade) {
      p = this.getPrefixForGradeOrCourse(prefixOrGrade);
    } else {
      p = this.data.settings.traineeCodePrefix || 'A';
    }
    console.log('[DB] getNextTraineeCode: p=', p);
    const len = this.data.settings.autoCodeLength || 3;
    
    // Find all numbers with matching prefix
    let maxNum = 0;
    const regex = new RegExp(`^${p}(\\d+)$`, 'i');
    for (const t of this.data.trainees) {
      const match = t.code?.trim().match(regex);
      if (match) {
        const num = parseInt(match[1], 10);
        if (num > maxNum) {
          maxNum = num;
        }
      }
    }
    const nextNum = maxNum + 1;
    const result = `${p}${String(nextNum).padStart(len, '0')}`;
    console.log('[DB] getNextTraineeCode: result=', result);
    return result;
  }

  public recalculateTraineeRankings() {
    try {
      if (!this.data.trainees || !Array.isArray(this.data.trainees)) return;
      
      // Sort trainees by total points descending, filtering out invalid items
      const validTrainees = this.data.trainees.filter(t => t && t.id);
      const sorted = [...validTrainees].sort((a, b) => (b.totalPoints || 0) - (a.totalPoints || 0));
      
      sorted.forEach((t, index) => {
        const found = this.data.trainees.find(tr => tr && tr.id === t.id);
        if (found) {
          found.ranking = index + 1;
        }
      });
      this.save();
    } catch (err) {
      console.warn('[DB] recalculateTraineeRankings notice:', err);
    }
  }

  public recalculateTrainerFinances(trainerId?: string) {
    try {
      if (!this.data.trainers || !Array.isArray(this.data.trainers)) return;
      const trainersToUpdate = trainerId 
        ? this.data.trainers.filter(t => t && t.id === trainerId)
        : this.data.trainers.filter(t => Boolean(t && t.id));

      const coursesList = Array.isArray(this.data.courses) ? this.data.courses : [];
      const traineesList = Array.isArray(this.data.trainees) ? this.data.trainees : [];
      const paymentsList = Array.isArray(this.data.payments) ? this.data.payments : [];
      const settlementsList = Array.isArray(this.data.trainerSettlements) ? this.data.trainerSettlements : [];

      for (const trainer of trainersToUpdate) {
        if (!trainer || !trainer.id) continue;
        // Find courses taught by trainer
        const trainerCourses = coursesList.filter(c => c && (c.trainerId === trainer.id || (Array.isArray(trainer.courseIds) && trainer.courseIds.includes(c.id))));
        const courseIds = trainerCourses.map(c => c.id);

        // Trainees enrolled in these courses (checking both courseId and courseIds)
        const enrolledTrainees = traineesList.filter(t => {
          if (!t) return false;
          const cIds = Array.isArray(t.courseIds) && t.courseIds.length > 0 ? t.courseIds : (t.courseId ? [t.courseId] : []);
          return cIds.some(cid => courseIds.includes(cid));
        });
        
        let totalEarned = 0;
        for (const trainee of enrolledTrainees) {
          if (!trainee) continue;
          const traineeCourses = Array.isArray(trainee.courseIds) && trainee.courseIds.length > 0 ? trainee.courseIds : (trainee.courseId ? [trainee.courseId] : []);
          const relevantCourseIds = traineeCourses.filter(cid => courseIds.includes(cid));
          
          const traineePayments = paymentsList.filter(p => p && p.traineeId === trainee.id);
          const totalTraineePaid = trainee.paidAmount ?? traineePayments.reduce((sum, p) => sum + (Number(p?.amount) || 0), 0);
          
          const totalTraineeCoursesCount = traineeCourses.length > 0 ? traineeCourses.length : 1;
          const effectivePaid = (totalTraineePaid * relevantCourseIds.length) / totalTraineeCoursesCount;

          for (const cid of relevantCourseIds) {
            const course = trainerCourses.find(c => c && c.id === cid) || coursesList.find(c => c && c.id === cid);
            const rate = trainer.commissionRate ?? course?.trainerPercentage ?? 50;
            const coursePortionPaid = effectivePaid / (relevantCourseIds.length || 1);
            
            if (trainer.commissionType === 'percentage') {
              totalEarned += (coursePortionPaid * rate) / 100;
            } else {
              totalEarned += rate / (relevantCourseIds.length || 1);
            }
          }
        }

        // Settlements paid to trainer
        const paid = settlementsList
          .filter(s => s && s.trainerId === trainer.id)
          .reduce((sum, s) => sum + (Number(s?.amount) || 0), 0);

        trainer.totalEarned = Math.round(totalEarned * 100) / 100;
        trainer.totalPaid = Math.round(paid * 100) / 100;
        trainer.balanceDue = Math.max(0, Math.round((totalEarned - paid) * 100) / 100);
      }
      this.save();
    } catch (err) {
      console.warn('[DB] recalculateTrainerFinances notice:', err);
    }
  }

  public getPasswordHash(userId: string): string | undefined {
    return userPasswordMap[userId];
  }

  public setPassword(userId: string, plainText: string) {
    userPasswordMap[userId] = hashPassword(plainText);
  }

  public restore(snapshot: DatabaseSchema) {
    this.data = {
      ...initialData,
      ...snapshot
    };
    this.saveDataDirect(this.data);
    this.recalculateTraineeRankings();
    this.recalculateTrainerFinances();
  }

  public recalculateAll() {
    for (const trainee of this.data.trainees) {
      const traineePayments = this.data.payments.filter(p => p.traineeId === trainee.id);
      const totalPaid = traineePayments.reduce((sum, p) => sum + (p.amount || 0), 0);
      trainee.paidAmount = totalPaid;
      trainee.netAmount = Math.max(0, (trainee.feeAmount || 0) - (trainee.discountAmount || 0));
      trainee.remainingAmount = Math.max(0, trainee.netAmount - trainee.paidAmount);
      if (!trainee.courseIds) {
        trainee.courseIds = trainee.courseId ? [trainee.courseId] : [];
      } else if (trainee.courseIds.length > 0 && !trainee.courseId) {
        trainee.courseId = trainee.courseIds?.[0];
      }
    }
    this.recalculateTraineeRankings();
    this.recalculateTrainerFinances();
  }

  public resetData(options: {
    trainees?: boolean;
    payments?: boolean;
    expenses?: boolean;
    trainers?: boolean;
    courses?: boolean;
    attendance?: boolean;
    exams?: boolean;
    auditLogs?: boolean;
    screenshotsArchive?: boolean;
    treasuryNet?: boolean;
    fullReset?: boolean;
  }) {
    if (options.fullReset) {
      const currentUsers = this.data.users?.length ? this.data.users : initialData.users;
      const currentBranches = this.data.branches?.length ? this.data.branches : initialData.branches;
      const currentSettings = this.data.settings ? this.data.settings : initialData.settings;
      const currentTemplates = this.data.certificateTemplates?.length ? this.data.certificateTemplates : initialData.certificateTemplates;
      const currentPointRules = this.data.pointRules?.length ? this.data.pointRules : initialData.pointRules;

      this.data = {
        ...JSON.parse(JSON.stringify(initialData)),
        users: currentUsers,
        branches: currentBranches,
        settings: currentSettings,
        certificateTemplates: currentTemplates,
        pointRules: currentPointRules,
        trainees: [],
        trainers: [],
        courses: [],
        programs: [],
        groups: [],
        attendance: [],
        payments: [],
        expenses: [],
        trainerSettlements: [],
        pointTransactions: [],
        exams: [],
        questions: [],
        examResults: [],
        interactiveSessions: [],
        devices: [],
        deviceCommands: [],
        certificates: [],
        traineeScreenshots: [],
        notifications: initialData.notifications || []
      };
    } else {
      if (options.trainees) {
        this.data.trainees = [];
        this.data.pointTransactions = [];
        this.data.attendance = [];
        this.data.examResults = [];
        this.data.certificates = [];
        this.data.traineeScreenshots = [];
      }
      if (options.payments) {
        this.data.payments = [];
      }
      if (options.expenses) {
        this.data.expenses = [];
      }
      if (options.treasuryNet) {
        this.data.payments = [];
        this.data.expenses = [];
        this.data.trainerSettlements = [];
      }
      if (options.trainers) {
        this.data.trainers = [];
        this.data.trainerSettlements = [];
      }
      if (options.courses) {
        this.data.courses = [];
        this.data.programs = [];
        this.data.groups = [];
      }
      if (options.attendance) {
        this.data.attendance = [];
      }
      if (options.exams) {
        this.data.exams = [];
        this.data.questions = [];
        this.data.examResults = [];
      }
      if (options.auditLogs) {
        this.data.auditLogs = [];
      }
      if (options.screenshotsArchive) {
        this.data.traineeScreenshots = [];
      }
    }
    // Synchronously write directly to disk to ensure immediate reset persistence
    this.saveDataDirect(this.data);
    this.recalculateTraineeRankings();
    this.recalculateTrainerFinances();
  }
}

export const db = new DatabaseManager();
