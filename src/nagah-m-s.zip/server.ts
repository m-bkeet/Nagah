import express from "express";
import path from "path";
import fs from "fs";
import cors from "cors";
import { createServer as createViteServer } from "vite";
import { apiRouter } from './server/routes';
import { versionRouter } from './server/versionRouter';
import { secureDb } from './server/secureDbConnection';
import { migrationManager } from './server/migrationManager';
import { startBackupCron } from './server/backupService';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Global trailing slash removal middleware
  app.use((req, res, next) => {
    if (req.url && req.url.length > 1) {
      const qIndex = req.url.indexOf('?');
      if (qIndex !== -1) {
        const pathPart = req.url.substring(0, qIndex);
        const queryPart = req.url.substring(qIndex);
        if (pathPart.endsWith('/') && pathPart.length > 1) {
          req.url = pathPart.replace(/\/+$/, '') + queryPart;
        }
      } else {
        if (req.url.endsWith('/') && req.url.length > 1) {
          req.url = req.url.replace(/\/+$/, '');
        }
      }
    }
    next();
  });

  // Verify secure database connection & integrity on startup
  secureDb.verifyIntegrity();

  // Run and record system migrations on startup
  migrationManager.runInitialMigrations();

  // Start cron jobs
  startBackupCron();

  // Health check endpoints
  app.get(['/health', '/api/health'], (req, res) => {
    res.json({
      status: 'ok',
      service: 'Nagah Management System',
      environment: process.env.NODE_ENV || 'development',
      migrationsHistory: migrationManager.getHistory(),
      timestamp: new Date().toISOString()
    });
  });

  // Add CORS to allow external forms/apps to hit the public APIs
  app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
  }));

  app.use(express.json({ limit: '50mb' }));
  app.use(express.text({ limit: '50mb', type: ['application/json', 'text/plain', '*/*'] }));

  app.use((req: any, res: any, next: any) => {
    if (req.method === 'POST' || req.method === 'PUT') {
      if (typeof req.body === 'string' && req.body.trim().startsWith('{')) {
        try {
          req.body = JSON.parse(req.body);
        } catch (e) {
          // Leave as string or let route handle it
        }
      }
    }
    next();
  });

  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  app.use('/api', versionRouter);

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      if (url.startsWith('/api')) return next();
      try {
        let template = fs.readFileSync(path.resolve('index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    const distPath = fs.existsSync(path.join(process.cwd(), 'dist')) 
      ? path.join(process.cwd(), 'dist')
      : path.join(process.cwd(), 'build');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
